# SET pilot · Administrator and user guide

## Operating modes
**Synthetic pilot:** use the profile menu to explore eight roles against the same persistent, explicitly synthetic database. Changes are real database transactions, not simulated animations. A second reviewer is needed for independently approved requests. Do not upload institutional PII or use real credentials here.

**Institutional mode:** demo sign-in is disabled, fixture databases are rejected, and a named account is required. The API is authoritative even if a client alters a form. Bearer sessions remain in page memory, expire after four hours, and are revoked on logout; a production page reload requires reauthentication. The client stores only the selected synthetic role and signed-out flag in tab storage, never the access token.

## 1. Administrator setup order
1. Apply migrations and bootstrap the first named administrator. Start with an empty institutional database, not the demonstration backup.
2. In **Workspace settings → Master data**, create school, department, programme, programme duration, academic year dates, batches and curriculum semesters. IDs shown in master tables are stable references used by related forms. Programme duration is not assumed to be eight semesters for every future programme.
3. Define each regulation independently. Set activation, floating window (0 or 1), whether the regulation expressly authorises conditional prerequisites, and the order of P1–P5. The fixed safety ceiling is one semester ahead. No threshold is inferred from a regulation code.
4. Define categories, including elective and mandatory-for-degree flags, independent assessment schemes, programme/regulation degree totals and category targets. Define minimum/maximum credit policies by regulation, programme and year, optionally specialising on semester and student category. The most specific semester then category match wins. No configured maximum means **fail closed**, not unlimited credits.
5. Configure course-wise attendance policy. A null threshold requires a verified explicit status. A configured threshold can flag shortage, but never automatically creates a relaxation or a debarment. Cross-course restriction is off unless expressly enabled by the regulation.
6. Create **exception policies** for each permitted category and regulation, including the designated decision authority. Missing authority configuration does not imply permission. Create registration windows with explicit opening and closing instants.
7. Import approved curricula and prerequisites. Configure approved equivalences with validity dates and a separate credit-recognition decision. An equivalence for teaching need not award interchangeable credit.
8. Set up faculty, qualifications, course competencies, approved weekly limits, other workload and daily availability. Configure rooms and laboratory capacities. These are master data, not embedded DSU norms.
9. Import student profiles, verified transcript attempts and attendance. Review credit reconciliation before committing a batch. Create named users linked to a stable student/faculty identifier and correct school/department scope.
10. Create teaching sections, assign qualified instructors and timetable slots, then publish after validation. Do not begin institutional registration until the academic authority signs off on the complete rule set.

**Policy correction:** edit a master, inspect its old/current values and confirm. Sensitive changes are audited. You cannot change an existing student's regulation through an ordinary master edit or spreadsheet update. Approved migrations use `POST /api/admin/migrations`, an independent recorded decision, no active enrolments, and approved recognition for earned courses. Referenced master records cannot simply be archived away.

## 2. Import centre
Choose **Workspace settings → Data imports**. Download the template for the selected profile. The first worksheet contains field names; a second worksheet contains instructions. CSV headers correspond to the Excel field names.

| Profile | Important validation |
|---|---|
| Student master | Unique register number; programme/department mapping; verified completed/failed/debarred codes; earned credits must reconcile with the transcript |
| Curriculum | Regulation, programme, semester, stable course code, positive credits, L–T–P, category, matching assessment scheme and approval |
| Prerequisites | Known course codes within one curriculum; Mandatory/Conditional/Recommended; AND/OR group; no self/cyclic prerequisite |
| Equivalences | Two distinct curriculum courses; validity interval; explicit approval; independent recognition flag |
| Attendance | Counts, course mapping and attempt number; no automatic debarment; authorised status and repeat approval |
| Examination results | Verified flag, explicit attempt, Passed/Failed/Debarred; no credits for a debarred attempt |
| Faculty master | Unique staff number, department, qualification, specialisation, optional semicolon-separated stable competency course IDs |
| Faculty workload | Named faculty member and current academic year; positive maximum, nonnegative other hours |
| Offering and timetable | Configured window, course, section, instructor, seats, room, weekday, teaching type and times; import creates a draft, not automatic publication |

**Formats:** UTF-8 CSV or `.xlsx`, at most 5 MB, 2,000 records and 64 columns. Uploaded workbooks are parsed as data, never executed. Macro-enabled files, formulas, malformed worksheets and excessive expanded archive sizes are rejected. Original files are not placed in the public asset directory.

**Procedure:** select profile → choose file → optionally allow reviewed updates → validate → inspect totals, valid/failed/duplicate/missing counts and spreadsheet row numbers → correct the source file if needed → confirm the complete batch. A preview uses rolled-back savepoints. It does not commit academic data. The application revalidates every row at commit time. Invalid batches do not partially import. The staging owner alone may commit a nonexpired batch; duplicate commits are rejected. For dependent new courses, import foundations first or import all course definitions before a separate prerequisite sheet.

**Corrections:** ordinary imports reject existing identities. Reviewed updates require an explicit flag and confirmation; historical credit/assessment changes on an attempted course require a new version. A result correction and an attendance-debarment correction retain an audit event. Empty optional course lists use blank cells. Multiple codes use semicolons, dates use ISO format, weekday 1 means Monday, and times use 24-hour `HH:MM`.

## 3. Role workflows
| Role | Main actions | Hard boundaries |
|---|---|---|
| Super Administrator | Masters, users, permission delegation, policies, imports, migrations, reports and audit | Confirmation, referential history and verified academic constraints still apply |
| Registrar | Approve policy, review university exceptions and migrations, academic reporting | Decisions require assigned authority and independent review |
| Dean – SET | School overview, offering publication, pooled faculty approval and school approvals | Operational student/department queries are school scoped |
| HoD | Department records, offerings, demand, competency-valid allocation and delegated exceptions | Cannot operate on another department's student or section |
| Faculty Advisor | Review assigned students, progression, eligibility and delegated decisions | Advisor link is enforced in the API; no blanket policy override |
| Faculty | Teaching timetable, assigned sections, class roster, per-course attendance | Cannot access unrelated transcripts or record another instructor's attendance |
| Student | Own profile, registration, recovery, preferences, exceptions, timetable and credit audit | Cannot select another student's identity or change verified results |
| Examination Cell | Import verified result attempts, enter debarment, validate academic recovery and export eligibility | No ordinary authority to reassign a student's regulation |

A permission is not a substitute for a record scope. Administrators can change delegated grants in **Accounts → Permissions**. Sensitive university-wide administration powers are not grantable to student, teacher or department-scoped accounts.

## 4. Controlled registration
1. Select a student (reviewers) or open your own registration. Review the applicable regulation, semester and credit audit.
2. The available catalogue includes eligible, waitlisted and conditionally pending courses. Choose **All courses** to inspect exact block reasons. A verified pass, not an enrolment, satisfies a completion prerequisite.
3. Normal basket: current semester or the immediate next semester only. Recovery is explicitly based on a verified failed attempt, debarment or approved repeat, with an offering approved for recovery. The final semester can include individually approved pending graduation requirements. Final-year essential requirements receive P1; recovery P2, compulsory current P3, current elective P4, and floating P5, in regulation-configured priority order.
4. Select **Register**, review the course, credit value and basket, then confirm. The server revalidates under a transaction lock. Protected compulsory/recovery capacity is not available to floating/current-elective demand. Full sections waitlist rather than overbook.
5. Waitlist ties are transparent: configured priority, then original request timestamp, then stable enrolment ID. Dropping a place or increasing a valid section capacity triggers a full eligibility recheck before promotion. Superseded or blocked queue candidates are not admitted merely because a seat opened.
6. Minimum credits are checked at **Finalise credit load**; maximum credits are checked for every addition. An elective is a classification, not another credit bucket added to the total. Active registered credits exclude waitlisted, pending, dropped and concluded attempts.
7. Preferences are explicitly nonbinding. Students may set ranks 1–3 with core, floating or open-elective interest. View demand in Reports. Withdrawing an offering retains demand history and blocks registration; active enrolments must first be resolved.

## 5. Progression and attendance
Open **Student records → student** for transcript, attendance and credit audit. A completed degree requires the configured total, applicable category minima, mandatory courses and individual pending requirements. Verified credit-equivalent attempts are counted once in the student's own regulation. The forecast is a **credit-load lower bound and published-supply estimate**, not a promised date or an examination decision.

Faculty enter attended/conducted counts from a class roster. The Examination Cell may record an authorised debarment. Debarment closes that attempt, earns no credits and creates recovery eligibility without blocking unrelated courses unless expressly required. A repeat is a new numbered attempt. Passing a later verified repeat does not erase the historic debarment.

## 6. Academic approvals
A request records student, course, reason, evidence reference, creation time, year, category and designated authority. Inspect evidence, add remarks and confirm a decision. The requester cannot approve their own request. A decision is single-use and timestamped.

Conditional approvals apply to conditional groups, not mandatory groups. Credit overload adds only the expressly authorised amount in scope. A request for equivalence, special offering or altered timetable authorises administrative work: staff must still create a valid mapping, publish the offering or allocate a conflict-free alternative slot. **Approval does not silently create teaching resources or permit attendance in two places at the same time.**

## 7. Reports and recency
Transactional counts come from PostgreSQL. Cohort eligibility indicators use dated snapshots computed with the same rule engine. The synthetic service refreshes maintenance every minute; production runs `python -m backend.analytics` on a controlled schedule. Eligibility reports refresh stale scoped rows. Submission always evaluates current policy and capacity, never a snapshot. CSV/XLSX exports neutralise spreadsheet formulas; PDF reports have repeated headers. Exported files contain sensitive academic records in a real deployment and require managed storage and an institutional retention policy.
