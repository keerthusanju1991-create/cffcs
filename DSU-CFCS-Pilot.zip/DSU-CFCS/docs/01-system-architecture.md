# DSU–CFCS · SET pilot architecture
**Dhanalakshmi Srinivasan University | Academic year 2026–2027 | Architecture baseline 1.0**

## 1. System boundary
A responsive React workspace and a same-origin FastAPI application share a PostgreSQL transactional database. The UI is a client of the API, never the authority on permission, credit, capacity or eligibility. No university information system, identity provider or managed database is presumed to be connected. The local preview is an isolated synthetic training installation.

```text
Browser / accessible React workspace
    │  HTTPS in deployment · opaque, expiring bearer session
    ▼
FastAPI: typed inputs → identity → permission → object scope
    ├── Academic masters / import staging / confirmed commit
    ├── Regulation-specific policy and equivalence resolution
    ├── Eligibility → locked allocation → approval / waitlist
    ├── Faculty and room constraints → published teaching sections
    └── Scoped reports → CSV / XLSX / PDF
    │  parameterised SQL + transaction-per-request
    ▼
PostgreSQL: identity keys, foreign keys, checks, partial unique indexes
    ├── academic, administrative and student-specific records
    ├── immutable academic audit trail
    └── encrypted managed snapshots + tested point-in-time recovery (production)
```

## 2. Logical ER diagram
```mermaid
erDiagram
 SCHOOL ||--o{ DEPARTMENT : contains
 DEPARTMENT ||--o{ PROGRAMME : owns
 PROGRAMME ||--o{ STUDENT : admits
 REGULATION ||--o{ STUDENT : governs
 ADMISSION_BATCH ||--o{ STUDENT : groups
 CURRICULUM_SEMESTER ||--o{ STUDENT : places
 PROGRAMME ||--o{ COURSE : defines
 REGULATION ||--o{ COURSE : versions
 COURSE_CATEGORY ||--o{ COURSE : classifies
 ASSESSMENT_SCHEME ||--o{ COURSE : assesses
 COURSE ||--o{ PREREQUISITE_GROUP : requires
 PREREQUISITE_GROUP ||--o{ COURSE_PREREQUISITE : combines
 COURSE ||--o{ COURSE_EQUIVALENCE : relates
 REGULATION ||--o{ CREDIT_LIMIT : constrains
 PROGRAMME ||--o{ GRADUATION_REQUIREMENT : requires
 STUDENT ||--o{ STUDENT_COURSE_RESULT : earns
 STUDENT ||--o{ ATTENDANCE_RECORD : attends
 STUDENT ||--o{ COURSE_PREFERENCE : ranks
 STUDENT ||--o{ ACADEMIC_EXCEPTION : requests
 STUDENT ||--o{ REGULATION_MIGRATION : migrates
 COURSE ||--o{ OFFERING_MAPPING : retains_academic_identity
 COURSE_OFFERING ||--o{ OFFERING_MAPPING : recognises
 REGISTRATION_WINDOW ||--o{ COURSE_OFFERING : opens
 COURSE_OFFERING ||--o{ COURSE_SECTION : delivers
 DEPARTMENT ||--o{ FACULTY : employs
 FACULTY ||--o{ FACULTY_COURSE_COMPETENCY : qualifies
 FACULTY ||--o{ FACULTY_WORKLOAD : limits
 FACULTY ||--o{ COURSE_SECTION : teaches
 COURSE_SECTION ||--o{ TIMETABLE_SLOT : meets
 CLASSROOM ||--o{ TIMETABLE_SLOT : hosts
 CLASSROOM ||--o| LABORATORY : specialises
 STUDENT ||--o{ COURSE_ENROLMENT : registers
 COURSE_SECTION ||--o{ COURSE_ENROLMENT : accommodates
 COURSE ||--o{ COURSE_ENROLMENT : awards_own_credits
 COURSE_ENROLMENT ||--o{ REGISTRATION_APPROVAL : reviews
 ROLE ||--o{ USER : authorises
 ROLE ||--o{ ROLE_PERMISSION : grants
 PERMISSION ||--o{ ROLE_PERMISSION : describes
 USER ||--o{ SESSION : authenticates
 USER ||--o{ IMPORT_BATCH : stages
 USER ||--o{ ACADEMIC_AUDIT_LOG : acts
```
The executable physical schema is **`migrations/001_foundation.sql`**. Integer identities are stable; names, codes and display labels are not relationship keys. Teaching delivery and academic recognition are separate: one section may teach approved equivalent curricula, but each enrolment carries the student's original course, assessment and credit value. The schema uses PostgreSQL 15+ `UNIQUE NULLS NOT DISTINCT` for policy specificity.

## 3. Policy model
**University configuration:** organisational hierarchy, roles, academic years, rooms and registration windows. **Academic policy:** approved priority groups and transparent FIFO ties, authorised exception authorities. **Regulation requirements:** curriculum, degree category targets, floating window bounded by one, verified prerequisites, attendance configuration, credit limits. **Student state:** transcript attempts, per-course attendance, active enrolments, recovery basket and individually approved exceptions. None of the sample thresholds is an official DSU requirement.

Eligibility resolves identity and applicable curriculum, verified results and recognition, explicit recovery, semester window and final-semester requirements, prerequisite groups, subject-specific attendance, credit headroom, offering and staffing, seats and clashes. Mandatory prerequisites cannot be bypassed. Conditional approval does not waive the other checks. Minimum credits are checked at load finalisation rather than blocking the first course. Credit categories overlap: elective credits are a classification, not an extra addition to the total. Shortage is not automatically debarment. No inferred attendance relaxation.

## 4. Screen inventory
| Workspace | Working views and workflows |
|---|---|
| Overview | Scoped KPIs, registration time series, registration mix, department table, approval queue |
| Student records | Searchable directory, profile, verified transcript, course attendance, credit audit and eligible catalogue |
| Course catalogue | Curriculum by regulation, programme and semester; credits, L–T–P, prerequisites and equivalence |
| Course offerings | Sections, room and faculty, seat usage, draft → validated publication, withdrawal |
| Registration | Student-specific validation, current/floating/recovery baskets, exact block reasons, waitlisting, drop and promotion |
| Faculty pool | Qualifications, competencies, workload and proposed allocations |
| Timetable | Weekly schedule, student/faculty/department/room filters |
| Approvals | Evidence, authority, review, decision confirmation and audit details |
| Reports | Domain report selection, scoped rows and real CSV, Excel and PDF exports |
| Administration | Master data, regulation policy, nine import profiles, template downloads, staged validation and audit log |
| Personal workspace | My courses, preferences, timetable, degree progress and exception requests |
| Account / workspace search | Identity and role, synthetic-only role selector, sign out, permission-scoped search |

## 5. REST contract
All routes use `/api`. GET is side-effect free. A JSON `detail` describes errors: 401 unauthenticated, 403 permission/scope, 404 missing record, 409 conflict, 422 invalid input. Collection queries use `q`, `page`, `size` and domain filters; responses include `items`, `total`, `page`, `size`. Sensitive writes require an explicit confirmation. OpenAPI and interactive reference are available at `/openapi.json` and `/docs`.

| Resource | Operations |
|---|---|
| `/auth/login`, `/auth/logout`, `/auth/me` | Authenticate, revoke, inspect identity; `/auth/demo` only for isolated synthetic mode |
| `/dashboard`, `/search` | Scoped aggregates and workspace search |
| `/students`, `/students/{id}` | Directory and academic detail |
| `/students/{id}/eligibility`, `/students/{id}/eligible-courses` | Outcome, reason, credits, priority and section per mapped course |
| `/students/{id}/credit-audit` | Transcript-based credits, outstanding requirements and published supply coverage |
| `/courses`, `/courses/{id}/prerequisites`, `/regulations` | Curriculum and academic policies |
| `/offerings`, `/offerings/{id}/publish`, `/offerings/{id}/withdraw` | Create, validate, publish and withdraw |
| `/faculty/pool`, `/faculty/assign` | Workload and approved allocations |
| `/registration/validate`, `/registration/submit` | Same rule engine, read-only or atomic commit |
| `/registration/student/{id}`, `/registration/{id}/drop` | Active load, queue and release |
| `/registration/{id}/approve`, `/registration/{id}/reject` | Delegated validation and decision |
| `/preferences`, `/timetable`, `/exceptions` | Preference collection, projected schedule and requests |
| `/exceptions/{id}/decision` | Authorised, confirmed decision with remarks |
| `/imports/{kind}/preview`, `/imports/{id}/commit`, `/templates/{kind}` | XLSX/CSV stage, revalidate, commit or correct |
| `/reports/{report}`, `/reports/{report}/export` | Scoped data and format `csv`, `xlsx` or `pdf` |
| `/admin/masters/{kind}`, `/audit` | Allowlisted master data and audit history |

## 6. Delivery / verification gates
1. **Foundation:** transactional SQL migration, bearer authentication, grants, scope checks, audit. Verify constraints and denied writes.
2. **Masters:** hierarchy, independent regulations, approved policy editing. Verify immutable student regulation mapping.
3. **Records:** stable student IDs, templates and staged imports. Test invalid, duplicate and conflicting rows.
4. **Eligibility:** verified result groups, per-course attendance and separate recovery. Test current, next and forbidden future courses.
5. **Delivery:** equivalence, original academic mapping, publication checks. Test non-equivalent rejection.
6. **Staffing:** competency, availability, contact hours and room/lab capacity. Test overload and clashes.
7. **Allocation:** atomic admission, protected seats, FIFO priority and promotion. Race two connections for one seat.
8. **Progress:** generated timetables, degree categories and supply-based forecast. Verify credit identity and conflicts.
9. **Operations:** role workspaces, approval evidence, demand and export formats. Verify scopes across roles.
10. **Release:** run rule, integration and browser checks; document actual results and go-live dependencies.

## 7. Deployment boundary
Local PostgreSQL is real, but is not a managed hosting service. Production requires an institution-provisioned private managed PostgreSQL endpoint, TLS, a secrets manager, named accounts, least-privilege database roles, approved academic parameter imports, backup restore rehearsal and institutional UAT. Demo authentication is rejected outside synthetic mode. No declaration of official policy approval, external audit or production readiness is implied by a passing local suite.

## Delivered release additions
The final schema includes `002_scope_and_policy.sql` (school scopes, exception policies and dated eligibility analytics), `003_verified_credits.sql` (independent verified credit recognition) and `004_attempt_lifecycle.sql` (separate original and repeat attempts). Refer to the generated `database-schema.sql`, `er-diagram.svg`, `schema-dictionary.csv` and `api-specification.json` for the exact delivered contract. The final release contains 49 tables, 89 foreign keys and 66 REST operations.
