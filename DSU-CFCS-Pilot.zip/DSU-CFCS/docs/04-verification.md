# Verification and release record

**Local execution:** 2026-11-18T14:07:52.315858+00:00  
**Result:** 62 tests, 0 failures, 0 errors, 0 skipped. Runtime: 26.002 seconds.  
**Database:** PostgreSQL 17, isolated schema per scenario. **Browser:** real headless Chromium.  
**Delivered surface:** 49 normalised tables, 89 foreign keys, four transactional migrations, 66 documented REST operations.

## Test gates
| Suite | Tests | Coverage |
|---|---:|---|
| Academic acceptance | 20 | All 20 requested mandatory scenarios |
| Workflow / integration / pure unit | 33 | Nine Excel profiles, preview/commit, audit, role scope, independent decisions, authentication, credit identity, attempt lifecycle and capacity changes |
| Browser end-to-end | 9 | Dashboard/filtering, student detail, publication, registration/drop, approvals, XLSX download/import, faculty attendance, search and mobile navigation |

## Mandatory academic scenarios
| No. | Executed scenario | Result |
|---:|---|---|
| 1 | Current semester registration | PASS |
| 2 | Immediately succeeding semester | PASS |
| 3 | Two semesters ahead blocked | PASS |
| 4 | Verified backlog outside window | PASS |
| 5 | Debarment normal block repeat allowed zero credits | PASS |
| 6 | Debarment does not block unrelated course | PASS |
| 7 | Mandatory prerequisites require verified results | PASS |
| 8 | Conditional prerequisite approved exception | PASS |
| 9 | Credit limit enforced | PASS |
| 10 | Duplicate registration refused | PASS |
| 11 | Atomic last seat race | PASS |
| 12 | Shared section independent regulation credits | PASS |
| 13 | Non equivalent courses cannot share delivery | PASS |
| 14 | Faculty assignment cannot exceed norm | PASS |
| 15 | Faculty timetable conflict | PASS |
| 16 | Student timetable conflict | PASS |
| 17 | Full section waitlists and promotes | PASS |
| 18 | Final semester pending graduation priority | PASS |
| 19 | Withdrawal after preferences preserves demand | PASS |
| 20 | Unauthorised academic modification denied | PASS |

## Phase-to-code traceability
1. Foundation: `core.py`, versioned DDL, password/session/permission tests.
2. Masters: `admin.py`, protected identity, approved migration and archival guards.
3. Student records: `imports.py`, real Excel workbook tests, invalid-row diagnostics and credit reconciliation.
4. Eligibility: `engine.py`, mandatory/conditional/recommended and AND/OR groups; per-attempt debarment.
5. Equivalence and delivery: approved validity-bounded mappings, original credits and schemes; publication checks.
6. Faculty: competencies, cross-department teaching, approved load, availability and lab/room checks.
7. Registration: same validator at submit/promotion, concurrent last-seat test, protected capacity, queue promotion.
8. Timetable and credit audit: overlap checks, verified recognition view, original attempts, category targets and supply-based forecast.
9. Operations: eight role workspaces, reports, actual binary downloads, validated uploads, independent decisions and audit.
10. Release: full regression, browser verification, verified backup restoration and deployment handoff.

## Additional observed checks
- No section overbooking in the initial live synthetic dataset.
- Desktop and 390-pixel mobile layouts render without page-level horizontal overflow; wide tables scroll inside their own container.
- Offline `/docs` renders using bundled Swagger assets; the OpenAPI schema includes a bearer authorisation scheme.
- A checksum-verified custom-format backup restored to a separate empty PostgreSQL database. Student, enrolment and examination-attempt counts matched the source; restored sessions = 0.
- Test writes occur in isolated schemas, not the user-facing preview. A deprecation notice from the test-client integration is not a failed test.

## Release decision
**Engineering regression: passed. Institutional go-live: not yet authorised.** These tests establish the stated scenarios on the delivered environment. They do not establish official DSU policy correctness, production load capacity, external security certification, privacy compliance, managed-database failover or final university UAT. Complete the deployment checklist before using real records.
