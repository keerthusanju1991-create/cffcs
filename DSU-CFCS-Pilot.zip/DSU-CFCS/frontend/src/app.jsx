import React, { useEffect, useState, useRef } from "react";
import { createRoot } from "react-dom/client";
import {
  LayoutGrid,
  ContactRound,
  BookOpen,
  Layers3,
  ClipboardList,
  UsersRound,
  CalendarDays,
  ListChecks,
  ChartNoAxesCombined,
  Settings2,
  ChevronRight,
  ChevronDown,
  Search,
  Bell,
  PanelLeft,
  Menu,
  X,
  FlaskConical,
  ShieldCheck,
  LogOut,
  Info,
  ArrowRight,
  GraduationCap,
  Building2,
  Command,
  CheckCircle2,
  TriangleAlert,
  Check,
  Clock3,
  Activity,
  Landmark,
  UserRound,
  Bookmark,
  LockKeyhole,
  CalendarRange,
  FolderOpen,
} from "lucide-react";
import {
  Ctx,
  useApp,
  useLoad,
  api,
  setToken,
  Crest,
  Modal,
  Button,
  IconButton,
  Initials,
  Loading,
  State,
  Notice,
  Field,
  Empty,
  Badge,
  KV,
  fmt,
} from "./ui";
import { Dashboard } from "./dashboard";
import {
  DataList,
  StudentDetail,
  CourseDetail,
  FacultyDetail,
  Registration,
  Approvals,
  Timetable,
  Reports,
} from "./pages";
import { Settings } from "./settings";
import "./style.css";
const GROUPS = [
  [
    "WORKSPACE",
    [
      ["overview", "Overview", LayoutGrid],
      ["students", "Student records", ContactRound],
    ],
  ],
  [
    "ACADEMIC MANAGEMENT",
    [
      ["courses", "Course catalogue", BookOpen],
      ["offerings", "Course offerings", Layers3],
      ["registration", "Registration", ClipboardList],
      ["faculty", "Faculty pool", UsersRound],
      ["timetable", "Timetable", CalendarDays],
    ],
  ],
  [
    "GOVERNANCE",
    [
      ["approvals", "Approvals", ListChecks],
      ["reports", "Reports & analytics", ChartNoAxesCombined],
    ],
  ],
];
const pages = Object.fromEntries(
  GROUPS.flatMap((g) => g[1].map((i) => [i[0], i[1]])),
);
pages.settings = "Workspace settings";
const parseRoute = () => {
  let [p, q] = location.hash.slice(1).split("?");
  return {
    page: pages[p] ? p : "overview",
    filters: Object.fromEntries(new URLSearchParams(q || "")),
  };
};
function SearchModal() {
  let { close, open, navigate, user } = useApp();
  let [q, sq] = useState(""),
    [deb, sd] = useState("");
  useEffect(() => {
    let t = setTimeout(() => sd(q.trim()), 180);
    return () => clearTimeout(t);
  }, [q]);
  let res = useLoad(
    deb.length >= 2 ? "/search?q=" + encodeURIComponent(deb) : null,
  );
  return (
    <Modal
      title="Search workspace"
      subtitle="Find a page, student, course or faculty member"
      onClose={close}
    >
      <div className="globalsearch">
        <Search size={19} />
        <input
          autoFocus
          value={q}
          onChange={(e) => sq(e.target.value)}
          aria-label="Search all workspace records"
          placeholder="What are you looking for?"
        />
        <kbd>ESC</kbd>
      </div>
      <div className="searchresults">
        <h4>WORKSPACE PAGES</h4>
        {Object.entries(pages)
          .filter(([k, v]) => v.toLowerCase().includes(q.toLowerCase()))
          .slice(0, q ? 7 : 4)
          .map(([k, v]) => (
            <button
              key={k}
              onClick={() => {
                close();
                navigate(k);
              }}
            >
              <FolderOpen size={16} />
              <span>{v}</span>
              <ArrowRight size={13} />
            </button>
          ))}
        {deb.length >= 2 && (
          <State req={res}>
            {(d) => (
              <>
                {[
                  ["students", "STUDENTS", (r) => <StudentDetail sid={r.id} />],
                  ["courses", "COURSES", (r) => <CourseDetail id={r.id} />],
                  ["faculty", "FACULTY", (r) => <FacultyDetail id={r.id} />],
                ].map(
                  ([k, label, component]) =>
                    d[k].length > 0 && (
                      <div key={k}>
                        <h4>{label}</h4>
                        {d[k].map((r) => (
                          <button key={r.id} onClick={() => open(component(r))}>
                            {k === "courses" ? (
                              <BookOpen size={15} />
                            ) : (
                              <UserRound size={15} />
                            )}
                            <span>
                              {r.name || r.title}
                              <small>
                                {r.register_number || r.code || r.staff_number}{" "}
                                · {r.department}
                                {r.regulation ? " · " + r.regulation : ""}
                              </small>
                            </span>
                            <ChevronRight size={14} />
                          </button>
                        ))}
                      </div>
                    ),
                )}
                {!d.students.length &&
                  !d.courses.length &&
                  !d.faculty.length && (
                    <Empty
                      title="No matching records"
                      text="Try a course code, faculty specialisation or student name."
                    />
                  )}
              </>
            )}
          </State>
        )}
      </div>
    </Modal>
  );
}
function About() {
  const { close, synthetic } = useApp();
  return (
    <Modal
      title="About this workspace"
      subtitle="DSU Controlled Flexible Credit System"
      onClose={close}
    >
      <div className="aboutbrand">
        <Crest size={37} />
        <div>
          <h2>DSU–CFCS</h2>
          <p>Dhanalakshmi Srinivasan University</p>
        </div>
      </div>
      <KV
        items={[
          ["School", "Engineering & Technology"],
          ["Academic year", "2026–2027"],
          [
            "Environment",
            synthetic ? "Isolated synthetic pilot" : "Institutional deployment",
          ],
          ["Database", "PostgreSQL"],
          ["API", "FastAPI · v1.0"],
          ["Access control", "Role + record scope"],
        ]}
      />
      {synthetic && (
        <Notice>
          All student identities, faculty records, course mappings and academic
          limits in this preview are synthetic examples, not official DSU
          information.
        </Notice>
      )}
    </Modal>
  );
}
// Optional tab preferences must not prevent opening an embedded workspace.
// They contain only role labels and a signed-out flag, never credentials.
const volatilePrefs = new Map();
const tabPrefs = {
  get(key) {
    try {
      return window.sessionStorage.getItem(key) ?? volatilePrefs.get(key);
    } catch {
      return volatilePrefs.get(key);
    }
  },
  set(key, value) {
    volatilePrefs.set(key, value);
    try {
      window.sessionStorage.setItem(key, value);
    } catch {
      /* Storage is optional. */
    }
  },
  remove(key) {
    volatilePrefs.delete(key);
    try {
      window.sessionStorage.removeItem(key);
    } catch {
      /* Storage is optional. */
    }
  },
};
function LoginScreen({ config, onLogin, onDemo, err }) {
  const [error, se] = useState(err),
    [busy, sb] = useState(false);
  const pilot = config?.synthetic === true;
  const signInForm = (
    <form
      className="formstack"
      onSubmit={async (e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        se("");
        sb(true);
        try {
          await onLogin(f.get("username"), f.get("password"));
        } catch (x) {
          se(x.message);
        } finally {
          sb(false);
        }
      }}
    >
      <Field label="Username">
        <input name="username" autoComplete="username" required />
      </Field>
      <Field label="Password">
        <input
          name="password"
          type="password"
          autoComplete="current-password"
          required
        />
      </Field>
      <Button kind="primary" type="submit" disabled={busy}>
        Sign in
      </Button>
    </form>
  );
  return (
    <div className="loginpage">
      <div className="loginbrand">
        <Crest size={38} />
        <b>DSU–CFCS</b>
      </div>
      <div className="logincard">
        <div className="overline blue-text">ACADEMIC WORKSPACE</div>
        <h1>{pilot ? "Explore the pilot" : "Welcome back"}</h1>
        <p>
          {pilot
            ? "Open the synthetic SET workspace without a username or password."
            : "Sign in to your university workspace."}
        </p>
        {pilot ? (
          <>
            <div className="pilot-entry">
              <span>
                <FlaskConical size={15} /> Synthetic pilot workspace
              </span>
              <Button
                kind="primary"
                disabled={busy}
                onClick={async () => {
                  se("");
                  sb(true);
                  try {
                    await onDemo("Dean – SET");
                  } catch (e) {
                    se(e.message);
                  } finally {
                    sb(false);
                  }
                }}
              >
                {busy ? "Opening workspace…" : "Explore the Dean workspace"}
                <ArrowRight size={14} />
              </Button>
            </div>
            <details className="named-login">
              <summary>Sign in with a named account</summary>
              {signInForm}
            </details>
          </>
        ) : (
          signInForm
        )}
        {error && (
          <div className="login-feedback">
            <Notice kind="error">{error}</Notice>
          </div>
        )}
      </div>
    </div>
  );
}
function App() {
  const [auth, sa] = useState(null),
    [config, sconfig] = useState(null),
    [lookup, slookup] = useState({
      departments: [],
      regulations: [],
      rooms: [],
      windows: [],
    }),
    [boot, sboot] = useState(true),
    [autherr, serr] = useState(""),
    [rt, srt] = useState(parseRoute),
    [modal, sm] = useState(null),
    [toast, stoast] = useState(null),
    [version, sv] = useState(0),
    [mobile, smb] = useState(false),
    [collapsed, sc] = useState(false),
    [menu, smenu] = useState("");
  const timer = useRef(0);
  const dashboard = useLoad(
    auth ? "/dashboard" : null,
    version + "-" + auth?.id,
  );
  const close = () => sm(null);
  const open = (c) => {
    smenu("");
    sm(c);
  };
  const notify = (msg, type = "success") => {
    stoast({ msg, type });
    clearTimeout(timer.current);
    timer.current = setTimeout(() => stoast(null), 4200);
  };
  function navigate(page, filters = {}) {
    const p = pages[page] ? page : "overview";
    let q = new URLSearchParams(filters).toString();
    location.hash = p + (q ? "?" + q : "");
    srt({ page: p, filters });
    smb(false);
    smenu("");
    sm(null);
    window.scrollTo(0, 0);
  }
  useEffect(() => {
    const h = () => {
      srt(parseRoute());
      sm(null);
      smb(false);
      smenu("");
    };
    window.addEventListener("hashchange", h);
    return () => window.removeEventListener("hashchange", h);
  }, []);
  async function ready(token) {
    setToken(token);
    let [u, l] = await Promise.all([api("/auth/me"), api("/lookups")]);
    sa(u);
    slookup(l);
    serr("");
    tabPrefs.remove("dsu-signed-out");
  }
  async function changeRole(role, initial = false) {
    if (auth) await api("/auth/logout", { method: "POST" }).catch(() => {});
    let r = await api("/auth/demo", { method: "POST", body: { role } });
    await ready(r.access_token);
    tabPrefs.set("dsu-demo-role", role);
    if (!initial) {
      navigate("overview");
      notify("Switched to " + role + " workspace");
    }
  }
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        let c = await api("/workspace");
        if (!alive) return;
        sconfig(c);
        if (c.synthetic && !tabPrefs.get("dsu-signed-out"))
          await changeRole(tabPrefs.get("dsu-demo-role") || "Dean – SET", true);
      } catch (e) {
        serr(e.message);
      } finally {
        sboot(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    const handle = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k" && auth) {
        e.preventDefault();
        open(<SearchModal />);
      }
      if (e.key === "Escape") {
        smenu("");
        smb(false);
      }
    };
    document.addEventListener("keydown", handle);
    return () => document.removeEventListener("keydown", handle);
  }, [auth]);
  useEffect(() => {
    document.title = (pages[rt.page] || "Overview") + " · DSU–CFCS";
  }, [rt.page]);
  const refresh = () => {
    sv((v) => v + 1);
    api("/lookups")
      .then(slookup)
      .catch(() => {});
  };
  if (boot)
    return (
      <div className="boot">
        <div className="bootsigil">
          <Crest size={44} />
        </div>
        <h2>DSU–CFCS</h2>
        <Loading small />
      </div>
    );
  if (!auth)
    return (
      <LoginScreen
        config={config}
        err={autherr}
        onDemo={changeRole}
        onLogin={async (username, password) => {
          let r = await api("/auth/login", {
            method: "POST",
            body: { username, password },
          });
          await ready(r.access_token);
          navigate("overview");
        }}
      />
    );
  const stats = dashboard.data?.stats;
  const navlabel = (k, l) =>
    auth.role === "Student"
      ? {
          overview: "My overview",
          students: "My academic record",
          approvals: "My requests",
          registration: "Course registration",
        }[k] || l
      : l;
  const ctx = {
    user: auth,
    synthetic: config?.synthetic,
    lookup,
    version,
    refresh,
    open,
    close,
    notify,
    navigate,
    filters: rt.filters,
  };
  return (
    <Ctx.Provider value={ctx}>
      <div
        className={
          "shell " +
          (collapsed ? "collapsed " : "") +
          (mobile ? "mobile-open" : "")
        }
      >
        <a
          href="#maincontent"
          className="skiplink"
          onClick={(e) => {
            e.preventDefault();
            document.getElementById("maincontent").focus();
          }}
        >
          Skip to content
        </a>
        {mobile && <div className="mobilescrim" onClick={() => smb(false)} />}
        <aside className="sidebar">
          <div className="brand">
            <Crest size={38} />
            <div>
              <div className="brandname">
                DSU
                <span className="brandbar" />
                CFCS
              </div>
              <p>Academic management</p>
            </div>
          </div>
          <nav className="sidenav" aria-label="Workspace navigation">
            {GROUPS.map(([label, items]) => (
              <div className="navgroup" key={label}>
                <div className="navcaption">{label}</div>
                {items
                  .filter(
                    ([k]) =>
                      !(
                        k === "approvals" &&
                        !auth.permissions.includes("requests") &&
                        !auth.permissions.includes("review")
                      ),
                  )
                  .map(([k, l, I]) => (
                    <button
                      key={k}
                      title={navlabel(k, l)}
                      aria-current={rt.page === k ? "page" : undefined}
                      className={"navitem " + (rt.page === k ? "selected" : "")}
                      onClick={() => navigate(k)}
                    >
                      <I size={18} strokeWidth={1.65} />
                      <span>{navlabel(k, l)}</span>
                      {k === "approvals" && stats?.pending > 0 && (
                        <em>{stats.pending}</em>
                      )}
                    </button>
                  ))}
              </div>
            ))}
          </nav>
          <div className="sidebottom">
            <button
              className={
                "navitem " + (rt.page === "settings" ? "selected" : "")
              }
              title="Workspace settings"
              onClick={() => navigate("settings")}
            >
              <Settings2 size={18} />
              <span>Workspace settings</span>
            </button>
            <button className="pilotcard" onClick={() => open(<About />)}>
              <span className="piloticon">
                <FlaskConical size={18} />
              </span>
              <span>
                <b>{config?.synthetic ? "Pilot workspace" : "SET workspace"}</b>
                <small>
                  {config?.synthetic
                    ? "Synthetic data environment"
                    : "Institutional environment"}
                </small>
              </span>
              <i className="statuslight" />
            </button>
          </div>
        </aside>
        <div className="mainwrap">
          <header className="topbar">
            <div className="crumbs">
              <IconButton
                icon={PanelLeft}
                label="Toggle navigation"
                onClick={() =>
                  window.innerWidth <= 850 ? smb(!mobile) : sc(!collapsed)
                }
              />
              <span className="crumbdivider" />
              <span className="crumb-workspace">Workspace</span>
              <ChevronRight size={12} />
              <b>{navlabel(rt.page, pages[rt.page])}</b>
            </div>
            <div className="topactions">
              <button
                className="searchtrigger"
                onClick={() => open(<SearchModal />)}
              >
                <Search size={15} />
                <span>Search workspace</span>
                <kbd>⌘ K</kbd>
              </button>
              <div className="menuwrap">
                <button
                  className="bellbtn"
                  aria-label="View notifications"
                  onClick={() => smenu(menu === "alerts" ? "" : "alerts")}
                >
                  <Bell size={19} strokeWidth={1.6} />
                  {!!stats?.pending && <i />}
                </button>
                {menu === "alerts" && (
                  <>
                    <div className="menu-dismiss" onClick={() => smenu("")} />
                    <div className="dropdown alerts">
                      <div className="drophead">
                        <h3>Workspace notifications</h3>
                        <Badge tone="blue">{stats?.pending || 0}</Badge>
                      </div>
                      <div className="notification">
                        <span className="metric-icon amber">
                          <ClipboardList size={17} />
                        </span>
                        <div>
                          <b>
                            {stats?.pending_exceptions || 0} academic requests
                          </b>
                          <p>Exception requests awaiting a decision.</p>
                        </div>
                      </div>
                      <div className="notification">
                        <span className="metric-icon blue">
                          <Layers3 size={17} />
                        </span>
                        <div>
                          <b>{stats?.pending_offers || 0} offering reviews</b>
                          <p>Teaching sections pending publication.</p>
                        </div>
                      </div>
                      <button
                        className="textlink"
                        onClick={() => navigate("approvals")}
                      >
                        Open approval centre <ArrowRight size={14} />
                      </button>
                    </div>
                  </>
                )}
              </div>
              <span className="userdivider" />
              <div className="menuwrap">
                <button
                  className="accounttrigger"
                  aria-label="Account and demo role selection"
                  onClick={() => smenu(menu === "account" ? "" : "account")}
                >
                  <Initials name={auth.name} />
                  <span>
                    <b>{auth.name}</b>
                    <small>{auth.role.replace(" – ", ", ")}</small>
                  </span>
                  <ChevronDown size={13} />
                </button>
                {menu === "account" && (
                  <>
                    <div className="menu-dismiss" onClick={() => smenu("")} />
                    <div className="dropdown accountmenu">
                      <div className="accountsummary">
                        <b>{auth.name}</b>
                        <small>{auth.username}</small>
                      </div>
                      {config?.synthetic && (
                        <>
                          <div className="menucaption">
                            SYNTHETIC PILOT · SWITCH ROLE
                          </div>
                          {config.roles.map((role) => (
                            <button
                              key={role}
                              className={role === auth.role ? "current" : ""}
                              onClick={async () => {
                                try {
                                  await changeRole(role);
                                } catch (e) {
                                  notify(e.message, "error");
                                }
                              }}
                            >
                              <UserRound size={14} />
                              {role}
                              {role === auth.role && <Check size={14} />}
                            </button>
                          ))}
                        </>
                      )}
                      <div className="menuline" />
                      <button onClick={() => open(<About />)}>
                        <Info size={15} />
                        About workspace
                      </button>
                      <button
                        onClick={async () => {
                          await api("/auth/logout", { method: "POST" });
                          setToken("");
                          sa(null);
                          smenu("");
                          tabPrefs.set("dsu-signed-out", "1");
                        }}
                      >
                        <LogOut size={15} />
                        Sign out
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </header>
          <main
            id="maincontent"
            tabIndex={-1}
            key={auth.id + "-" + rt.page + "-" + JSON.stringify(rt.filters)}
          >
            {rt.page === "overview" ? (
              auth.role === "Student" ? (
                <Registration personal />
              ) : auth.role === "Faculty" ? (
                <Timetable />
              ) : (
                <Dashboard />
              )
            ) : ["students", "courses", "offerings", "faculty"].includes(
                rt.page,
              ) ? (
              <DataList kind={rt.page} />
            ) : rt.page === "registration" ? (
              <Registration />
            ) : rt.page === "approvals" ? (
              <Approvals />
            ) : rt.page === "timetable" ? (
              <Timetable />
            ) : rt.page === "reports" ? (
              <Reports />
            ) : (
              <Settings />
            )}
          </main>
        </div>
      </div>
      {modal}
      {toast && (
        <div className={"toast " + toast.type} role="status">
          {toast.type === "error" ? (
            <TriangleAlert size={17} />
          ) : (
            <CheckCircle2 size={17} />
          )}
          <span>{toast.msg}</span>
          <button
            aria-label="Dismiss notification"
            onClick={() => stoast(null)}
          >
            <X size={13} />
          </button>
        </div>
      )}
    </Ctx.Provider>
  );
}
createRoot(document.getElementById("root")).render(<App />);
