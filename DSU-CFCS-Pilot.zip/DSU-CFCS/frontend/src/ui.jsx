import React, {
  useState,
  useEffect,
  useRef,
  useContext,
  createContext,
} from "react";
import {
  ChevronLeft,
  ChevronRight,
  X,
  Search,
  LoaderCircle,
  Inbox,
  CheckCircle2,
  TriangleAlert,
  Info,
  ArrowUpRight,
  ChevronDown,
  Download,
  Check,
  RotateCw,
  ShieldCheck,
} from "lucide-react";
export const Ctx = createContext({});
export const useApp = () => useContext(Ctx);
let token = "";
export const setToken = (t) => (token = t);
// Keep the session in memory. Application headers survive preview gateways
// that reserve Authorization for platform authentication. Never put it in a URL.
const sessionHeaders = () => (token ? { "X-CFCS-Session": token } : {});
export async function api(path, options = {}) {
  let o = {
    ...options,
    headers: { ...sessionHeaders(), ...options.headers },
  };
  if (o.body && !(o.body instanceof FormData)) {
    o.headers["Content-Type"] = "application/json";
    o.body = JSON.stringify(o.body);
  }
  const r = await fetch("/api" + path, o);
  if (!r.ok) {
    let j = await r
      .json()
      .catch(() => ({ detail: "The request could not be completed." }));
    throw Error(
      Array.isArray(j.detail)
        ? j.detail.map((i) => i.loc?.slice(-1) + ": " + i.msg).join("; ")
        : j.detail || `Request failed (${r.status})`,
    );
  }
  return r.json();
}
export async function download(path, fallback) {
  const r = await fetch("/api" + path, {
    headers: sessionHeaders(),
  });
  if (!r.ok) {
    let j = await r.json();
    throw Error(j.detail || "Export failed.");
  }
  const a = document.createElement("a");
  const url = URL.createObjectURL(await r.blob());
  a.href = url;
  a.download =
    (r.headers.get("content-disposition") || "").match(
      /filename="([^"]+)"/,
    )?.[1] || fallback;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2500);
}
export function useLoad(path, key = 0) {
  const [data, setData] = useState(null),
    [error, setError] = useState(""),
    [loading, sl] = useState(true);
  useEffect(() => {
    let alive = true;
    setError("");
    setData(null);
    if (!path) {
      sl(false);
      return;
    }
    sl(true);
    api(path)
      .then((d) => {
        if (alive) setData(d);
      })
      .catch((e) => {
        if (alive) setError(e.message);
      })
      .finally(() => {
        if (alive) sl(false);
      });
    return () => {
      alive = false;
    };
  }, [path, key]);
  return { data, error, loading };
}
export const fmt = (v) =>
  Number(v || 0).toLocaleString("en-IN", { maximumFractionDigits: 1 });
export const tit = (s) =>
  String(s || "")
    .replaceAll("_", " ")
    .replace(/\b\w/g, (a) => a.toUpperCase());
export const dayfmt = (v) =>
  new Date(v).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
export const tm = (n) =>
  `${String(Math.floor(n / 60)).padStart(2, "0")}:${String(n % 60).padStart(2, "0")}`;
export function Crest({ size = 40 }) {
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size * 1.13}
      viewBox="0 0 44 50"
      fill="none"
    >
      <path
        d="M3 4L22 1l19 3v21c0 10-9 18-19 23C12 43 3 35 3 25Z"
        stroke="#D7C393"
        strokeWidth="1.7"
      />
      <path
        d="M6 7l16-3 16 3v18c0 8-7 15-16 20C13 40 6 33 6 25Z"
        stroke="#BCA675"
        strokeWidth=".7"
      />
      <path
        d="M10 24c5-1 9 0 12 3 3-3 7-4 12-3v9c-5-.5-9 .8-12 3-4-2-8-3.5-12-3Z"
        fill="#DECFAD"
      />
      <path
        d="M22 27v8m-10-8c3 0 6 1 8 2m-8 1c3 0 6 1 8 2m4-3c2-1 5-2 8-2m-8 5c2-1 5-2 8-2"
        stroke="#16253B"
        strokeWidth="1"
      />
      <path d="M18 18h8l-2 3h-4Zm3 4h2v4h-2Z" fill="#D7C393" />
      <path
        d="M22 7c2 4-2 5 1 8 0-2 2-2 2-5 4 6 1 9-3 9-5 0-6-4-3-8 0 3 1 3 2 3-1-3 1-4 1-7Z"
        fill="#D7C393"
      />
      <path
        d="M12 10l1 2 2 .5-2 1-.5 2-.8-2-2-1 2-.5Zm20 0l.8 2 2 .5-2 1-.8 2-.8-2-2-1 2-.5Z"
        fill="#D7C393"
      />
    </svg>
  );
}
export function Badge({ children, tone }) {
  const v = String(children);
  let c =
    tone ||
    (/^(Active|Eligible|Published|Approved|Passed|Verified|Registered|Online|Confirmed)$/.test(
      v,
    )
      ? "green"
      : /Pending|Waitlisted|Shortage|Draft|Repeat/.test(v)
        ? "amber"
        : /Blocked|Rejected|Debarred|Failed|Withdrawn|Restricted/.test(v)
          ? "red"
          : /Floating|R202|Regular/.test(v)
            ? "blue"
            : "slate");
  return <span className={"badge " + c}>{children}</span>;
}
export function Button({
  children,
  icon: I,
  onClick,
  kind = "",
  disabled = false,
  type = "button",
  ...props
}) {
  return (
    <button
      className={"btn " + kind}
      type={type}
      onClick={onClick}
      disabled={disabled}
      {...props}
    >
      {I && <I size={15} />} {children}
    </button>
  );
}
export function IconButton({ icon: I, label, onClick, extra = "" }) {
  return (
    <button
      className={"iconbtn " + extra}
      aria-label={label}
      title={label}
      onClick={onClick}
    >
      <I size={17} />
    </button>
  );
}
export function Empty({
  title = "No records found",
  text = "Try a different search or filter.",
  icon: I = Inbox,
}) {
  return (
    <div className="empty">
      <span>
        <I size={25} />
      </span>
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}
export function Loading({ small = false }) {
  return (
    <div className={"loading " + (small ? "small" : "")}>
      <LoaderCircle className="spin" size={19} />
      <span>Loading workspace data…</span>
    </div>
  );
}
export function Notice({ children, kind = "info" }) {
  let I =
    kind === "error" ? TriangleAlert : kind === "success" ? CheckCircle2 : Info;
  return (
    <div
      role={kind === "error" ? "alert" : "status"}
      className={"notice " + kind}
    >
      <I size={16} />
      <span>{children}</span>
    </div>
  );
}
export function State({ req, children }) {
  return req.error ? (
    <Notice kind="error">{req.error}</Notice>
  ) : req.loading || !req.data ? (
    <Loading />
  ) : (
    children(req.data)
  );
}
export function PageHead({
  eyebrow = "ACADEMIC WORKSPACE",
  title,
  subtitle,
  action,
}) {
  return (
    <div className="pagehead">
      <div>
        <div className="overline blue-text">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      {action}
    </div>
  );
}
export function Searchbox({
  value,
  onChange,
  placeholder = "Search records…",
}) {
  return (
    <label className="searchfield">
      <Search size={16} />
      <input
        aria-label={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
      />
      {value && (
        <button aria-label="Clear search" onClick={() => onChange("")}>
          <X size={13} />
        </button>
      )}
    </label>
  );
}
export function Select({ value, onChange, options, label, small = false }) {
  return (
    <label className={"selectwrap " + (small ? "small" : "")}>
      <select
        aria-label={label || "Filter"}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((o, i) =>
          typeof o === "object" ? (
            <option key={i} value={o.value}>
              {o.label}
            </option>
          ) : (
            <option key={i} value={o}>
              {o}
            </option>
          ),
        )}
      </select>
      <ChevronDown size={13} />
    </label>
  );
}
export function Pages({ data, page, setPage }) {
  const max = Math.max(1, Math.ceil(data.total / data.size));
  return (
    <div className="pagination">
      <span>
        {data.total
          ? `${fmt((page - 1) * data.size + 1)}–${fmt(Math.min(page * data.size, data.total))} of ${fmt(data.total)} records`
          : "0 records"}
      </span>
      <div>
        <button
          aria-label="Previous page"
          disabled={page <= 1}
          onClick={() => setPage(page - 1)}
        >
          <ChevronLeft size={15} />
        </button>
        <b>{page}</b>
        <span>of {max}</span>
        <button
          aria-label="Next page"
          disabled={page >= max}
          onClick={() => setPage(page + 1)}
        >
          <ChevronRight size={15} />
        </button>
      </div>
    </div>
  );
}
export function Table({
  cols,
  rows,
  onRow,
  keyField = "id",
  empty = "No records match this view.",
}) {
  if (!rows.length) return <Empty text={empty} />;
  return (
    <div className="table-scroll">
      <table>
        <thead>
          <tr>
            {cols.map((col, i) => (
              <th key={i} style={{ textAlign: col.align }}>
                {col.label}
              </th>
            ))}
            {onRow && <th />}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr
              key={r[keyField] ?? i}
              className={onRow ? "clickrow" : ""}
              onClick={onRow ? () => onRow(r) : undefined}
              tabIndex={onRow ? 0 : undefined}
              onKeyDown={(e) => {
                if (onRow && e.key === "Enter") onRow(r);
              }}
            >
              {cols.map((col, j) => (
                <td key={j} style={{ textAlign: col.align }}>
                  {col.render
                    ? col.render(r)
                    : typeof r[col.key] === "boolean"
                      ? r[col.key]
                        ? "Yes"
                        : "No"
                      : String(r[col.key] ?? "—")}
                </td>
              ))}
              {onRow && (
                <td className="row-arrow">
                  <ChevronRight size={15} />
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export function PanelHead({ title, subtitle, action }) {
  return (
    <div className="panelhead">
      <div>
        <h2>{title}</h2>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}
export function Modal({
  title,
  subtitle,
  children,
  onClose,
  wide = false,
  className = "",
}) {
  const ref = useRef(null);
  useEffect(() => {
    let prev = document.activeElement;
    let orig = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    requestAnimationFrame(() => ref.current?.focus());
    const h = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab") {
        let es = [
          ...ref.current.querySelectorAll(
            'button:not(:disabled),input:not(:disabled),select,textarea,[tabindex="0"]',
          ),
        ];
        if (!es.length) return;
        if (e.shiftKey && document.activeElement === es[0]) {
          e.preventDefault();
          es.at(-1).focus();
        } else if (!e.shiftKey && document.activeElement === es.at(-1)) {
          e.preventDefault();
          es[0].focus();
        }
      }
    };
    document.addEventListener("keydown", h);
    return () => {
      document.removeEventListener("keydown", h);
      document.body.style.overflow = orig;
      prev?.focus?.();
    };
  }, []);
  return (
    <div
      className="overlay"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <section
        className={"modal " + (wide ? "wide " : "") + className}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        ref={ref}
        tabIndex={-1}
      >
        <div className="modalhead">
          <div>
            <h2>{title}</h2>
            {subtitle && <p>{subtitle}</p>}
          </div>
          <IconButton icon={X} label="Close dialog" onClick={onClose} />
        </div>
        <div className="modalbody">{children}</div>
      </section>
    </div>
  );
}
export function Field({ label, children, hint }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
      {hint && <small>{hint}</small>}
    </label>
  );
}
export function KV({ items }) {
  return (
    <dl className="kv">
      {items.map(([k, v]) => (
        <div key={k}>
          <dt>{k}</dt>
          <dd>{v ?? "—"}</dd>
        </div>
      ))}
    </dl>
  );
}
export function Tabs({ items, active, onChange }) {
  return (
    <div className="tabs" role="tablist">
      {items.map((it) => (
        <button
          key={it}
          role="tab"
          aria-selected={active === it}
          className={active === it ? "active" : ""}
          onClick={() => onChange(it)}
        >
          {it}
        </button>
      ))}
    </div>
  );
}
export function ConfirmAction({
  title,
  text,
  button = "Confirm",
  onConfirm,
  danger = false,
  remarks = false,
}) {
  const { close, notify, refresh } = useApp();
  const [busy, sb] = useState(false),
    [err, se] = useState(""),
    [note, sn] = useState(""),
    [ack, sa] = useState(false);
  return (
    <Modal title={title} subtitle="Authorised academic action" onClose={close}>
      <div className="confirm-emblem">
        <ShieldCheck size={26} />
      </div>
      <p className="bodycopy">{text}</p>
      {remarks && (
        <Field label="Decision remarks">
          <textarea
            value={note}
            onChange={(e) => sn(e.target.value)}
            placeholder="Record the reason for this decision…"
            rows={3}
          />
        </Field>
      )}
      <label className="checkline">
        <input
          type="checkbox"
          checked={ack}
          onChange={(e) => sa(e.target.checked)}
        />
        I have reviewed this change and confirm the action.
      </label>
      {err && <Notice kind="error">{err}</Notice>}
      <div className="dialogactions">
        <Button onClick={close}>Cancel</Button>
        <Button
          disabled={!ack || busy || (remarks && note.trim().length < 3)}
          kind={danger ? "danger" : "primary"}
          icon={busy ? LoaderCircle : Check}
          onClick={async () => {
            sb(true);
            try {
              const r = await onConfirm(note);
              notify(r?.status || "Changes saved");
              refresh();
              close();
            } catch (e) {
              se(e.message);
            } finally {
              sb(false);
            }
          }}
        >
          {busy ? "Saving…" : button}
        </Button>
      </div>
    </Modal>
  );
}
export function ExportButton({
  report = "department",
  title = "Export report",
}) {
  const { notify } = useApp(),
    [open, so] = useState(false),
    [busy, sb] = useState(false);
  return (
    <div className="menuwrap">
      <Button icon={Download} onClick={() => so(!open)} disabled={busy}>
        {busy ? "Exporting…" : title}
        <ChevronDown size={12} />
      </Button>
      {open && (
        <>
          <div className="menu-dismiss" onClick={() => so(false)} />
          <div className="dropdown exportmenu">
            <div className="menucaption">DOWNLOAD AS</div>
            {[
              ["xlsx", "Excel workbook"],
              ["csv", "CSV spreadsheet"],
              ["pdf", "PDF document"],
            ].map(([fmt, label]) => (
              <button
                key={fmt}
                onClick={async () => {
                  so(false);
                  sb(true);
                  try {
                    await download(
                      "/reports/" + report + "/export?format=" + fmt,
                    );
                    notify(label + " downloaded");
                  } catch (e) {
                    notify(e.message, "error");
                  } finally {
                    sb(false);
                  }
                }}
              >
                <Download size={14} />
                {label}
                <small>.{fmt}</small>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
export function Initials({ name = "", color = 0 }) {
  return (
    <span className={"initials c" + (color % 6)}>
      {name
        .replace("Dr. ", "")
        .split(" ")
        .slice(0, 2)
        .map((x) => x[0])
        .join("")}
    </span>
  );
}
