import React, { useState, useMemo, useLayoutEffect, useRef } from "react";
import {
  UsersRound,
  BookOpen,
  ChartNoAxesColumnIncreasing,
  ClipboardCheck,
  ArrowUpRight,
  CalendarDays,
  Building2,
  ArrowRight,
  Layers3,
  Landmark,
  ChevronRight,
  Activity,
  Clock3,
  GraduationCap,
  Cpu,
  CircuitBoard,
  Cog,
  Zap,
  BrainCircuit,
  Database,
  CheckCheck,
  ShieldCheck,
  ChartPie,
  Info,
  Network,
  TrendingUp,
  ChartColumn,
  PanelTop,
  CalendarRange,
  ScanLine,
} from "lucide-react";
import {
  useApp,
  useLoad,
  State,
  Badge,
  Select,
  PanelHead,
  fmt,
  dayfmt,
  ExportButton,
  IconButton,
  Modal,
  KV,
  Button,
  Table,
} from "./ui";
const COLORS = {
  Regular: "#4168dc",
  Floating: "#36b5a2",
  Backlog: "#eeb568",
  Repeat: "#a28ada",
};
export const deptIcons = [Cpu, CircuitBoard, Cog, Zap, Building2, BrainCircuit];
export function DeptIcon({ i = 0 }) {
  const I = deptIcons[i % 6];
  return (
    <span className={"depticon c" + (i % 6)}>
      <I size={18} strokeWidth={1.7} />
    </span>
  );
}
function smooth(pts) {
  if (pts.length < 2) return "";
  let d = `M ${pts[0][0]},${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i],
      p1 = pts[i],
      p2 = pts[i + 1],
      p3 = pts[i + 2] || p2;
    d += ` C ${p1[0] + (p2[0] - p0[0]) / 6},${p1[1] + (p2[1] - p0[1]) / 6} ${p2[0] - (p3[0] - p1[0]) / 6},${p2[1] - (p3[1] - p1[1]) / 6} ${p2[0]},${p2[1]}`;
  }
  return d;
}
function Trend({ data, days, setDays }) {
  let [hover, sh] = useState(null);
  const plotRef = useRef(null);
  const [wh, setWH] = useState([580, 153]);
  useLayoutEffect(() => {
    const el = plotRef.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) =>
      setWH([
        Math.max(100, entry.contentRect.width),
        Math.max(120, entry.contentRect.height),
      ]),
    );
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  let [w, h] = wh;
  let left = 32,
    right = 8,
    top = 9,
    bottom = 24;
  let max = Math.max(
    100,
    Math.ceil(
      Math.max(...data.map((x) => Math.max(x.regular, x.floating))) / 100,
    ) * 100,
  );
  let px = (i) =>
      left + ((w - left - right) * i) / Math.max(1, data.length - 1),
    py = (v) => top + (h - top - bottom) * (1 - v / max);
  let a = data.map((p, i) => [px(i), py(p.regular)]),
    b = data.map((p, i) => [px(i), py(p.floating)]);
  const short = (d) =>
    new Date(d + "T12:00:00").toLocaleDateString("en-GB", {
      day: "numeric",
      month: "short",
    });
  return (
    <section className="panel trendpanel">
      <PanelHead
        title="Registration activity"
        subtitle="Daily course registrations across the school"
        action={
          <Select
            small
            label="Registration period"
            value={days}
            onChange={(v) => {
              setDays(+v);
              sh(null);
            }}
            options={[
              { value: 7, label: "Last 7 days" },
              { value: 14, label: "Last 14 days" },
              { value: 30, label: "Last 30 days" },
            ]}
          />
        }
      />
      <div className="chartlegend">
        <span>
          <i style={{ background: COLORS.Regular }} />
          Current semester
        </span>
        <span>
          <i style={{ background: COLORS.Floating }} />
          Floating
        </span>
      </div>
      <div className="chartplot" ref={plotRef}>
        <svg
          viewBox={`0 0 ${w} ${h}`}
          preserveAspectRatio="none"
          role="img"
          aria-label="Daily regular and floating registration line chart"
          onMouseLeave={() => sh(null)}
        >
          <defs>
            <linearGradient id="bluearea" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#5279ed" stopOpacity=".18" />
              <stop offset="100%" stopColor="#5279ed" stopOpacity="0.015" />
            </linearGradient>
            <linearGradient id="mintarea" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#40c1a7" stopOpacity=".11" />
              <stop offset="100%" stopColor="#40c1a7" stopOpacity=".01" />
            </linearGradient>
          </defs>
          {[0, 1, 2, 3, 4].map((t) => (
            <g key={t}>
              <line
                x1={left}
                x2={w - right}
                y1={py((max * t) / 4)}
                y2={py((max * t) / 4)}
                stroke="#e6eaf1"
                strokeDasharray="3 4"
              />
              <text
                x={left - 10}
                y={py((max * t) / 4) + 3}
                textAnchor="end"
                className="axis"
              >
                {(max * t) / 4}
              </text>
            </g>
          ))}
          <path
            d={
              smooth(a) +
              ` L ${px(data.length - 1)},${py(0)} L ${left},${py(0)} Z`
            }
            fill="url(#bluearea)"
          />
          <path
            d={
              smooth(b) +
              ` L ${px(data.length - 1)},${py(0)} L ${left},${py(0)} Z`
            }
            fill="url(#mintarea)"
          />
          <path
            d={smooth(a)}
            fill="none"
            stroke={COLORS.Regular}
            strokeWidth="2.7"
            strokeLinecap="round"
            vectorEffect="non-scaling-stroke"
          />
          <path
            d={smooth(b)}
            fill="none"
            stroke={COLORS.Floating}
            strokeWidth="2.4"
            strokeLinecap="round"
            vectorEffect="non-scaling-stroke"
          />
          {data.map((d, i) => (
            <g key={d.date}>
              {(i % Math.ceil(data.length / 7) === 0 ||
                i === data.length - 1) && (
                <text
                  x={px(i)}
                  y={h - 3}
                  textAnchor={
                    i === data.length - 1 ? "end" : i === 0 ? "start" : "middle"
                  }
                  className="axis"
                >
                  {short(d.date)}
                </text>
              )}
              <rect
                x={px(i) - (w - left - right) / data.length / 2}
                y={0}
                width={(w - left - right) / data.length + 4}
                height={h - bottom}
                fill="transparent"
                onMouseEnter={() => sh(i)}
              >
                <title>
                  {short(d.date)}: {d.regular} regular, {d.floating} floating
                </title>
              </rect>
            </g>
          ))}
          {hover !== null && data[hover] && (
            <g pointerEvents="none">
              <line
                x1={px(hover)}
                x2={px(hover)}
                y1={top}
                y2={py(0)}
                stroke="#99a8c1"
                strokeDasharray="3 3"
              />
              <circle
                cx={px(hover)}
                cy={py(data[hover].regular)}
                r="4.5"
                fill={COLORS.Regular}
                stroke="white"
                strokeWidth="2"
              />
              <circle
                cx={px(hover)}
                cy={py(data[hover].floating)}
                r="4.5"
                fill={COLORS.Floating}
                stroke="white"
                strokeWidth="2"
              />
            </g>
          )}
        </svg>
        {hover !== null && data[hover] && (
          <div className="chart-tip">
            <b>{short(data[hover].date)}</b> Regular {data[hover].regular} ·
            Floating {data[hover].floating}
          </div>
        )}
      </div>
    </section>
  );
}
function Mix({ data }) {
  let total = data.reduce((a, r) => a + r.value, 0);
  let offset = 0;
  return (
    <section className="panel mixpanel">
      <PanelHead
        title="Registration mix"
        subtitle="Distribution by registration type"
        action={
          <span className="lighticon">
            <ChartPie size={18} />
          </span>
        }
      />
      <div className="donutlayout">
        <div className="donut">
          <svg
            viewBox="0 0 150 150"
            role="img"
            aria-label="Registration mix by category"
          >
            {data.map((r) => {
              const len = (r.value / total) * 100;
              const e = (
                <circle
                  key={r.basket}
                  cx="75"
                  cy="75"
                  r="61.5"
                  stroke={COLORS[r.basket]}
                  strokeWidth="19"
                  pathLength="100"
                  strokeDasharray={`${Math.max(0, len - 0.65)} ${100 - Math.max(0, len - 0.65)}`}
                  strokeDashoffset={-offset}
                  fill="none"
                  transform="rotate(-90 75 75)"
                >
                  <title>
                    {r.basket}: {fmt(r.value)}
                  </title>
                </circle>
              );
              offset += len;
              return e;
            })}
          </svg>
          <div className="donutvalue">
            <strong>{fmt(total)}</strong>
            <span>Registrations</span>
          </div>
        </div>
        <div className="mixlegend">
          {data.map((r) => (
            <div key={r.basket}>
              <span>
                <i style={{ background: COLORS[r.basket] }} />
                {r.basket}
              </span>
              <b>{((100 * r.value) / total).toFixed(1)}%</b>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
export function Dashboard() {
  const { user, version, navigate, open, close, notify } = useApp();
  const [days, setDays] = useState(7);
  const req = useLoad("/dashboard?days=" + days, version);
  return (
    <State req={req}>
      {(d) => {
        const s = d.stats;
        const cards = [
          {
            label: "Total students",
            value: fmt(s.students),
            icon: UsersRound,
            cl: "blue",
            foot: `Across ${s.departments} departments`,
            page: "students",
          },
          {
            label: "Course offerings",
            value: fmt(s.offerings),
            icon: BookOpen,
            cl: "teal",
            foot: `${s.published} published offerings`,
            page: "offerings",
          },
          {
            label: "Faculty utilisation",
            value: s.faculty_utilisation + "%",
            icon: ChartNoAxesColumnIncreasing,
            cl: "violet",
            foot: `${s.faculty} faculty in the pool`,
            page: "faculty",
          },
          {
            label: "Pending approvals",
            value: String(s.pending).padStart(2, "0"),
            icon: ClipboardCheck,
            cl: "amber",
            foot: "Awaiting academic review",
            page: "approvals",
          },
        ];
        return (
          <>
            <section className="hero">
              <div className="hero-grid" />
              <div className="hero-art" />
              <div className="herocopy">
                <div className="hero-eyebrow">
                  <span className="gold-line" />
                  {user.role === "Dean – SET"
                    ? "DEAN’S WORKSPACE"
                    : user.role.toUpperCase() + " WORKSPACE"}
                </div>
                <h1>Academic overview</h1>
                <p>School of Engineering &amp; Technology</p>
                <div className="herometa">
                  <span>
                    <CalendarDays size={13} />
                    Academic year {d.year}
                  </span>
                  <i />
                  <span>
                    <Landmark size={14} />
                    SET
                  </span>
                </div>
              </div>
            </section>
            <div className="sectionline">
              <h2>At a glance</h2>
              <span className="date-label">
                <CalendarDays size={13} />
                {new Date().toLocaleDateString("en-GB", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}
              </span>
            </div>
            <div className="kpis">
              {cards.map((c) => (
                <button
                  key={c.label}
                  className="kpicard"
                  onClick={() => navigate(c.page)}
                >
                  <div className="kpirow">
                    <span className={"metric-icon " + c.cl}>
                      <c.icon size={18} strokeWidth={1.8} />
                    </span>
                    <span className="kpilabel">{c.label}</span>
                    <ArrowUpRight className="kpiarrow" size={14} />
                  </div>
                  <strong>{c.value}</strong>
                  <span className="kpifoot">
                    {c.cl === "amber" && <i className="dotgold" />}
                    {c.cl === "teal" && <i className="dotgreen" />}
                    {c.foot}
                  </span>
                </button>
              ))}
            </div>
            <div className="dashboardcharts">
              <Trend data={d.trend} days={days} setDays={setDays} />
              <Mix data={d.mix} />
            </div>
            <section className="panel deptpanel">
              <PanelHead
                title="Department overview"
                subtitle="A school-wide view of academic registration"
                action={
                  <button
                    className="textlink"
                    onClick={() =>
                      navigate("reports", { report: "department" })
                    }
                  >
                    View report <ArrowRight size={14} />
                  </button>
                }
              />
              <Table
                rows={d.departments}
                cols={[
                  {
                    label: "Department",
                    render: (r) => (
                      <div className="deptcell">
                        <DeptIcon i={r.id - 1} />
                        <div>
                          <b>{r.department}</b>
                          <small>{r.code}</small>
                        </div>
                      </div>
                    ),
                  },
                  { label: "Students", key: "students" },
                  { label: "Offerings", key: "offerings" },
                  { label: "Floating", key: "floating" },
                  {
                    label: "Registration progress",
                    render: (r) => (
                      <div className="progresscell">
                        <i>
                          <span
                            style={{
                              width:
                                Math.round(
                                  (100 * r.registered) /
                                    Math.max(r.students, 1),
                                ) + "%",
                            }}
                          />
                        </i>
                        <b>
                          {Math.round(
                            (100 * r.registered) / Math.max(r.students, 1),
                          )}
                          %
                        </b>
                      </div>
                    ),
                  },
                ]}
                onRow={(r) => navigate("students", { department: r.code })}
              />
            </section>
            <section className="insightstrip">
              <div>
                <span className="insighticon">
                  <ShieldCheck size={19} />
                </span>
                <b>Academic indicators</b>
              </div>
              {[
                [
                  s.regulations,
                  "Active regulations",
                  "regulation-distribution",
                ],
                [s.eligible_students, "Eligible students", "eligible"],
                [s.floating_eligible, "Floating eligible", "eligible"],
                [s.shortage, "Attendance shortages", "attendance"],
                [s.backlogs, "Students with backlogs", "backlogs"],
                [s.faculty_shortages, "Faculty shortages", "faculty-shortage"],
              ].map(([n, l, key]) => (
                <button
                  key={l}
                  onClick={() => navigate("reports", { report: key })}
                >
                  <strong>{fmt(n)}</strong>
                  <span>{l}</span>
                </button>
              ))}
            </section>
            <div className="pagefoot">
              <span>DSU Controlled Flexible Credit System</span>
              <span>
                <i className="dotgreen" /> Connected to academic database
              </span>
            </div>
          </>
        );
      }}
    </State>
  );
}
