import React, { useState, useEffect, useRef } from "react";
import {
  Settings2,
  Database,
  Upload,
  Download,
  ShieldCheck,
  BookOpen,
  Plus,
  Pencil,
  Archive,
  FileSpreadsheet,
  CheckCircle2,
  Clock3,
  FileText,
  ArrowRight,
  UsersRound,
  SlidersHorizontal,
  Check,
  FlaskConical,
  LockKeyhole,
  Layers3,
  FolderOpen,
  ScrollText,
} from "lucide-react";
import {
  useApp,
  useLoad,
  api,
  download,
  State,
  PageHead,
  PanelHead,
  Select,
  Button,
  Table,
  Pages,
  Tabs,
  Field,
  Modal,
  Notice,
  Empty,
  KV,
  Badge,
  ConfirmAction,
  Searchbox,
  tit,
  dayfmt,
  fmt,
} from "./ui";
const booleans = [
  "active",
  "conditional_allowed",
  "block_on_shortage",
  "block_unrelated",
  "elective",
  "approved",
  "recognise_credit",
  "lab_competent",
  "mandatory_for_degree",
];
const numeric = [
  "semesters",
  "number",
  "year",
  "floating_window",
  "attendance_threshold",
  "total_credits",
  "mandatory_credits",
  "elective_credits",
  "minimum_credits",
  "maximum_credits",
  "lecture",
  "tutorial",
  "practical",
  "credits",
  "maximum_hours",
  "other_hours",
  "weekday",
  "starts",
  "ends",
  "capacity",
];
const fmtval = (v) =>
  typeof v === "boolean"
    ? v
      ? "Yes"
      : "No"
    : Array.isArray(v)
      ? v.join(" → ")
      : String(v ?? "—");
export function Settings() {
  const { user, filters, open } = useApp();
  const [tab, st] = useState(filters.tab || "Master data");
  let tabs = [
    ...(user.permissions.some((p) => ["manage", "audit", "policy"].includes(p))
      ? ["Master data"]
      : []),
    "Data imports",
    ...(user.permissions.includes("audit") ? ["Audit trail"] : []),
    ...(user.permissions.includes("users") ? ["Accounts"] : []),
    "Workspace guide",
  ];
  useEffect(() => {
    if (!tabs.includes(tab)) st(tabs[0]);
  }, []);
  return (
    <>
      <PageHead
        eyebrow="WORKSPACE ADMINISTRATION"
        title="Workspace settings"
        subtitle="Manage academic configuration, validated imports and the institutional audit trail."
      />
      <section className="panel">
        <Tabs active={tab} onChange={st} items={tabs} />
        {tab === "Master data" ? (
          <Masters />
        ) : tab === "Data imports" ? (
          <Imports />
        ) : tab === "Audit trail" ? (
          <Audit />
        ) : tab === "Accounts" ? (
          <Accounts />
        ) : (
          <Guide />
        )}
      </section>
    </>
  );
}
function Masters() {
  const { user, open, version } = useApp();
  const [kind, sk] = useState("regulations"),
    [page, sp] = useState(1);
  let types = useLoad("/admin/masters"),
    req = useLoad(`/admin/masters/${kind}?page=${page}&size=12`, version);
  let schema = types.data?.items.find((x) => x.key === kind);
  return (
    <>
      <div className="filters">
        <Select
          label="Master collection"
          value={kind}
          onChange={(v) => {
            sk(v);
            sp(1);
          }}
          options={(types.data?.items || []).map((s) => ({
            value: s.key,
            label: tit(s.key),
          }))}
        />
        {schema?.editable ? (
          <Button
            icon={Plus}
            kind="primary"
            onClick={() => open(<MasterForm schema={schema} />)}
          >
            Add record
          </Button>
        ) : (
          <Badge tone="slate">Read-only access</Badge>
        )}
      </div>
      {kind === "regulations" && (
        <div className="insetnotice">
          <Notice>
            Each regulation maintains its own curriculum, eligibility rules and
            credit limits. Sample policies are not official DSU regulations.
          </Notice>
        </div>
      )}
      <State req={req}>
        {(d) => {
          let ks = ["id", ...(schema?.fields || [])]
            .filter(
              (k) =>
                ![
                  "priority_order",
                  "block_on_shortage",
                  "block_unrelated",
                  "conditional_allowed",
                  "attendance_threshold",
                ].includes(k),
            )
            .slice(0, 6);
          return (
            <>
              <Table
                rows={d.items}
                cols={ks.map((k) => ({
                  label: tit(k),
                  render: (r) =>
                    k === "active" ? (
                      <Badge>{r[k] ? "Active" : "Inactive"}</Badge>
                    ) : (
                      fmtval(r[k])
                    ),
                }))}
                onRow={(r) => open(<MasterForm schema={schema} row={r} />)}
              />
              <Pages data={d} page={page} setPage={sp} />
            </>
          );
        }}
      </State>
    </>
  );
}
function MasterForm({ schema, row }) {
  const { close, open, refresh, notify } = useApp();
  let [vals, sv] = useState({ ...row }),
    [err, se] = useState(""),
    [busy, sb] = useState(false);
  const readonly = !schema.editable;
  return (
    <Modal
      title={
        (row ? (readonly ? "View " : "Edit ") : "Create ") +
        tit(schema.key).toLowerCase()
      }
      subtitle={
        row ? "Stable record ID: " + row.id : "New academic master record"
      }
      onClose={close}
      wide
    >
      {readonly ? (
        <KV items={schema.fields.map((k) => [tit(k), fmtval(row[k])])} />
      ) : (
        <form
          className="formstack"
          onSubmit={async (e) => {
            e.preventDefault();
            sb(true);
            se("");
            let v = {};
            for (let k of schema.fields) {
              let x = vals[k];
              if (booleans.includes(k)) v[k] = x === true || x === "true";
              else if (x === "" || x == null) v[k] = null;
              else if (k === "priority_order")
                v[k] = Array.isArray(x)
                  ? x
                  : String(x)
                      .split(",")
                      .map((x) => x.trim());
              else if (
                k.endsWith("_id") ||
                numeric.includes(k) ||
                ["course_a", "course_b"].includes(k)
              )
                v[k] = Number(x);
              else v[k] = x;
            }
            if (!v.priority_order && schema.key === "regulations")
              v.priority_order = ["P1", "P2", "P3", "P4", "P5"];
            try {
              await api(
                `/admin/masters/${schema.key}` + (row ? "/" + row.id : ""),
                {
                  method: row ? "PUT" : "POST",
                  body: { values: v, confirm: true },
                },
              );
              notify("Master data saved and audited");
              refresh();
              close();
            } catch (x) {
              se(x.message);
            } finally {
              sb(false);
            }
          }}
        >
          <div className="formgrid">
            {schema.fields.map((k) => (
              <Field
                key={k}
                label={tit(k)}
                hint={
                  k === "floating_window"
                    ? "0 = current only; 1 = current + next"
                    : k.endsWith("_id")
                      ? "Use the stable ID from the related master collection."
                      : null
                }
              >
                {booleans.includes(k) ? (
                  <select
                    value={String(vals[k] ?? false)}
                    onChange={(e) =>
                      sv({ ...vals, [k]: e.target.value === "true" })
                    }
                  >
                    <option value="true">Yes</option>
                    <option value="false">No</option>
                  </select>
                ) : (
                  <input
                    type={
                      k.endsWith("_on") || k.startsWith("valid_")
                        ? "date"
                        : numeric.includes(k) ||
                            k.endsWith("_id") ||
                            ["course_a", "course_b"].includes(k)
                          ? "number"
                          : "text"
                    }
                    step="any"
                    value={
                      Array.isArray(vals[k])
                        ? vals[k].join(", ")
                        : (vals[k] ?? "")
                    }
                    placeholder={
                      k === "priority_order" ? "P1, P2, P3, P4, P5" : tit(k)
                    }
                    onChange={(e) => sv({ ...vals, [k]: e.target.value })}
                  />
                )}
              </Field>
            ))}
          </div>
          <label className="checkline">
            <input type="checkbox" required />I confirm this academic
            configuration change.
          </label>
          {err && <Notice kind="error">{err}</Notice>}
          <div className="dialogactions">
            <Button onClick={close}>Cancel</Button>
            {row && schema.archivable && (
              <Button
                kind="dangerlight"
                icon={Archive}
                onClick={() =>
                  open(
                    <ConfirmAction
                      title="Archive master record?"
                      text="This retires the record without deleting its stable identifier. Records with dependent academic history cannot be archived."
                      danger
                      remarks
                      button="Archive record"
                      onConfirm={(reason) =>
                        api(`/admin/masters/${schema.key}/${row.id}/archive`, {
                          method: "POST",
                          body: { reason, confirm: true },
                        })
                      }
                    />,
                  )
                }
              >
                Archive
              </Button>
            )}
            <Button type="submit" kind="primary" icon={Check} disabled={busy}>
              Save record
            </Button>
          </div>
        </form>
      )}
    </Modal>
  );
}
function Imports() {
  const { user, version, filters, refresh, notify, open, close } = useApp();
  const [kind, sk] = useState(filters.kind || "students"),
    [file, sf] = useState(null),
    [over, so] = useState(false),
    [preview, sp] = useState(null),
    [err, se] = useState(""),
    [busy, sb] = useState(false),
    [drag, sd] = useState(false);
  const ref = useRef();
  let req = useLoad("/imports");
  useEffect(() => {
    if (req.data?.items.length && !req.data.items.some((x) => x.key === kind))
      sk(req.data.items[0].key);
  }, [req.data]);
  function changeFile(f) {
    sf(f);
    sp(null);
    se("");
  }
  return (
    <State req={req}>
      {(d) =>
        !d.items.length ? (
          <Empty
            icon={LockKeyhole}
            title="Import access is role-restricted"
            text="Use a Super Administrator account for master imports, or an Examination Cell account for results and attendance. In this synthetic pilot, demo roles can be selected from your profile menu."
          />
        ) : (
          <div className="importarea">
            <div className="importsteps">
              <span className="active">
                <b>1</b> Choose file
              </span>
              <i />
              <span className={preview ? "active" : ""}>
                <b>2</b> Validate records
              </span>
              <i />
              <span className={preview?.committed ? "active" : ""}>
                <b>3</b> Confirm import
              </span>
            </div>
            <div className="importconfig">
              <Field label="Import profile">
                <Select
                  label="Import profile"
                  value={kind}
                  onChange={(v) => {
                    sk(v);
                    changeFile(null);
                  }}
                  options={d.items.map((r) => ({
                    value: r.key,
                    label: r.label,
                  }))}
                />
              </Field>
              <Button
                icon={Download}
                onClick={async () => {
                  try {
                    await download("/templates/" + kind);
                    notify("Excel template downloaded");
                  } catch (e) {
                    se(e.message);
                  }
                }}
              >
                Download template
              </Button>
            </div>
            <input
              type="file"
              ref={ref}
              hidden
              accept=".xlsx,.csv"
              onChange={(e) => changeFile(e.target.files?.[0])}
            />
            <button
              className={"dropzone " + (drag ? "dragging" : "")}
              onClick={() => ref.current.click()}
              onDragOver={(e) => {
                e.preventDefault();
                sd(true);
              }}
              onDragLeave={() => sd(false)}
              onDrop={(e) => {
                e.preventDefault();
                sd(false);
                changeFile(e.dataTransfer.files?.[0]);
              }}
            >
              <span className="uploadicon">
                {file ? <FileSpreadsheet size={29} /> : <Upload size={27} />}
              </span>
              <b>{file ? file.name : "Choose a file or drag it here"}</b>
              <span>
                {file
                  ? `${(file.size / 1024).toFixed(1)} KB · Click to replace`
                  : "Excel (.xlsx) or UTF-8 CSV · Up to 5 MB and 2,000 rows"}
              </span>
            </button>
            <label className="checkline">
              <input
                type="checkbox"
                checked={over}
                onChange={(e) => {
                  so(e.target.checked);
                  sp(null);
                }}
              />
              Allow reviewed updates to existing records
            </label>
            <Button
              kind="primary"
              icon={ShieldCheck}
              disabled={!file || busy}
              onClick={async () => {
                sb(true);
                se("");
                sp(null);
                let f = new FormData();
                f.append("file", file);
                try {
                  sp(
                    await api(`/imports/${kind}/preview?overwrite=${over}`, {
                      method: "POST",
                      body: f,
                    }),
                  );
                } catch (e) {
                  se(e.message);
                } finally {
                  sb(false);
                }
              }}
            >
              {busy ? "Validating…" : "Validate file"}
            </Button>
            {err && <Notice kind="error">{err}</Notice>}
            {preview && (
              <div className="importresult">
                <h3>Validation summary</h3>
                <div className="mini-kpis">
                  {["total", "valid", "failed", "duplicates"].map((k) => (
                    <div key={k}>
                      <strong>{preview[k]}</strong>
                      <span>{tit(k)}</span>
                    </div>
                  ))}
                </div>
                {preview.errors.length ? (
                  <>
                    <Notice kind="error">
                      No data was committed. Correct the following rows and
                      upload the file again.
                    </Notice>
                    <Table
                      rows={preview.errors}
                      cols={[
                        { label: "Spreadsheet row", key: "row" },
                        { label: "Validation issue", key: "message" },
                      ]}
                    />
                  </>
                ) : (
                  <>
                    <Notice kind="success">
                      All {preview.valid} records passed validation. Changes are
                      not applied until confirmed.
                    </Notice>
                    <Button
                      kind="primary"
                      icon={Check}
                      onClick={() =>
                        open(
                          <ConfirmAction
                            title="Commit validated import?"
                            text={`Commit ${preview.valid} validated ${kind} records from ${file.name}. Every row will be revalidated inside a single database transaction.`}
                            button="Commit import"
                            onConfirm={async () => {
                              let r = await api(
                                `/imports/${preview.batch_id}/commit`,
                                { method: "POST", body: { confirm: true } },
                              );
                              sp(null);
                              sf(null);
                              return { status: r.valid + " records imported" };
                            }}
                          />,
                        )
                      }
                    >
                      Review & commit import
                    </Button>
                  </>
                )}
              </div>
            )}
          </div>
        )
      }
    </State>
  );
}
function Audit() {
  const { version, open, close } = useApp();
  let [page, sp] = useState(1);
  const req = useLoad("/audit?page=" + page + "&size=15", version);
  return (
    <>
      <PanelHead
        title="Academic audit trail"
        subtitle="Append-only history of sensitive academic decisions"
      />
      <State req={req}>
        {(d) => (
          <>
            <Table
              rows={d.items}
              cols={[
                { label: "Action", key: "action" },
                { label: "Actor", key: "actor" },
                { label: "Record type", render: (r) => tit(r.entity) },
                {
                  label: "Timestamp",
                  render: (r) =>
                    new Date(r.recorded_at).toLocaleString("en-GB"),
                },
              ]}
              onRow={(r) =>
                open(
                  <Modal
                    title="Audit event"
                    subtitle={"Event #" + r.id}
                    onClose={close}
                  >
                    <KV
                      items={[
                        ["Action", r.action],
                        ["Actor", r.actor],
                        ["Entity", r.entity],
                        ["Record ID", r.entity_id],
                        ["Timestamp", new Date(r.recorded_at).toLocaleString()],
                      ]}
                    />
                    <pre className="jsonview">
                      {JSON.stringify(r.detail, null, 2)}
                    </pre>
                  </Modal>,
                )
              }
            />
            <Pages data={d} page={page} setPage={sp} />
          </>
        )}
      </State>
    </>
  );
}
function Accounts() {
  const { open, version } = useApp();
  let req = useLoad("/admin/users", version);
  return (
    <>
      <PanelHead
        title="User accounts"
        subtitle="Named accounts and role-scoped access"
        action={
          <div className="taglist">
            <Button icon={ShieldCheck} onClick={() => open(<DelegationForm />)}>
              Permissions
            </Button>
            <Button
              kind="primary"
              icon={Plus}
              onClick={() => open(<AccountForm />)}
            >
              Create account
            </Button>
          </div>
        }
      />
      <State req={req}>
        {(d) => (
          <Table
            rows={d.items}
            cols={[
              { label: "Display name", key: "name" },
              { label: "Username", key: "username" },
              { label: "Role", key: "role" },
              {
                label: "Account type",
                render: (r) => (
                  <Badge tone={r.demo ? "amber" : "blue"}>
                    {r.demo ? "Synthetic demo" : "Named account"}
                  </Badge>
                ),
              },
              {
                label: "Status",
                render: (r) => (
                  <Badge>{r.active ? "Active" : "Inactive"}</Badge>
                ),
              },
            ]}
          />
        )}
      </State>
    </>
  );
}
function AccountForm() {
  const { close, notify, refresh, lookup } = useApp();
  const [role, sr] = useState("Student"),
    [err, se] = useState("");
  return (
    <Modal
      title="Create user account"
      subtitle="Use a unique username and institution-approved access scope."
      onClose={close}
    >
      <form
        className="formstack"
        onSubmit={async (e) => {
          e.preventDefault();
          let f = new FormData(e.target);
          try {
            await api("/admin/users", {
              method: "POST",
              body: {
                name: f.get("name"),
                username: f.get("username"),
                password: f.get("password"),
                role,
                school_id: Number(f.get("school")) || null,
                department_id: Number(f.get("department")) || null,
                student_id: Number(f.get("student")) || null,
                faculty_id: Number(f.get("faculty")) || null,
                confirm: true,
              },
            });
            notify("Account created");
            refresh();
            close();
          } catch (x) {
            se(x.message);
          }
        }}
      >
        <Field label="Display name">
          <input name="name" required minLength={2} />
        </Field>
        <Field label="Username">
          <input name="username" required minLength={3} autoComplete="off" />
        </Field>
        <Field
          label="Initial password"
          hint="Minimum 12 characters. Deliver credentials through a secure channel."
        >
          <input
            type="password"
            name="password"
            required
            minLength={12}
            autoComplete="new-password"
          />
        </Field>
        <Field label="Role">
          <select value={role} onChange={(e) => sr(e.target.value)}>
            {[
              "Student",
              "Faculty",
              "Faculty Advisor",
              "HoD",
              "Dean – SET",
              "Registrar",
              "Examination Cell",
              "Super Administrator",
            ].map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </Field>
        {role === "Dean – SET" && (
          <Field label="School scope">
            <select name="school" required>
              {lookup.schools?.map((s) => (
                <option value={s.id} key={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </Field>
        )}
        <Field label="Department scope">
          <select name="department">
            <option value="">University-wide (authorised roles only)</option>
            {lookup.departments.map((x) => (
              <option key={x.id} value={x.id}>
                {x.name}
              </option>
            ))}
          </select>
        </Field>
        {role === "Student" && (
          <Field label="Stable student ID">
            <input required type="number" min="1" name="student" />
          </Field>
        )}
        {["Faculty", "Faculty Advisor"].includes(role) && (
          <Field label="Stable faculty ID">
            <input required type="number" min="1" name="faculty" />
          </Field>
        )}
        <label className="checkline">
          <input required type="checkbox" />
          Confirm the assigned role and data scope.
        </label>
        {err && <Notice kind="error">{err}</Notice>}
        <div className="dialogactions">
          <Button type="submit" kind="primary">
            Create account
          </Button>
        </div>
      </form>
    </Modal>
  );
}
function Guide() {
  const { user, synthetic } = useApp();
  return (
    <div className="guide">
      <div className="detailbanner">
        <span className="metric-icon blue">
          <BookOpen size={23} />
        </span>
        <div>
          <span className="overline">DSU–CFCS HANDBOOK</span>
          <h2>Working in your academic workspace</h2>
        </div>
      </div>
      {synthetic && (
        <Notice>
          This isolated pilot uses synthetic students, sample curricula and
          illustrative policy values. No data is an official DSU academic
          record.
        </Notice>
      )}
      {[
        [
          "01",
          "Explore academic data",
          "Open a student record to review the regulation, verified transcript, attendance and credit progression. Faculty and advisors only see authorised students.",
        ],
        [
          "02",
          "Manage registration",
          "Select Registration to inspect each course’s current-semester, floating or recovery eligibility. Register or join a waitlist from a Student account. The backend rechecks every constraint at submission.",
        ],
        [
          "03",
          "Review academic exceptions",
          "Approvals displays the request, evidence and designated authority. Only an independent authorised reviewer may approve or reject a request. A conditional approval never waives mandatory requirements.",
        ],
        [
          "04",
          "Import verified records",
          "Choose a data profile, download its Excel template, populate configured master codes and validate. Review every row-level error. A confirmed import is atomic and logged.",
        ],
        [
          "05",
          "Report and reconcile",
          "Choose a report, inspect its scope, then download Excel, CSV or PDF. Restrict downloaded academic data to authorised personnel.",
        ],
      ].map(([n, h, p]) => (
        <article key={n}>
          <span>{n}</span>
          <div>
            <h3>{h}</h3>
            <p>{p}</p>
          </div>
        </article>
      ))}
      <a className="textlink" href="/docs" target="_blank" rel="noreferrer">
        Open API documentation <ArrowRight size={14} />
      </a>
    </div>
  );
}
function DelegationForm() {
  const { close, open } = useApp(),
    [role, sr] = useState("Faculty Advisor");
  const req = useLoad("/admin/permissions");
  return (
    <Modal
      title="Delegated permissions"
      subtitle="Academic scope checks remain mandatory even when a permission is granted."
      onClose={close}
    >
      <State req={req}>
        {(d) => (
          <>
            <Select
              label="Permission role"
              value={role}
              onChange={sr}
              options={d.roles
                .filter((r) => r.name !== "Super Administrator")
                .map((r) => r.name)}
            />
            <div className="permissionslist">
              {d.permissions.map((permission) => {
                let enabled = d.grants.some(
                  (g) => g.role === role && g.permission === permission,
                );
                return (
                  <div key={permission}>
                    <span>{tit(permission)}</span>
                    <Badge tone={enabled ? "green" : "slate"}>
                      {enabled ? "Granted" : "Not granted"}
                    </Badge>
                    <button
                      className="textlink"
                      onClick={() =>
                        open(
                          <ConfirmAction
                            title={
                              (enabled ? "Revoke" : "Grant") +
                              " delegated permission?"
                            }
                            text={`${enabled ? "Revoke" : "Grant"} the ${permission} permission for ${role}. This applies to all accounts with this role and is recorded in the audit trail.`}
                            button={
                              enabled ? "Revoke permission" : "Grant permission"
                            }
                            onConfirm={() =>
                              api("/admin/permissions", {
                                method: "POST",
                                body: {
                                  role,
                                  permission,
                                  grant: !enabled,
                                  confirm: true,
                                },
                              })
                            }
                          />,
                        )
                      }
                    >
                      {enabled ? "Revoke" : "Grant"}
                    </button>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </State>
    </Modal>
  );
}
