import React, { useState, useEffect } from "react";
import {
  UsersRound,
  BookOpen,
  Layers3,
  Plus,
  Download,
  Upload,
  ArrowRight,
  CalendarDays,
  GraduationCap,
  ShieldCheck,
  ClipboardList,
  CheckCircle2,
  Clock3,
  Check,
  X,
  ArrowUpRight,
  UserRound,
  SlidersHorizontal,
  FileText,
  Search,
  LayoutGrid,
  ChevronRight,
  Send,
  Building2,
  NotebookTabs,
  Bookmark,
  ChartColumn,
  CalendarRange,
  ListChecks,
  TriangleAlert,
  Mail,
  HeartPulse,
  Filter,
  ArrowLeftRight,
  Database,
  BrainCircuit,
  ClipboardCheck,
  UserRoundCheck,
} from "lucide-react";
import {
  useApp,
  useLoad,
  api,
  download,
  State,
  Loading,
  Notice,
  Empty,
  PageHead,
  Select,
  Searchbox,
  Table,
  Pages,
  PanelHead,
  Badge,
  Button,
  IconButton,
  Initials,
  Modal,
  Tabs,
  Field,
  KV,
  ConfirmAction,
  ExportButton,
  tit,
  fmt,
  dayfmt,
  tm,
} from "./ui";
import { DeptIcon } from "./dashboard";
const qstr = (o) =>
  new URLSearchParams(
    Object.entries(o).filter(([k, v]) => v !== "" && v != null),
  ).toString();
const nums = (n) => Number(n);
const days = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
];
export function DataList({ kind }) {
  const { lookup, user, version, navigate, open, filters } = useApp();
  const [q, sq] = useState(""),
    [dept, sd] = useState(filters.department || ""),
    [reg, sr] = useState(""),
    [status, ss] = useState(filters.status || ""),
    [page, sp] = useState(1);
  useEffect(() => sp(1), [q, dept, reg, status]);
  const pages = {
    students: [
      "Student records",
      "Explore student profiles, academic progression and regulation mappings.",
      "Student directory",
      "/students",
    ],
    courses: [
      "Course catalogue",
      "Browse regulation-specific curricula, prerequisites and academic equivalences.",
      "Curriculum courses",
      "/courses",
    ],
    offerings: [
      "Course offerings",
      "Manage teaching sections, faculty allocations and publication readiness.",
      "Teaching sections",
      "/offerings",
    ],
    faculty: [
      "Faculty pool",
      "Explore teaching competencies, workload and cross-department capacity.",
      "Faculty directory",
      "/faculty/pool",
    ],
  };
  const [heading, sub, label, path] = pages[kind];
  const req = useLoad(
    path +
      "?" +
      qstr({ q, department: dept, regulation: reg, status, page, size: 12 }),
    version,
  );
  let columns = {
    students: [
      {
        label: "Student",
        render: (r) => (
          <div className="identitycell">
            <Initials name={r.name} color={r.id} />
            <div>
              <b>{r.name}</b>
              <small className="mono">{r.register_number}</small>
            </div>
          </div>
        ),
      },
      { label: "Department", key: "department" },
      {
        label: "Regulation",
        render: (r) => <Badge tone="slate">{r.regulation}</Badge>,
      },
      { label: "Semester", render: (r) => "Sem " + r.semester },
      { label: "CGPA", render: (r) => Number(r.cgpa || 0).toFixed(2) },
      { label: "Academic status", render: (r) => <Badge>{r.status}</Badge> },
    ],
    courses: [
      {
        label: "Course",
        render: (r) => (
          <div className="twoline">
            <b>{r.title}</b>
            <small className="mono">{r.code}</small>
          </div>
        ),
      },
      {
        label: "Regulation",
        render: (r) => <Badge tone="blue">{r.regulation}</Badge>,
      },
      { label: "Department", key: "department" },
      { label: "Semester", render: (r) => "Sem " + r.semester },
      { label: "Credits", render: (r) => <b>{Number(r.credits)}</b> },
      { label: "Category", key: "category" },
    ],
    offerings: [
      {
        label: "Course offering",
        render: (r) => (
          <div className="twoline">
            <b>{r.title}</b>
            <small>
              {r.code} · Section {r.section}
            </small>
          </div>
        ),
      },
      { label: "Department", key: "department" },
      { label: "Assigned faculty", key: "faculty" },
      {
        label: "Enrolment",
        render: (r) => (
          <div className="seatcell">
            <b>
              {r.enrolled} <em>/ {r.capacity}</em>
            </b>
            <i>
              <span style={{ width: (100 * r.enrolled) / r.capacity + "%" }} />
            </i>
          </div>
        ),
      },
      { label: "Status", render: (r) => <Badge>{r.status}</Badge> },
    ],
    faculty: [
      {
        label: "Faculty member",
        render: (r) => (
          <div className="identitycell">
            <Initials name={r.name} color={r.id} />
            <div>
              <b>{r.name}</b>
              <small>{r.staff_number}</small>
            </div>
          </div>
        ),
      },
      { label: "Department", key: "department" },
      { label: "Specialisation", key: "specialisation" },
      {
        label: "Weekly workload",
        render: (r) => (
          <span>
            {Number(r.allocated)} / {Number(r.maximum_hours)} hrs
          </span>
        ),
      },
      {
        label: "Remaining",
        render: (r) => (
          <Badge tone="green">
            {Number(r.maximum_hours) - Number(r.allocated)} hrs
          </Badge>
        ),
      },
      { label: "Sections", key: "sections" },
    ],
  }[kind];
  let onRow = (r) =>
    open(
      kind === "students" ? (
        <StudentDetail sid={r.id} />
      ) : kind === "courses" ? (
        <CourseDetail id={r.id} />
      ) : kind === "faculty" ? (
        <FacultyDetail id={r.id} />
      ) : (
        <OfferingDetail id={r.id} />
      ),
    );
  return (
    <>
      <PageHead
        eyebrow={
          kind === "students" ? "STUDENT WORKSPACE" : "ACADEMIC MANAGEMENT"
        }
        title={heading}
        subtitle={sub}
        action={
          kind === "offerings" && user.permissions.includes("publish") ? (
            <Button
              kind="primary"
              icon={Plus}
              onClick={() => open(<OfferForm />)}
            >
              Create offering
            </Button>
          ) : user.permissions.includes("manage") ? (
            <Button
              icon={Upload}
              onClick={() =>
                navigate("settings", {
                  tab: "Data imports",
                  kind: kind === "courses" ? "curriculum" : kind,
                })
              }
            >
              Import records
            </Button>
          ) : ["faculty", "offerings"].includes(kind) ? (
            <ExportButton
              report={
                kind === "faculty" ? "faculty-workload" : "section-strength"
              }
            />
          ) : null
        }
      />
      <section className="panel">
        <div className="listheadline">
          <h2>{label}</h2>
          {req.data && <span className="countpill">{fmt(req.data.total)}</span>}
        </div>
        <div className="filters">
          <Searchbox
            value={q}
            onChange={sq}
            placeholder={
              "Search " +
              (kind === "students"
                ? "name or register number…"
                : kind === "faculty"
                  ? "faculty or specialisation…"
                  : "course title or code…")
            }
          />
          <div className="filterright">
            <Select
              label="Department"
              value={dept}
              onChange={sd}
              options={[
                { value: "", label: "All departments" },
                ...(lookup.departments || []).map((d) => ({
                  value: d.code,
                  label: d.code,
                })),
              ]}
            />
            {["courses", "students"].includes(kind) && (
              <Select
                label="Regulation"
                value={reg}
                onChange={sr}
                options={[
                  { value: "", label: "All regulations" },
                  ...(lookup.regulations || []).map((r) => r.code),
                ]}
              />
            )}{" "}
            {kind === "offerings" && (
              <Select
                label="Offering status"
                value={status}
                onChange={ss}
                options={[
                  { value: "", label: "All statuses" },
                  "Published",
                  "Draft",
                  "Pending approval",
                  "Withdrawn",
                ]}
              />
            )}
          </div>
        </div>
        <State req={req}>
          {(data) => (
            <>
              <Table cols={columns} rows={data.items} onRow={onRow} />
              <Pages data={data} page={page} setPage={sp} />
            </>
          )}
        </State>
      </section>
    </>
  );
}
export function StudentDetail({ sid }) {
  const { close, navigate, user, open } = useApp();
  let [tab, st] = useState("Profile");
  const req = useLoad("/students/" + sid),
    audit = useLoad("/students/" + sid + "/credit-audit");
  return (
    <Modal
      title="Student academic record"
      subtitle="Verified profile and regulation-specific progression"
      onClose={close}
      wide
    >
      <State req={req}>
        {(s) => (
          <>
            <div className="profilehero">
              <Initials name={s.name} color={sid} />
              <div>
                <h2>{s.name}</h2>
                <p>
                  {s.register_number} <span>·</span> {s.programme_code}
                </p>
              </div>
              <Badge>{s.status}</Badge>
            </div>
            <Tabs
              items={["Profile", "Transcript", "Attendance", "Credit audit"]}
              active={tab}
              onChange={st}
            />
            {tab === "Profile" ? (
              <KV
                items={[
                  ["Department", s.department],
                  ["Programme", s.programme],
                  ["Applicable regulation", s.regulation],
                  ["Admission year", s.admission_year],
                  ["Current semester", "Semester " + s.semester],
                  ["CGPA", Number(s.cgpa).toFixed(2)],
                ]}
              />
            ) : tab === "Transcript" ? (
              <Table
                cols={[
                  { label: "Course", key: "title" },
                  { label: "Code", key: "code" },
                  {
                    label: "Credits",
                    render: (r) =>
                      r.outcome === "Passed" ? Number(r.credits) : 0,
                  },
                  { label: "Attempt", key: "attempt" },
                  {
                    label: "Result",
                    render: (r) => <Badge>{r.outcome}</Badge>,
                  },
                ]}
                rows={s.results}
              />
            ) : tab === "Attendance" ? (
              <Table
                cols={[
                  { label: "Course", key: "title" },
                  {
                    label: "Attendance",
                    render: (r) => r.attended + " / " + r.conducted,
                  },
                  {
                    label: "Percent",
                    render: (r) =>
                      ((100 * r.attended) / r.conducted).toFixed(1) + "%",
                  },
                  { label: "Status", render: (r) => <Badge>{r.status}</Badge> },
                ]}
                rows={s.attendance}
              />
            ) : (
              <State req={audit}>{(a) => <CreditSummary data={a} />}</State>
            )}
            <div className="dialogactions">
              {user.permissions.includes("policy") && (
                <Button
                  icon={ShieldCheck}
                  onClick={() => open(<ProgressionForm student={s} />)}
                >
                  Progression review
                </Button>
              )}
              <Button
                icon={CalendarDays}
                onClick={() => {
                  close();
                  navigate("timetable", { student_id: sid });
                }}
              >
                Student timetable
              </Button>
              <Button
                kind="primary"
                icon={ClipboardList}
                onClick={() => {
                  close();
                  navigate("registration", { student_id: sid });
                }}
              >
                View registration
              </Button>
            </div>
          </>
        )}
      </State>
    </Modal>
  );
}
function CreditSummary({ data: a }) {
  return (
    <div className="creditblock">
      <div className="mini-kpis">
        {[
          [a.earned, "Earned credits"],
          [a.registered, "Registered"],
          [a.pending, "Pending credits"],
          [a.target, "Degree target"],
        ].map(([n, l]) => (
          <div key={l}>
            <strong>{Number(n || 0)}</strong>
            <span>{l}</span>
          </div>
        ))}
      </div>
      <div className="degreebar">
        <i
          style={{
            width:
              Math.min(100, (100 * a.earned) / Math.max(a.target, 1)) + "%",
          }}
        />
      </div>
      <KV
        items={[
          ["Core credits earned", Number(a.mandatory_earned)],
          ["Elective credits earned", Number(a.elective_earned)],
          [
            "Approved credit range",
            `${Number(a.minimum)}–${Number(a.maximum)}`,
          ],
          [
            "Graduation eligibility",
            a.graduation_eligible ? "Requirements met" : "In progress",
          ],
        ]}
      />
      <Notice>{a.forecast}</Notice>
    </div>
  );
}
export function CourseDetail({ id }) {
  const { close } = useApp();
  const req = useLoad("/courses/" + id + "/prerequisites");
  return (
    <Modal
      title="Course information"
      subtitle="Curriculum, prerequisites and approved recognition"
      onClose={close}
      wide
    >
      <State req={req}>
        {(d) => (
          <>
            <div className="detailbanner">
              <span className="metric-icon blue">
                <BookOpen size={23} />
              </span>
              <div>
                <span className="overline">
                  {d.course.code} · {d.course.regulation}
                </span>
                <h2>{d.course.title}</h2>
              </div>
            </div>
            <KV
              items={[
                ["Programme", d.course.programme],
                ["Semester", d.course.semester],
                ["Credits", Number(d.course.credits)],
                [
                  "L–T–P",
                  `${d.course.lecture}–${d.course.tutorial}–${d.course.practical}`,
                ],
                ["Course category", d.course.category],
                ["Assessment scheme", d.course.assessment],
              ]}
            />
            <h3 className="subhead">Prerequisite requirements</h3>
            {d.groups.length ? (
              <Table
                rows={d.groups}
                cols={[
                  { label: "Group", key: "name" },
                  { label: "Requirement", key: "title" },
                  { label: "Condition", key: "operator" },
                  { label: "Type", key: "kind" },
                ]}
              />
            ) : (
              <Notice>
                No prerequisite groups are configured for this course.
              </Notice>
            )}
            <h3 className="subhead">Course equivalence matrix</h3>
            <Table
              rows={d.equivalences}
              cols={[
                { label: "Course code", key: "code" },
                { label: "Regulation", key: "regulation" },
                { label: "Validity", render: (r) => dayfmt(r.valid_until) },
                {
                  label: "Status",
                  render: (r) => (
                    <Badge>{r.approved ? "Approved" : "Pending"}</Badge>
                  ),
                },
              ]}
            />
          </>
        )}
      </State>
    </Modal>
  );
}
export function FacultyDetail({ id }) {
  const { close, navigate } = useApp();
  const req = useLoad("/faculty/" + id);
  return (
    <Modal
      title="Faculty profile"
      subtitle="Pooled teaching capacity and course competency"
      onClose={close}
      wide
    >
      <State req={req}>
        {(r) => (
          <>
            <div className="profilehero">
              <Initials name={r.name} color={r.id} />
              <div>
                <h2>{r.name}</h2>
                <p>
                  {r.staff_number} · {r.department}
                </p>
              </div>
            </div>
            <KV
              items={[
                ["Qualification", r.qualification],
                ["Specialisation", r.specialisation],
                [
                  "Weekly workload",
                  `${Number(r.allocated)} / ${Number(r.maximum_hours)} hours`,
                ],
                [
                  "Lab competency",
                  r.lab_competent ? "Approved" : "Not approved",
                ],
              ]}
            />
            <h3 className="subhead">Approved course competencies</h3>
            <div className="taglist">
              {r.courses.map((x) => (
                <Badge key={x.title} tone="blue">
                  {x.title}
                </Badge>
              ))}
            </div>
            <h3 className="subhead">Teaching assignments</h3>
            <Table
              rows={r.assignments}
              cols={[
                { label: "Course", key: "title" },
                { label: "Section", key: "section" },
                { label: "Students", key: "enrolled" },
                { label: "Status", render: (x) => <Badge>{x.status}</Badge> },
              ]}
            />
            <div className="dialogactions">
              <Button
                kind="primary"
                icon={CalendarDays}
                onClick={() => {
                  close();
                  navigate("timetable", { faculty_id: id });
                }}
              >
                View faculty timetable
              </Button>
            </div>
          </>
        )}
      </State>
    </Modal>
  );
}
export function OfferingDetail({ id }) {
  const { user, open, close, version } = useApp();
  const req = useLoad("/offerings/" + id, version);
  return (
    <Modal
      title="Teaching section"
      subtitle="Course delivery, resources and regulation mappings"
      onClose={close}
      wide
    >
      <State req={req}>
        {(o) => (
          <>
            <div className="detailbanner">
              <span className="metric-icon teal">
                <Layers3 size={22} />
              </span>
              <div>
                <span className="overline">
                  {o.code} · SECTION {o.section}
                </span>
                <h2>{o.title}</h2>
              </div>
              <Badge>{o.status}</Badge>
            </div>
            <KV
              items={[
                ["Department", o.department],
                ["Faculty", o.faculty || "Unassigned"],
                ["Section strength", `${o.enrolled} / ${o.capacity} seats`],
                ["Reserved seats", o.reserved_seats],
                [
                  "Recovery registration",
                  o.recovery_allowed ? "Allowed" : "Not allowed",
                ],
                ["Waitlist", o.waitlisted + " students"],
              ]}
            />
            <h3 className="subhead">Weekly timetable</h3>
            {o.slots.map((t) => (
              <div className="scheduleline" key={t.id}>
                <CalendarDays size={17} />
                <b>{days[t.weekday - 1]}</b>
                <span>
                  {tm(t.starts)} – {tm(t.ends)}
                </span>
                <Badge tone="slate">{t.room}</Badge>
              </div>
            ))}
            <h3 className="subhead">Independent academic mappings</h3>
            <Table
              rows={o.mapping_details}
              cols={[
                { label: "Regulation", key: "regulation" },
                { label: "Course", key: "code" },
                { label: "Credits", render: (r) => Number(r.credits) },
                { label: "Assessment", key: "assessment" },
              ]}
            />
            {user.role !== "Student" && (
              <div className="rosteraction">
                <Button
                  icon={UsersRound}
                  onClick={() =>
                    open(<ClassRoster section={o.section_id} title={o.title} />)
                  }
                >
                  View class roster
                </Button>
                {user.permissions.includes("publish") && (
                  <Button
                    icon={SlidersHorizontal}
                    onClick={() => open(<CapacityForm offering={o} />)}
                  >
                    Edit seat allocation
                  </Button>
                )}
              </div>
            )}
            {user.permissions.includes("publish") && (
              <div className="dialogactions">
                {o.status !== "Withdrawn" && (
                  <Button
                    onClick={() =>
                      open(
                        <ConfirmAction
                          title="Withdraw offering?"
                          text="This offering will be unavailable for registration. Existing preferences are retained. Active enrolments must be resolved first."
                          button="Withdraw offering"
                          danger
                          remarks
                          onConfirm={(remarks) =>
                            api(`/offerings/${id}/withdraw`, {
                              method: "POST",
                              body: { confirm: true, remarks },
                            })
                          }
                        />,
                      )
                    }
                  >
                    Withdraw
                  </Button>
                )}
                <Button
                  icon={UsersRound}
                  onClick={() => open(<FacultyAssign section={o.section_id} />)}
                >
                  Allocate faculty
                </Button>
                {["Draft", "Pending approval"].includes(o.status) && (
                  <Button
                    kind="primary"
                    icon={Check}
                    onClick={() =>
                      open(
                        <ConfirmAction
                          title="Publish course offering?"
                          text={
                            "Publish " +
                            o.title +
                            " after rechecking faculty competency, workload, room capacity and timetable conflicts."
                          }
                          button="Validate & publish"
                          onConfirm={() =>
                            api(`/offerings/${id}/publish`, {
                              method: "POST",
                              body: { confirm: true },
                            })
                          }
                        />,
                      )
                    }
                  >
                    Publish offering
                  </Button>
                )}
              </div>
            )}
          </>
        )}
      </State>
    </Modal>
  );
}
function FacultyAssign({ section }) {
  const { open, close } = useApp();
  const req = useLoad("/sections/" + section + "/suggestions");
  return (
    <Modal
      title="Suggested faculty allocations"
      subtitle="Only competent, available faculty within approved workload norms"
      onClose={close}
    >
      <State req={req}>
        {(d) =>
          d.items.length ? (
            d.items.map((f) => (
              <button
                className="pickrow"
                key={f.id}
                onClick={() =>
                  open(
                    <ConfirmAction
                      title="Confirm faculty allocation"
                      text={`Assign ${f.name} to this teaching section. The assignment is recorded in the academic audit log.`}
                      button="Approve allocation"
                      onConfirm={() =>
                        api("/faculty/assign", {
                          method: "POST",
                          body: {
                            section_id: section,
                            faculty_id: f.id,
                            confirm: true,
                          },
                        })
                      }
                    />,
                  )
                }
              >
                <Initials name={f.name} />
                <span>
                  <b>{f.name}</b>
                  <small>
                    {f.department} ·{" "}
                    {Number(f.maximum_hours) - Number(f.allocated)} hours
                    remaining
                  </small>
                </span>
                <ChevronRight size={16} />
              </button>
            ))
          ) : (
            <Empty
              title="No compatible faculty"
              text="Review competency, availability and workload master data."
            />
          )
        }
      </State>
    </Modal>
  );
}
function OfferForm() {
  const { close, refresh, notify, lookup } = useApp();
  const [q, sq] = useState(""),
    [course, sc] = useState(""),
    [busy, sb] = useState(false),
    [err, se] = useState("");
  const req = useLoad("/courses?size=50&q=" + encodeURIComponent(q)),
    fac = useLoad("/faculty/pool?size=100");
  return (
    <Modal
      title="Create course offering"
      subtitle="Save a draft section. Publication requires a separate authorised review."
      onClose={close}
    >
      <form
        className="formstack"
        onSubmit={async (e) => {
          e.preventDefault();
          let f = new FormData(e.target);
          let minute = (t) =>
            t.split(":").reduce((a, x) => a * 60 + Number(x), 0);
          sb(true);
          se("");
          try {
            let r = await api("/offerings", {
              method: "POST",
              body: {
                course_id: Number(f.get("course")),
                faculty_id: Number(f.get("faculty")) || null,
                section: f.get("section"),
                capacity: Number(f.get("capacity")),
                minimum_seats: Number(f.get("minimum")),
                reserved_seats: Number(f.get("reserved")),
                window_id: Number(f.get("window")),
                recovery_allowed: f.has("recovery"),
                slots: [
                  {
                    room_id: Number(f.get("room")),
                    weekday: Number(f.get("day")),
                    starts: minute(f.get("start")),
                    ends: minute(f.get("end")),
                    kind: f.get("kind"),
                  },
                ],
                confirm: true,
              },
            });
            notify("Draft offering created");
            refresh();
            close();
          } catch (x) {
            se(x.message);
          } finally {
            sb(false);
          }
        }}
      >
        <Searchbox
          value={q}
          onChange={sq}
          placeholder="Find a curriculum course…"
        />
        <Field label="Curriculum course">
          <select name="course" required defaultValue="">
            <option value="" disabled>
              Select a course and regulation
            </option>
            {req.data?.items.map((c) => (
              <option value={c.id} key={c.id}>
                {c.code} · {c.title} · {c.regulation}
              </option>
            ))}
          </select>
        </Field>
        <div className="formgrid">
          <Field label="Faculty member">
            <select name="faculty">
              <option value="">Assign later</option>
              {fac.data?.items.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name} · {f.department}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Section name">
            <input name="section" defaultValue="B" required />
          </Field>
          <Field label="Maximum seats">
            <input name="capacity" type="number" min="1" required />
          </Field>
          <Field label="Minimum seats">
            <input
              name="minimum"
              type="number"
              min="0"
              defaultValue="0"
              required
            />
          </Field>
          <Field label="Protected seats">
            <input
              name="reserved"
              type="number"
              min="0"
              defaultValue="0"
              required
            />
          </Field>
          <Field label="Classroom / laboratory">
            <select name="room" required>
              {lookup.rooms.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.code} · {x.capacity} seats
                </option>
              ))}
            </select>
          </Field>
          <Field label="Day">
            <select name="day">
              {days.map((d, i) => (
                <option key={d} value={i + 1}>
                  {d}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Teaching type">
            <select name="kind">
              {["Theory", "Practical", "Tutorial"].map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </Field>
          <Field label="Start time">
            <input type="time" name="start" required defaultValue="09:00" />
          </Field>
          <Field label="End time">
            <input type="time" name="end" required defaultValue="11:00" />
          </Field>
        </div>
        <Field label="Registration window">
          <select name="window" required>
            {lookup.windows.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </Field>
        <label className="checkline">
          <input type="checkbox" name="recovery" />
          Allow approved backlog and repeat registration
        </label>
        {err && <Notice kind="error">{err}</Notice>}
        <div className="dialogactions">
          <Button onClick={close}>Cancel</Button>
          <Button type="submit" kind="primary" disabled={busy}>
            Save draft offering
          </Button>
        </div>
      </form>
    </Modal>
  );
}
export function StudentPicker({ onChoose }) {
  const { close } = useApp();
  let [q, sq] = useState("");
  let req = useLoad("/students?size=8&q=" + encodeURIComponent(q));
  return (
    <Modal
      title="Choose a student"
      subtitle="Search within your authorised academic scope"
      onClose={close}
    >
      <Searchbox
        value={q}
        onChange={sq}
        placeholder="Student name or register number…"
      />
      <State req={req}>
        {(d) => (
          <div className="picklist">
            {d.items.length ? (
              d.items.map((s) => (
                <button
                  key={s.id}
                  className="pickrow"
                  onClick={() => {
                    onChoose(s);
                    close();
                  }}
                >
                  <Initials name={s.name} color={s.id} />
                  <span>
                    <b>{s.name}</b>
                    <small>
                      {s.register_number} · {s.department} · Sem {s.semester}
                    </small>
                  </span>
                  <ChevronRight size={15} />
                </button>
              ))
            ) : (
              <Empty />
            )}
          </div>
        )}
      </State>
    </Modal>
  );
}
export function Registration({ personal = false }) {
  const { user, version, open, filters, close, navigate } = useApp();
  let [sid, setSid] = useState(
      user.student_id || Number(filters.student_id) || null,
    ),
    [tab, st] = useState(personal ? "Academic profile" : "Eligible catalogue"),
    [view, sv] = useState("Available"),
    [q, sq] = useState("");
  let first = useLoad(!sid ? "/students?size=1" : null);
  useEffect(() => {
    if (!sid && first.data?.items[0]) setSid(first.data.items[0].id);
  }, [first.data]);
  let student = useLoad(sid ? "/students/" + sid : null, version),
    audit = useLoad(sid ? `/students/${sid}/credit-audit` : null, version),
    eligible = useLoad(sid ? `/students/${sid}/eligibility` : null, version),
    enrol = useLoad(sid ? "/registration/student/" + sid : null, version),
    prefs = useLoad(tab === "Preferences" ? "/preferences" : null, version);
  const canRegister = user.permissions.includes("register");
  return (
    <>
      <PageHead
        eyebrow="CONTROLLED FLEXIBLE CREDIT SYSTEM"
        title={
          personal
            ? "My academic overview"
            : user.role === "Student"
              ? "My registration"
              : "Registration desk"
        }
        subtitle={
          personal
            ? "Your academic profile, degree progress and available learning pathways."
            : "Review eligibility, registered credits and recovery pathways for each student."
        }
        action={
          user.role !== "Student" ? (
            <Button
              icon={UsersRound}
              onClick={() =>
                open(<StudentPicker onChoose={(s) => setSid(s.id)} />)
              }
            >
              Change student
            </Button>
          ) : (
            <Button icon={CalendarDays} onClick={() => navigate("timetable")}>
              My timetable
            </Button>
          )
        }
      />
      {!sid ? (
        <Loading />
      ) : (
        <State req={student}>
          {(s) => (
            <>
              <div className="studentbanner">
                <Initials name={s.name} color={sid} />
                <div>
                  <div className="overline">STUDENT ACADEMIC RECORD</div>
                  <h2>{s.name}</h2>
                  <p>
                    {s.register_number} · {s.dept_code} · Semester {s.semester}
                  </p>
                </div>
                <div className="studentbadges">
                  <Badge tone="blue">{s.regulation}</Badge>
                  <Badge>{s.status}</Badge>
                </div>
              </div>
              <div className="mini-kpis regkpis">
                {[
                  [audit.data?.earned, "Earned credits"],
                  [audit.data?.registered, "Registered credits"],
                  [audit.data?.pending, "Pending degree credits"],
                  [
                    eligible.data?.items.filter((x) => x.status === "Eligible")
                      .length,
                    "Eligible courses",
                  ],
                ].map(([v, l]) => (
                  <div key={l}>
                    <span>{l}</span>
                    <strong>{v == null ? "—" : Number(v)}</strong>
                  </div>
                ))}
              </div>
              <section className="panel">
                <Tabs
                  items={[
                    ...(personal ? ["Academic profile"] : []),
                    "Eligible catalogue",
                    "Registered courses",
                    "Credit audit",
                    "Preferences",
                  ]}
                  active={tab}
                  onChange={st}
                />
                {tab === "Academic profile" ? (
                  <div className="panelpad">
                    <KV
                      items={[
                        ["Programme", s.programme],
                        ["Regulation", s.regulation],
                        ["Semester", s.semester],
                        ["CGPA", s.cgpa],
                        ["Admission year", s.admission_year],
                        [
                          "Floating window",
                          `Semester ${s.semester}${s.semester < s.semesters ? " + " + (s.semester + 1) : " and pending graduation requirements"}`,
                        ],
                      ]}
                    />
                    <Button
                      icon={NotebookTabs}
                      onClick={() => open(<StudentDetail sid={sid} />)}
                    >
                      Transcript & attendance
                    </Button>
                  </div>
                ) : tab === "Eligible catalogue" ? (
                  <>
                    <div className="filters">
                      <Searchbox
                        value={q}
                        onChange={sq}
                        placeholder="Find a course…"
                      />
                      <Select
                        label="Eligibility filter"
                        value={view}
                        onChange={sv}
                        options={[
                          "Available",
                          "All courses",
                          "Recovery",
                          "Blocked",
                          "Already completed",
                        ]}
                      />
                    </div>
                    <State req={eligible}>
                      {(d) => (
                        <div className="cataloguelist">
                          {d.items.filter(
                            (r) =>
                              (view === "All courses" ||
                                (view === "Available"
                                  ? [
                                      "Eligible",
                                      "Waitlisted",
                                      "Pending approval",
                                    ].includes(r.status)
                                  : view === "Recovery"
                                    ? ["Backlog", "Repeat"].includes(r.basket)
                                    : r.status === view)) &&
                              (r.title + " " + r.code)
                                .toLowerCase()
                                .includes(q.toLowerCase()),
                          ).length === 0 ? (
                            <Empty
                              title="No courses in this view"
                              text="Choose All courses to inspect every validation outcome."
                            />
                          ) : (
                            d.items
                              .filter(
                                (r) =>
                                  (view === "All courses" ||
                                    (view === "Available"
                                      ? [
                                          "Eligible",
                                          "Waitlisted",
                                          "Pending approval",
                                        ].includes(r.status)
                                      : view === "Recovery"
                                        ? ["Backlog", "Repeat"].includes(
                                            r.basket,
                                          )
                                        : r.status === view)) &&
                                  (r.title + " " + r.code)
                                    .toLowerCase()
                                    .includes(q.toLowerCase()),
                              )
                              .map((r) => (
                                <div className="cataloguerow" key={r.course_id}>
                                  <span
                                    className={
                                      "metric-icon " +
                                      (r.basket === "Floating"
                                        ? "violet"
                                        : "blue")
                                    }
                                  >
                                    <BookOpen size={19} />
                                  </span>
                                  <div className="coursecopy">
                                    <div className="coursemeta">
                                      {r.code} <span>·</span> Sem {r.semester}{" "}
                                      <span>·</span> {Number(r.credits)} credits
                                    </div>
                                    <h3>{r.title}</h3>
                                    <p>{r.reason}</p>
                                    <div className="taglist">
                                      <Badge>
                                        {r.existing_status || r.status}
                                      </Badge>
                                      <Badge tone="slate">{r.basket}</Badge>
                                    </div>
                                  </div>
                                  {canRegister &&
                                  ["Eligible", "Waitlisted"].includes(
                                    r.status,
                                  ) ? (
                                    <Button
                                      kind="primary"
                                      onClick={() =>
                                        open(
                                          <ConfirmAction
                                            title={
                                              r.status === "Waitlisted"
                                                ? "Join the waitlist?"
                                                : "Confirm course registration"
                                            }
                                            text={`${s.name} · ${r.title} (${r.code}), ${Number(r.credits)} credits. Basket: ${r.basket}. The system will revalidate all academic and seat constraints before saving.`}
                                            button={
                                              r.status === "Waitlisted"
                                                ? "Join waitlist"
                                                : "Register course"
                                            }
                                            onConfirm={() =>
                                              api("/registration/submit", {
                                                method: "POST",
                                                body: {
                                                  student_id: sid,
                                                  course_id: r.course_id,
                                                  section_id: r.section_id,
                                                  basket: [
                                                    "Backlog",
                                                    "Repeat",
                                                  ].includes(r.basket)
                                                    ? "Recovery"
                                                    : "Normal",
                                                  confirm: true,
                                                },
                                              })
                                            }
                                          />,
                                        )
                                      }
                                    >
                                      {r.status === "Waitlisted"
                                        ? "Join waitlist"
                                        : "Register"}
                                    </Button>
                                  ) : r.status === "Pending approval" &&
                                    user.permissions.includes("requests") ? (
                                    <Button
                                      onClick={() =>
                                        open(
                                          <RequestForm
                                            sid={sid}
                                            course={r.course_id}
                                          />,
                                        )
                                      }
                                    >
                                      Request review
                                    </Button>
                                  ) : null}
                                </div>
                              ))
                          )}
                        </div>
                      )}
                    </State>
                  </>
                ) : tab === "Registered courses" ? (
                  <State req={enrol}>
                    {(d) => (
                      <>
                        <Table
                          cols={[
                            {
                              label: "Course",
                              render: (r) => (
                                <div className="twoline">
                                  <b>{r.title}</b>
                                  <small>{r.code}</small>
                                </div>
                              ),
                            },
                            { label: "Basket", key: "basket" },
                            {
                              label: "Credits",
                              render: (r) => Number(r.credits),
                            },
                            {
                              label: "Status",
                              render: (r) => <Badge>{r.status}</Badge>,
                            },
                            {
                              label: "",
                              render: (r) =>
                                canRegister &&
                                ["Registered", "Waitlisted"].includes(
                                  r.status,
                                ) ? (
                                  <button
                                    className="textlink red-text"
                                    onClick={() =>
                                      open(
                                        <ConfirmAction
                                          title="Drop course registration?"
                                          danger
                                          text={`Remove ${r.title} from the active load. Any released seat will be offered to the next eligible waitlisted student.`}
                                          button="Confirm drop"
                                          remarks
                                          onConfirm={(remarks) =>
                                            api(`/registration/${r.id}/drop`, {
                                              method: "POST",
                                              body: { confirm: true, remarks },
                                            })
                                          }
                                        />,
                                      )
                                    }
                                  >
                                    Drop
                                  </button>
                                ) : null,
                            },
                          ]}
                          rows={d.items}
                        />
                        {canRegister && (
                          <div className="panelpad">
                            <Button
                              onClick={() =>
                                open(
                                  <ConfirmAction
                                    title="Finalise academic load"
                                    text="Confirm your selected courses. The regulation-specific minimum credit requirement will be checked and the decision recorded."
                                    onConfirm={() =>
                                      api(`/students/${sid}/finalise`, {
                                        method: "POST",
                                        body: { confirm: true },
                                      })
                                    }
                                  />,
                                )
                              }
                            >
                              Finalise credit load
                            </Button>
                          </div>
                        )}
                      </>
                    )}
                  </State>
                ) : tab === "Credit audit" ? (
                  <div className="panelpad">
                    <State req={audit}>
                      {(a) => <CreditSummary data={a} />}
                    </State>
                  </div>
                ) : (
                  <State req={prefs}>
                    {(d) => (
                      <>
                        <Table
                          rows={d.items.filter((x) => x.student_id === sid)}
                          cols={[
                            { label: "Rank", key: "rank" },
                            { label: "Preferred course", key: "title" },
                            { label: "Code", key: "code" },
                            { label: "Interest", key: "interest" },
                          ]}
                        />
                        {user.permissions.includes("preferences") && (
                          <div className="panelpad">
                            <Button
                              icon={Plus}
                              onClick={() =>
                                open(
                                  <PreferenceForm
                                    sid={sid}
                                    courses={eligible.data?.items || []}
                                  />,
                                )
                              }
                            >
                              Set course preference
                            </Button>
                          </div>
                        )}
                      </>
                    )}
                  </State>
                )}
              </section>
            </>
          )}
        </State>
      )}
    </>
  );
}
function PreferenceForm({ sid, courses }) {
  const { close, refresh, notify } = useApp(),
    [err, se] = useState("");
  return (
    <Modal
      title="Course preference"
      subtitle="Preferences express demand; they do not reserve a seat."
      onClose={close}
    >
      <form
        className="formstack"
        onSubmit={async (e) => {
          e.preventDefault();
          let f = new FormData(e.target);
          try {
            await api("/preferences", {
              method: "POST",
              body: {
                student_id: sid,
                course_id: Number(f.get("course")),
                rank: Number(f.get("rank")),
                interest: f.get("interest"),
                confirm: true,
              },
            });
            notify("Preference saved");
            refresh();
            close();
          } catch (x) {
            se(x.message);
          }
        }}
      >
        <Field label="Course">
          <select name="course">
            {courses.map((c) => (
              <option key={c.course_id} value={c.course_id}>
                {c.code} · {c.title}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Preference rank">
          <select name="rank">
            {[1, 2, 3].map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </Field>
        <Field label="Interest">
          <select name="interest">
            {["Core", "Floating", "Open elective"].map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </Field>
        <label className="checkline">
          <input required type="checkbox" />
          Replace any existing preference at this rank.
        </label>
        {err && <Notice kind="error">{err}</Notice>}
        <div className="dialogactions">
          <Button type="submit" kind="primary">
            Confirm preference
          </Button>
        </div>
      </form>
    </Modal>
  );
}
export function RequestForm({ sid, course }) {
  const { close, refresh, notify, user } = useApp();
  const [err, se] = useState(""),
    [busy, sb] = useState(false),
    [kind, sk] = useState("Conditional prerequisite"),
    [student, ss] = useState(sid || user.student_id || "");
  const students = useLoad(!student ? "/students?size=80" : null),
    courses = useLoad(student ? `/students/${student}/eligibility` : null);
  return (
    <Modal
      title="Request academic exception"
      subtitle="Submit supporting evidence for independent academic review."
      onClose={close}
    >
      <form
        className="formstack"
        onSubmit={async (e) => {
          e.preventDefault();
          sb(true);
          let f = new FormData(e.target);
          try {
            await api("/exceptions", {
              method: "POST",
              body: {
                student_id: Number(student),
                course_id: Number(f.get("course")) || null,
                kind,
                reason: f.get("reason"),
                evidence: f.get("evidence"),
                extra_credits: Number(f.get("extra") || 0),
                confirm: true,
              },
            });
            notify("Exception request submitted for review");
            refresh();
            close();
          } catch (x) {
            se(x.message);
          } finally {
            sb(false);
          }
        }}
      >
        {!sid && !user.student_id && (
          <Field label="Student">
            <select
              required
              value={student}
              onChange={(e) => ss(e.target.value)}
            >
              <option value="">Select student</option>
              {students.data?.items.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} · {s.register_number}
                </option>
              ))}
              {student && (
                <option value={student}>Selected student #{student}</option>
              )}
            </select>
          </Field>
        )}
        <Field label="Exception category">
          <select value={kind} onChange={(e) => sk(e.target.value)}>
            {[
              "Conditional prerequisite",
              "Credit overload",
              "Course equivalence",
              "Special offering",
              "Timetable",
              "Academic progression",
              "Attendance exception",
            ].map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </Field>
        <Field label="Course">
          <select name="course" defaultValue={course || ""}>
            <option value="">Student-wide request</option>
            {courses.data?.items.map((c) => (
              <option key={c.course_id} value={c.course_id}>
                {c.code} · {c.title}
              </option>
            ))}
          </select>
        </Field>
        {kind === "Credit overload" && (
          <Field label="Additional credits requested">
            <input type="number" name="extra" min="1" max="100" required />
          </Field>
        )}
        <Field label="Academic reason">
          <textarea
            name="reason"
            required
            minLength={8}
            rows={3}
            placeholder="Explain the reason for this request…"
          />
        </Field>
        <Field label="Supporting evidence reference">
          <input
            name="evidence"
            required
            minLength={3}
            placeholder="Advisor recommendation or document reference"
          />
        </Field>
        <Notice>
          Submitting a request does not override mandatory prerequisites or
          confirm registration.
        </Notice>
        {err && <Notice kind="error">{err}</Notice>}
        <div className="dialogactions">
          <Button onClick={close}>Cancel</Button>
          <Button
            type="submit"
            kind="primary"
            icon={Send}
            disabled={busy || !student}
          >
            Submit request
          </Button>
        </div>
      </form>
    </Modal>
  );
}
export function Approvals() {
  const { user, version, open } = useApp();
  const [tab, st] = useState("Academic exceptions"),
    [status, ss] = useState("Pending"),
    [page, sp] = useState(1);
  const req = useLoad(
    tab === "Academic exceptions"
      ? `/exceptions?status=${status}&page=${page}&size=12`
      : `/offerings?status=Pending%20approval&page=${page}&size=12`,
    version,
  );
  return (
    <>
      <PageHead
        eyebrow="ACADEMIC GOVERNANCE"
        title={user.role === "Student" ? "My requests" : "Approval centre"}
        subtitle="Review academic requests, supporting evidence and school-level course offerings."
        action={
          user.permissions.includes("requests") && (
            <Button
              kind="primary"
              icon={Plus}
              onClick={() => open(<RequestForm />)}
            >
              New request
            </Button>
          )
        }
      />
      <section className="panel">
        <Tabs
          active={tab}
          items={[
            "Academic exceptions",
            ...(user.role !== "Student" ? ["Offering approvals"] : []),
          ]}
          onChange={(v) => {
            st(v);
            sp(1);
          }}
        />
        <div className="filters">
          <h3>
            {tab === "Academic exceptions"
              ? "Exception register"
              : "Pending publication"}
          </h3>
          {tab === "Academic exceptions" && (
            <Select
              label="Request status"
              value={status}
              onChange={(v) => {
                ss(v);
                sp(1);
              }}
              options={[
                { value: "", label: "All decisions" },
                "Pending",
                "Approved",
                "Rejected",
              ]}
            />
          )}
        </div>
        <State req={req}>
          {(d) => (
            <>
              <Table
                rows={d.items}
                cols={
                  tab === "Academic exceptions"
                    ? [
                        {
                          label: "Request",
                          render: (r) => (
                            <div className="twoline">
                              <b>{r.kind}</b>
                              <small>REQ-{String(r.id).padStart(4, "0")}</small>
                            </div>
                          ),
                        },
                        {
                          label: "Student",
                          render: (r) => (
                            <div className="twoline">
                              <b>{r.student}</b>
                              <small>{r.register_number}</small>
                            </div>
                          ),
                        },
                        { label: "Department", key: "department" },
                        { label: "Authority", key: "authority" },
                        {
                          label: "Status",
                          render: (r) => <Badge>{r.status}</Badge>,
                        },
                      ]
                    : [
                        { label: "Course", key: "title" },
                        { label: "Code", key: "code" },
                        { label: "Department", key: "department" },
                        { label: "Faculty", key: "faculty" },
                        {
                          label: "Status",
                          render: (r) => <Badge>{r.status}</Badge>,
                        },
                      ]
                }
                onRow={(r) =>
                  open(
                    tab === "Academic exceptions" ? (
                      <ExceptionDetail row={r} />
                    ) : (
                      <OfferingDetail id={r.id} />
                    ),
                  )
                }
              />
              <Pages data={d} page={page} setPage={sp} />
            </>
          )}
        </State>
      </section>
    </>
  );
}
function ExceptionDetail({ row: r }) {
  const { user, close, open } = useApp();
  const can =
    user.permissions.includes("review") &&
    [r.authority, "Super Administrator"].includes(user.role) &&
    r.requested_by !== user.id;
  let decide = (decision) =>
    open(
      <ConfirmAction
        title={
          decision === "Approved"
            ? "Approve academic exception?"
            : "Reject academic exception?"
        }
        text={`${r.kind} for ${r.student}. This decision is scoped to this request and academic year. All other academic constraints remain in force.`}
        danger={decision === "Rejected"}
        remarks
        button={decision === "Approved" ? "Approve request" : "Reject request"}
        onConfirm={(remarks) =>
          api(`/exceptions/${r.id}/decision`, {
            method: "POST",
            body: { decision, remarks, confirm: true },
          })
        }
      />,
    );
  return (
    <Modal
      title={r.kind}
      subtitle={"Academic exception · REQ-" + String(r.id).padStart(4, "0")}
      onClose={close}
    >
      <div className="taglist">
        <Badge>{r.status}</Badge>
        <Badge tone="slate">{r.department}</Badge>
      </div>
      <KV
        items={[
          ["Student", r.student],
          ["Register number", r.register_number],
          ["Course", r.course || "Student-wide"],
          ["Approving authority", r.authority],
          ["Request date", dayfmt(r.requested_at)],
          ["Extra credits", Number(r.extra_credits)],
        ]}
      />
      <h3 className="subhead">Reason for request</h3>
      <p className="bodycopy">{r.reason}</p>
      <h3 className="subhead">Supporting evidence</h3>
      <div className="evidence">
        <FileText size={17} />
        {r.evidence}
      </div>
      {r.status === "Pending" ? (
        can ? (
          <div className="dialogactions">
            <Button kind="dangerlight" onClick={() => decide("Rejected")}>
              Reject request
            </Button>
            <Button
              kind="primary"
              icon={Check}
              onClick={() => decide("Approved")}
            >
              Approve request
            </Button>
          </div>
        ) : (
          <Notice>
            This request awaits an independent decision from {r.authority}.
          </Notice>
        )
      ) : (
        <Notice>
          Decision recorded by {r.decision_maker} on {dayfmt(r.decided_at)}.{" "}
          {r.remarks}
        </Notice>
      )}
    </Modal>
  );
}
export function Timetable() {
  const { filters, user, lookup, version, open, navigate } = useApp();
  let [dept, sd] = useState(filters.department || ""),
    [room, sr] = useState(""),
    [day, sdy] = useState(1),
    [mode, sm] = useState("Weekly schedule"),
    [faculty, sf] = useState(filters.faculty_id || ""),
    [sid, ss] = useState(filters.student_id || user.student_id || "");
  let req = useLoad(
    "/timetable?" +
      qstr({
        department: dept,
        room_id: room,
        faculty_id: faculty,
        student_id: sid,
      }),
    version,
  );
  const fac = useLoad("/faculty/pool?size=100");
  return (
    <>
      <PageHead
        eyebrow="ACADEMIC OPERATIONS"
        title="Academic timetable"
        subtitle="Published teaching schedules, coordinated across students, faculty and rooms."
        action={
          user.role !== "Student" && (
            <Button
              icon={UserRound}
              onClick={() => open(<StudentPicker onChoose={(s) => ss(s.id)} />)}
            >
              Student timetable
            </Button>
          )
        }
      />
      <section className="panel">
        <PanelHead
          title={
            sid
              ? "Student schedule"
              : faculty
                ? "Faculty schedule"
                : room
                  ? "Room schedule"
                  : "Teaching schedule"
          }
          subtitle="Academic year 2026–2027 · Weekly recurring timetable"
        />
        <div className="filters wrap">
          <Select
            label="Department"
            value={dept}
            onChange={sd}
            options={[
              { value: "", label: "All departments" },
              ...lookup.departments.map((x) => x.code),
            ]}
          />
          <Select
            label="Faculty"
            value={faculty}
            onChange={sf}
            options={[
              { value: "", label: "All faculty" },
              ...(fac.data?.items || []).map((x) => ({
                value: x.id,
                label: x.name + " · " + x.department,
              })),
            ]}
          />
          <Select
            label="Classroom"
            value={room}
            onChange={sr}
            options={[
              { value: "", label: "All classrooms" },
              ...lookup.rooms.map((x) => ({ value: x.id, label: x.code })),
            ]}
          />
          {sid && user.role !== "Student" && (
            <Button icon={X} onClick={() => ss("")}>
              Student #{sid}
            </Button>
          )}
        </div>
        <div className="weekdaytabs">
          {days.slice(0, 6).map((v, i) => (
            <button
              key={v}
              onClick={() => sdy(i + 1)}
              className={day === i + 1 ? "active" : ""}
            >
              <span>{v.slice(0, 3)}</span>
              <small>
                {req.data?.items.filter((x) => x.weekday === i + 1).length || 0}{" "}
                slots
              </small>
            </button>
          ))}
        </div>
        <State req={req}>
          {(d) => (
            <div className="slotlist">
              {d.items.filter((x) => x.weekday === day).length ? (
                d.items
                  .filter((x) => x.weekday === day)
                  .map((t) => (
                    <button
                      key={t.id}
                      className="timeslot"
                      onClick={() =>
                        open(<OfferingDetail id={t.offering_id} />)
                      }
                    >
                      <div className="slottime">
                        <b>{tm(t.starts)}</b>
                        <span>{tm(t.ends)}</span>
                      </div>
                      <i />
                      <div>
                        <div className="coursemeta">
                          {t.code} · SECTION {t.section}
                        </div>
                        <h3>{t.title}</h3>
                        <p>
                          {t.faculty} · Room {t.room}
                        </p>
                      </div>
                      <Badge tone="blue">{t.department}</Badge>
                    </button>
                  ))
              ) : (
                <Empty
                  icon={CalendarDays}
                  title="No scheduled classes"
                  text="There are no published slots for this day and filter combination."
                />
              )}
            </div>
          )}
        </State>
      </section>
    </>
  );
}
export function Reports() {
  const { filters, version } = useApp();
  let [key, sk] = useState(filters.report || "registration"),
    [page, sp] = useState(1);
  let opts = useLoad("/reports");
  let req = useLoad(`/reports/${key}?page=${page}&size=15`, version);
  const chosen = opts.data?.items.find((x) => x.key === key);
  let cards = [
    ["registration", "Registration register", ClipboardList, "blue"],
    ["course-demand", "Course demand", ChartColumn, "teal"],
    ["faculty-workload", "Faculty workload", UsersRound, "violet"],
    ["graduation-risk", "Graduation risk", ShieldCheck, "amber"],
  ];
  return (
    <>
      <PageHead
        eyebrow="INSIGHTS & GOVERNANCE"
        title="Reports & analytics"
        subtitle="Explore scoped academic reports and export verified data for review."
        action={<ExportButton report={key} />}
      />
      <div className="reporttiles">
        {cards
          .filter((c) => opts.data?.items.some((o) => o.key === c[0]))
          .map(([k, l, I, col]) => (
            <button
              key={k}
              className={"reporttile " + (key === k ? "chosen" : "")}
              onClick={() => {
                sk(k);
                sp(1);
              }}
            >
              <span className={"metric-icon " + col}>
                <I size={19} />
              </span>
              <b>{l}</b>
              <ArrowUpRight size={14} />
            </button>
          ))}
      </div>
      <section className="panel">
        <PanelHead
          title={chosen?.label || "Academic report"}
          subtitle="Live data · Current academic year"
          action={
            <Select
              label="Choose report"
              value={key}
              onChange={(v) => {
                sk(v);
                sp(1);
              }}
              options={(opts.data?.items || []).map((x) => ({
                value: x.key,
                label: x.label,
              }))}
            />
          }
        />
        <State req={req}>
          {(d) => {
            let keys = Object.keys(d.items[0] || {})
              .filter(
                (k) =>
                  k !== "id" &&
                  !k.endsWith("_id") &&
                  ![
                    "created_at",
                    "staff_number",
                    "lab_competent",
                    "qualification",
                    "maximum_hours",
                    "other_hours",
                    "repeat_approved",
                    "recovery_allowed",
                    "mappings",
                  ].includes(k),
              )
              .slice(0, 7);
            return (
              <>
                <Table
                  rows={d.items}
                  cols={keys.map((k) => ({
                    label: tit(k),
                    key: k,
                    render: (r) =>
                      k === "status" ? (
                        <Badge>{r[k]}</Badge>
                      ) : typeof r[k] === "number" ? (
                        fmt(r[k])
                      ) : (
                        String(r[k] ?? "—")
                      ),
                  }))}
                  empty="No records meet this report’s criteria."
                />
                <Pages data={d} page={page} setPage={sp} />
              </>
            );
          }}
        </State>
      </section>
    </>
  );
}
function ClassRoster({ section, title }) {
  const { user, version, close, open } = useApp();
  let [q, sq] = useState(""),
    [page, sp] = useState(1);
  const req = useLoad(
    `/sections/${section}/roster?${qstr({ q, page, size: 12 })}`,
    version,
  );
  return (
    <Modal
      wide
      title="Class roster"
      subtitle={title + " · Confirmed section registrations"}
      onClose={close}
    >
      <Searchbox
        value={q}
        onChange={(v) => {
          sq(v);
          sp(1);
        }}
        placeholder="Search enrolled students…"
      />
      <State req={req}>
        {(d) => (
          <>
            <Table
              rows={d.items}
              cols={[
                {
                  label: "Student",
                  render: (r) => (
                    <div className="twoline">
                      <b>{r.name}</b>
                      <small>{r.register_number}</small>
                    </div>
                  ),
                },
                { label: "Regulation", key: "regulation" },
                {
                  label: "Attendance",
                  render: (r) =>
                    r.conducted
                      ? `${r.attended} / ${r.conducted}`
                      : "Not recorded",
                },
                {
                  label: "Eligibility",
                  render: (r) => (
                    <Badge>{r.attendance_status || "Not assessed"}</Badge>
                  ),
                },
                ...(user.permissions.includes("attendance")
                  ? [
                      {
                        label: "",
                        render: (r) => (
                          <button
                            className="textlink"
                            onClick={() =>
                              open(<AttendanceForm row={r} section={section} />)
                            }
                          >
                            Record
                          </button>
                        ),
                      },
                    ]
                  : []),
              ]}
            />
            <Pages data={d} page={page} setPage={sp} />
          </>
        )}
      </State>
    </Modal>
  );
}
function AttendanceForm({ row, section }) {
  const { close, user, refresh, notify } = useApp();
  const [err, se] = useState(""),
    [busy, sb] = useState(false);
  return (
    <Modal
      title="Record course attendance"
      subtitle={`${row.name} · ${row.code} · ${row.regulation}`}
      onClose={close}
    >
      <form
        className="formstack"
        onSubmit={async (e) => {
          e.preventDefault();
          let f = new FormData(e.target);
          sb(true);
          try {
            await api("/attendance/record", {
              method: "POST",
              body: {
                student_id: row.id,
                section_id: section,
                attended: Number(f.get("attended")),
                conducted: Number(f.get("conducted")),
                status: f.get("status"),
                confirm: true,
              },
            });
            refresh();
            notify("Course attendance recorded");
            close();
          } catch (x) {
            se(x.message);
          } finally {
            sb(false);
          }
        }}
      >
        <div className="formgrid">
          <Field label="Classes attended">
            <input
              type="number"
              name="attended"
              min="0"
              defaultValue={row.attended}
              required
            />
          </Field>
          <Field label="Classes conducted">
            <input
              type="number"
              min="1"
              name="conducted"
              defaultValue={row.conducted}
              required
            />
          </Field>
        </div>
        <Field label="Course-wise eligibility">
          <select name="status" defaultValue={row.attendance_status || ""}>
            <option value="">Calculate from regulation threshold</option>
            {[
              "Eligible",
              "Shortage",
              ...(["Examination Cell", "Super Administrator"].includes(
                user.role,
              )
                ? ["Debarred", "Approved exception"]
                : []),
            ].map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </Field>
        <label className="checkline">
          <input type="checkbox" required />
          Confirm these verified course-wise attendance counts.
        </label>
        {err && <Notice kind="error">{err}</Notice>}
        <div className="dialogactions">
          <Button type="submit" kind="primary" disabled={busy}>
            Save attendance
          </Button>
        </div>
      </form>
    </Modal>
  );
}
function CapacityForm({ offering: o }) {
  const { close, notify, refresh } = useApp();
  const [err, se] = useState("");
  return (
    <Modal
      title="Edit seat allocation"
      subtitle={`${o.code} · Section ${o.section} · ${o.enrolled} registered students`}
      onClose={close}
    >
      <form
        className="formstack"
        onSubmit={async (e) => {
          e.preventDefault();
          let f = new FormData(e.target);
          try {
            await api(`/sections/${o.section_id}/capacity`, {
              method: "PUT",
              body: {
                capacity: Number(f.get("capacity")),
                reserved_seats: Number(f.get("reserve")),
                confirm: true,
              },
            });
            notify("Section capacity updated");
            refresh();
            close();
          } catch (x) {
            se(x.message);
          }
        }}
      >
        <div className="formgrid">
          <Field label="Section capacity">
            <input
              type="number"
              min={Math.max(1, o.enrolled)}
              name="capacity"
              defaultValue={o.capacity}
              required
            />
          </Field>
          <Field label="Protected seats">
            <input
              type="number"
              min="0"
              name="reserve"
              defaultValue={o.reserved_seats}
              required
            />
          </Field>
        </div>
        <Notice>
          Room and laboratory capacity are revalidated. Newly available seats
          are allocated to eligible waitlisted students in priority order.
        </Notice>
        <label className="checkline">
          <input type="checkbox" required />
          Confirm this authorised capacity change.
        </label>
        {err && <Notice kind="error">{err}</Notice>}
        <div className="dialogactions">
          <Button type="submit" kind="primary">
            Save allocation
          </Button>
        </div>
      </form>
    </Modal>
  );
}
function ProgressionForm({ student: s }) {
  const { user, lookup, close, notify, refresh } = useApp();
  let [tab, st] = useState("Graduation requirement"),
    [err, se] = useState(""),
    [busy, sb] = useState(false);
  let req = useLoad(`/students/${s.id}/eligibility`);
  return (
    <Modal
      title="Academic progression review"
      subtitle={`${s.name} · ${s.register_number} · ${s.regulation}`}
      onClose={close}
    >
      <Tabs
        active={tab}
        onChange={st}
        items={[
          "Graduation requirement",
          ...(user.permissions.includes("migrate")
            ? ["Regulation migration"]
            : []),
        ]}
      />
      <form
        className="formstack"
        onSubmit={async (e) => {
          e.preventDefault();
          let f = new FormData(e.target);
          sb(true);
          se("");
          try {
            let r =
              tab === "Graduation requirement"
                ? await api(`/students/${s.id}/pending-requirements`, {
                    method: "POST",
                    body: {
                      course_id: Number(f.get("course")),
                      approved: f.get("state") === "approve",
                      reason: f.get("reason"),
                      confirm: true,
                    },
                  })
                : await api("/admin/migrations", {
                    method: "POST",
                    body: {
                      student_id: s.id,
                      regulation_id: Number(f.get("reg")),
                      reason: f.get("reason"),
                      confirm: true,
                    },
                  });
            notify(r.status);
            refresh();
            close();
          } catch (x) {
            se(x.message);
          } finally {
            sb(false);
          }
        }}
      >
        {tab === "Graduation requirement" ? (
          <>
            <Notice>
              Record an essential degree requirement. This does not bypass
              prerequisite, credit, faculty or timetable checks.
            </Notice>
            <Field label="Curriculum course">
              <select name="course" required>
                {req.data?.items.map((r) => (
                  <option key={r.course_id} value={r.course_id}>
                    {r.code} · {r.title}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Requirement decision">
              <select name="state">
                <option value="approve">Approve as pending requirement</option>
                <option value="revoke">Remove individual requirement</option>
              </select>
            </Field>
          </>
        ) : (
          <>
            <Notice>
              Active registrations must be resolved. Every completed course
              requires approved credit recognition in the destination
              curriculum.
            </Notice>
            <Field label="Destination regulation">
              <select name="reg" required>
                {lookup.regulations
                  .filter((r) => r.id !== s.regulation_id)
                  .map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.code}
                    </option>
                  ))}
              </select>
            </Field>
          </>
        )}
        <Field label="Academic rationale and approval reference">
          <textarea minLength={12} required name="reason" rows={3} />
        </Field>
        <label className="checkline">
          <input type="checkbox" required />I authorise this change and its
          audit record.
        </label>
        {err && <Notice kind="error">{err}</Notice>}
        <div className="dialogactions">
          <Button type="submit" kind="primary" disabled={busy}>
            Confirm academic decision
          </Button>
        </div>
      </form>
    </Modal>
  );
}
