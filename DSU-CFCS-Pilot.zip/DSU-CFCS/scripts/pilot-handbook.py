"""Build the printable handoff, using the executed test evidence rather than sample verdicts."""

from pathlib import Path
from xml.etree import ElementTree as ET
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    Image,
    PageBreak,
    KeepTogether,
)
from reportlab.lib.enums import TA_CENTER
from xml.sax.saxutils import escape
import json

R = Path(__file__).resolve().parents[1]
fontdir = Path("/usr/share/fonts/truetype/dejavu")
pdfmetrics.registerFont(TTFont("DSU", str(fontdir / "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("DSU-B", str(fontdir / "DejaVuSans-Bold.ttf")))
styles = {
    n: ParagraphStyle(
        n, fontName=f, fontSize=s, leading=l, textColor=colors.HexColor(c), spaceAfter=a
    )
    for n, f, s, l, c, a in [
        ("label", "DSU-B", 8, 12, "#627998", 8),
        ("h1", "DSU-B", 27, 34, "#1c3151", 9),
        ("h2", "DSU-B", 16, 23, "#20385a", 7),
        ("h3", "DSU-B", 11, 16, "#29486e", 3),
        ("p", "DSU", 9.3, 15, "#506078", 10),
        ("small", "DSU", 7.7, 12, "#74859d", 6),
        ("cell", "DSU", 8.2, 13, "#4c5b70", 0),
        ("th", "DSU-B", 8, 12, "#ffffff", 0),
    ]
}
S = []


def text(s, kind="p"):
    S.append(Paragraph(escape(str(s)), styles[kind]))


def head(n, title, sub):
    text(n, "label")
    text(title, "h1")
    text(sub)


def item(h, p):
    S.append(
        KeepTogether(
            [Paragraph(escape(h), styles["h3"]), Paragraph(escape(p), styles["p"])]
        )
    )


def table(headers, rows, widths):
    data = [[Paragraph(escape(str(x)), styles["th"]) for x in headers]] + [
        [Paragraph(escape(str(x)), styles["cell"]) for x in row] for row in rows
    ]
    t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#203857")),
                (
                    "ROWBACKGROUNDS",
                    (0, 1),
                    (-1, -1),
                    [colors.white, colors.HexColor("#f2f5fa")],
                ),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LINEBELOW", (0, 0), (-1, -1), 0.35, colors.HexColor("#e1e7ef")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    S.append(t)
    S.append(Spacer(1, 13))


def page():
    S.append(PageBreak())


head(
    "ACADEMIC SYSTEMS  /  SET PILOT  /  2026–2027",
    "Controlled Flexible Credit System",
    "Dhanalakshmi Srinivasan University · School of Engineering & Technology",
)
text("Pilot handbook & engineering handoff", "h2")
text(
    "A working academic administration workspace backed by FastAPI and PostgreSQL. This edition documents the synthetic pilot, its academic safeguards and the conditions required before institutional deployment."
)
img = R / "docs/workspace-overview.png"
if img.exists():
    S.append(Image(str(img), width=502, height=314))
    S.append(Spacer(1, 12))
table(
    ["Release surface", "Verified implementation"],
    [
        [
            "Application",
            "Responsive React workspace · eight roles · 66 REST operations",
        ],
        [
            "Data model",
            "49 normalised PostgreSQL tables · 89 foreign keys · four migrations",
        ],
        [
            "Verification",
            "62 automated tests passed, including all 20 mandatory scenarios",
        ],
        [
            "Data boundary",
            "The preview contains synthetic, illustrative records and policies only.",
        ],
    ],
    [112, 390],
)
text(
    "Status: engineering pilot candidate. Institutional policy approval, managed hosting, independent security review and final SET user acceptance remain required.",
    "small",
)
page()
head(
    "01  /  SYSTEM DESIGN",
    "Architecture & safeguards",
    "Academic identity and teaching delivery remain independent, even when two regulations share a classroom.",
)
for h, p in [
    (
        "Browser workspace",
        "React screens call a same-origin API. All decision reasons, chart values, rosters, course options and reports originate in PostgreSQL. Client controls do not grant academic authority.",
    ),
    (
        "Identity and scope",
        "FastAPI resolves an expiring opaque bearer session, approved permissions and school, department, advisor, instructor or student scope. Named accounts use Argon2id password hashes.",
    ),
    (
        "Decision and allocation",
        "The regulation engine evaluates verified results, prerequisite groups, semester eligibility, approved recovery, current credit headroom, valid teaching mappings, faculty and room constraints, available seats and student clashes.",
    ),
    (
        "Transactional database",
        "Stable keys, foreign keys, partial unique indexes and an allocation transaction prevent duplicate admission and overbooking. The same checks run when a waitlisted student is promoted.",
    ),
    (
        "Reporting and evidence",
        "Per-attempt results drive credit recognition. Snapshots accelerate cohort analytics, never individual admission decisions. Academic changes and exports leave an immutable audit record.",
    ),
]:
    item(h, p)
text("Core relationships", "h2")
table(
    ["Parent", "Relationship", "Dependent"],
    [
        ["School → department", "Organisational scope", "Programme → student"],
        [
            "Regulation + programme",
            "Independent curriculum",
            "Course → prerequisite group",
        ],
        [
            "Offering → section",
            "Shared teaching delivery",
            "Faculty + room + timetable slots",
        ],
        [
            "Student + section",
            "Confirmed seat or queue",
            "Original course + recognition credits",
        ],
        [
            "Student + course + attempt",
            "Verified academic history",
            "Attendance, result and recovery",
        ],
    ],
    [135, 152, 215],
)
text(
    "The complete physical diagram, schema dictionary and migration SQL are included in the source bundle.",
    "small",
)
page()
head(
    "02  /  ACCESS & OPERATIONS",
    "Role handbook",
    "Use the profile menu to explore synthetic roles. Production disables demo authentication and requires named accounts.",
)
table(
    ["Role", "Primary workflow", "Scope / safeguard"],
    [
        [
            "Super Administrator",
            "Masters, accounts, permissions, imports, policies.",
            "Confirmation and historic recognition safeguards remain mandatory.",
        ],
        [
            "Registrar",
            "Review policy, migration and authorised exceptions.",
            "No self-approval; evidence and remarks retained.",
        ],
        [
            "Dean – SET",
            "School overview, section publication and pooled allocation.",
            "Operational data is scoped to the managed school.",
        ],
        [
            "HoD",
            "Department demand, offerings, student progression and exceptions.",
            "Cannot modify another department’s student records.",
        ],
        [
            "Faculty Advisor",
            "Review assigned students, eligibility and delegated requests.",
            "Advisor relationship restricts access.",
        ],
        [
            "Faculty",
            "Teaching timetable → section → class roster → attendance.",
            "Only assigned teaching sections; no unrelated transcript access.",
        ],
        [
            "Student",
            "Profile, preferences, own registration, recovery and credit audit.",
            "Cannot change results, identity or regulation.",
        ],
        [
            "Examination Cell",
            "Import verified results and review attendance debarment.",
            "An attendance-debarred attempt earns zero credit.",
        ],
    ],
    [107, 175, 220],
)
item(
    "Finding records",
    "Use workspace search (Ctrl/Cmd + K), department/regulation filters and paginated tables. Opening a student record reveals verified transcript attempts, course-wise attendance and degree progress.",
)
item(
    "Reviewing a request",
    "Open Approvals, inspect the academic reason, evidence and named authority, then enter decision remarks and confirm. Repeated or self-approved decisions are refused.",
)
item(
    "Withdrawing an offering",
    "A reason and confirmation are required. Active seats and waitlist entries must first be resolved. Collected preferences remain available for demand analysis.",
)
page()
head(
    "03  /  ACADEMIC WORKFLOWS",
    "Registration & recovery",
    "The controlled window is current semester plus at most one succeeding semester. Recovery is a separate academic pathway.",
)
for h, p in [
    (
        "1. Check the student’s curriculum",
        "Review programme, admission batch, regulation, semester and academic status. The system never silently migrates a student to make a course fit.",
    ),
    (
        "2. Inspect eligibility",
        "Use All courses to see the reason for every block. Mandatory prerequisites need verified completion; conditional groups need expressly authorised provisional permission; recommended preparation is advisory. Groups support AND and OR.",
    ),
    (
        "3. Confirm a registration",
        "The API repeats validation under a database lock. No seat is consumed by a pending or waitlisted request. Protected capacity is unavailable to lower-priority floating/elective demand.",
    ),
    (
        "4. Promote transparently",
        "Queue order follows the configured P1–P5 scheme, then request time and stable ID. A drop or permitted capacity increase triggers promotion only if the candidate still passes every check.",
    ),
    (
        "5. Handle debarment by attempt",
        "Attendance shortage does not imply an invented relaxation or automatic debarment. An authorised debarment closes that attempt without credit. A later verified repeat is a new attempt and does not erase its history.",
    ),
    (
        "6. Reconcile credits",
        "View earned, registered, pending, mandatory and elective credits, approved load limits and basket subtotals. Elective classification must not be added to total credits a second time. A forecast is a lower-bound load estimate, not a guaranteed graduation date.",
    ),
]:
    item(h, p)
text("Never infer an official DSU threshold", "h2")
text(
    "Attendance thresholds, workload norms, regulation-specific credit limits, degree targets, curriculum mappings and authorisation policies must be supplied and approved by the institution. Fixture values are illustrative only."
)
page()
head(
    "04  /  ADMINISTRATION",
    "Imports & master data",
    "Workbooks are staged and validated before any confirmed academic commit.",
)
table(
    ["Profile", "Review before committing"],
    [
        [
            "Student master",
            "Identity, programme/regulation, semester, attempts and earned-credit reconciliation.",
        ],
        [
            "Curriculum",
            "Course code, positive credit, L–T–P, semester, category and independent assessment mapping.",
        ],
        [
            "Prerequisites",
            "Known prerequisite IDs, group operator, type, conflicting groups and cycles.",
        ],
        [
            "Equivalences",
            "Course pair, validity, approval and separate academic credit recognition.",
        ],
        [
            "Attendance",
            "Counts, attempt number and verified status; authorised debarment/exception.",
        ],
        [
            "Examination results",
            "Explicit verified attempt and outcome. No credit for a debarred attempt.",
        ],
        [
            "Faculty master",
            "Staff code, qualification, department, specialisation and competencies.",
        ],
        [
            "Faculty workload",
            "Approved maximum and existing other workload for the academic year.",
        ],
        [
            "Offering & timetable",
            "Course, faculty, seats, resources, registration window, teaching type and times.",
        ],
    ],
    [134, 368],
)
item(
    "Upload → validate → confirm",
    "Download the profile’s Excel template. Use configured master codes, fill data rows and upload XLSX or UTF-8 CSV. Preview returns valid, failed, duplicate and missing-value diagnostics. Correct errors in the source workbook and preview again.",
)
item(
    "No silent overwrite",
    "Updates to existing records require the reviewed-update flag and explicit batch confirmation. The entire batch is revalidated and committed atomically. Invalid records are not silently discarded.",
)
text(
    "Bounds: 5 MB · 2,000 records · 64 columns. The application rejects formulas, macro-enabled files, malformed archives and expired import confirmations.",
    "small",
)
page()
head(
    "05  /  RELEASE OPERATIONS",
    "Deploy, verify, recover",
    "A successful synthetic regression is a prerequisite for pilot UAT, not a substitute for institutional sign-off.",
)
for h, p in [
    (
        "Private managed PostgreSQL",
        "Use a private encrypted service, verified TLS, separate schema-owner and runtime roles, a secrets manager and provider PITR. Do not reuse the demonstration backup as institutional data.",
    ),
    (
        "Migrate and initialise",
        "Run scripts/migrate.py, bootstrap a unique named administrator and deploy the non-root application container. Configure approved hierarchy, regulations, assessment, faculty, rooms, windows and student data before enabling registration.",
    ),
    (
        "Secure the service",
        "Route traffic through the university HTTPS gateway. Configure upload limits, trusted proxies, rate limits, frame policy, monitoring and institutional retention. Keep API and database secrets out of code and logs.",
    ),
    (
        "Recover into an empty target",
        "Use scripts/backup.sh on approved encrypted storage. Verify checksum, explicitly select a separate empty recovery database, then run scripts/restore.sh. Reconcile student, enrolment and result counts and inspect audit continuity before an authorised cutover.",
    ),
    (
        "Verification evidence",
        "The 62-test suite includes all mandatory registration scenarios, real PostgreSQL concurrency, nine Excel import profiles, scoped exports, secure sessions and nine real-browser workflows. A separate local backup restore was successfully reconciled.",
    ),
]:
    item(h, p)
text("Included reference files", "h2")
table(
    ["File", "Purpose"],
    [
        [
            "docs/01-system-architecture.md",
            "Architecture, logical ER, screens, contract and delivery plan.",
        ],
        [
            "docs/api-specification.json",
            "Generated OpenAPI contract. Offline interactive reference: /docs.",
        ],
        [
            "docs/er-diagram.svg",
            "Physical relationship diagram generated from 89 foreign keys.",
        ],
        [
            "docs/02-admin-and-user-guide.md",
            "Detailed operating guide for administrators and all eight roles.",
        ],
        [
            "docs/03-deployment-and-recovery.md",
            "Production handoff, security boundaries and recovery procedures.",
        ],
        [
            "docs/04-verification.md",
            "Executed results and release gates; JUnit evidence alongside.",
        ],
    ],
    [215, 287],
)
pg = SimpleDocTemplate(
    str(R / "DSU-CFCS-Pilot-Handbook.pdf"),
    pagesize=A4,
    leftMargin=46,
    rightMargin=46,
    topMargin=64,
    bottomMargin=44,
    title="DSU–CFCS | SET Pilot Handbook",
    author="DSU–CFCS engineering workspace",
)


def decorate(canvas, doc):
    width, height = A4
    canvas.saveState()
    canvas.setFillColor(colors.HexColor("#192e4c"))
    canvas.rect(0, height - 38, width, 38, fill=1, stroke=0)
    canvas.setFillColor(colors.white)
    canvas.setFont("DSU-B", 10)
    canvas.drawString(46, height - 24, "DSU  /  CFCS")
    canvas.setFillColor(colors.HexColor("#d2bd96"))
    canvas.setFont("DSU", 7)
    canvas.drawRightString(
        width - 46, height - 24, "ACADEMIC SYSTEMS  ·  PILOT HANDBOOK"
    )
    canvas.setStrokeColor(colors.HexColor("#dbe2ed"))
    canvas.line(46, 31, width - 46, 31)
    canvas.setFont("DSU", 7)
    canvas.setFillColor(colors.HexColor("#74859d"))
    canvas.drawString(
        46, 19, "School of Engineering & Technology  ·  Synthetic pilot edition"
    )
    canvas.drawRightString(width - 46, 19, str(doc.page).zfill(2))
    canvas.restoreState()


pg.build(S, onFirstPage=decorate, onLaterPages=decorate)
print("Printable pilot handbook generated.")
