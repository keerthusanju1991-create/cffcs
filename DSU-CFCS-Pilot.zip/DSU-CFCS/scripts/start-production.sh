#!/usr/bin/env bash
set -euo pipefail
export APP_MODE=production
if [[ -n "${DATABASE_URL_FILE:-}" ]]; then export DATABASE_URL="$(cat "$DATABASE_URL_FILE")"; fi
: "${DATABASE_URL:?Provide the institution-managed PostgreSQL connection through a runtime secret}"
: "${PGSSLMODE:=verify-full}"; export PGSSLMODE
exec uvicorn backend.api:app --host 0.0.0.0 --port "${PORT:-8000}" --workers "${WEB_WORKERS:-2}" --no-server-header --no-access-log
