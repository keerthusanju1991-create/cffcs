#!/usr/bin/env bash
set -euo pipefail
: "${PGDATABASE:?Set a separate empty recovery database in PGDATABASE}"
[[ "${RESTORE_CONFIRM:-}" == 'restore-to-empty-target' ]] || { echo 'Set RESTORE_CONFIRM=restore-to-empty-target after verifying the recovery target.'; exit 1; }
FILE="${1:?Usage: scripts/restore.sh backup.dump}"
[[ "$(psql -Atc "SELECT count(*) FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE'")" == '0' ]] || { echo 'Refusing to overwrite a non-empty database.'; exit 1; }
[[ -f "$FILE.sha256" ]] && sha256sum -c "$FILE.sha256"
# A schema-scoped PG17 dump may explicitly include CREATE SCHEMA public.
# Keep its contents, but do not recreate the target's pre-existing empty namespace.
TOC=$(mktemp); trap 'rm -f "$TOC"' EXIT
pg_restore --list "$FILE" >"$TOC"
if [[ "$(psql -Atc "SELECT count(*) FROM pg_namespace WHERE nspname='public'")" == '1' ]]; then
  sed -i -E '/^[0-9]+; [0-9]+ [0-9]+ SCHEMA - public( |$)/d' "$TOC"
fi
pg_restore --single-transaction --exit-on-error --no-owner --no-acl --use-list="$TOC" -d "$PGDATABASE" "$FILE"
psql -v ON_ERROR_STOP=1 -c 'SELECT version,applied_at FROM schema_migrations ORDER BY version' -c 'SELECT count(*) AS students FROM students' -c 'SELECT count(*) AS retained_audit_events FROM academic_audit_logs'
echo 'Restored to an isolated target. Do not cut over until academic reconciliation is approved.'
