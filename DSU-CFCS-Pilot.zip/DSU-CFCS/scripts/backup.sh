#!/usr/bin/env bash
# Use inherited PGHOST, PGDATABASE, PGUSER and a secrets-mounted PGPASSFILE.
set -euo pipefail; umask 077
: "${PGDATABASE:?Choose a database through authenticated PostgreSQL environment configuration}"
DEST="${1:?Usage: scripts/backup.sh /secure/backup-directory}"; mkdir -p "$DEST"
FILE="$DEST/cfcs-$(date -u +%Y%m%dT%H%M%SZ).dump"
pg_dump -Fc --no-owner --no-acl --exclude-table-data=sessions --exclude-table-data=login_attempts -f "$FILE.tmp"
pg_restore --list "$FILE.tmp" >/dev/null; mv "$FILE.tmp" "$FILE"; sha256sum "$FILE" > "$FILE.sha256"; echo "Backup and checksum created: $FILE"
