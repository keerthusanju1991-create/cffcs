#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export APP_MODE=synthetic
PG_BIN="$(pg_config --bindir)"; PGDATA="$PWD/.local/dsu-pg"; SOCKET=/tmp/dsu-socket
mkdir -p "$PGDATA" "$SOCKET" data; chmod 700 "$PGDATA" "$SOCKET"
if [[ ! -x "$PG_BIN/postgres" ]]; then echo 'PostgreSQL server 15+ is required (Debian: install postgresql-17).'; exit 1; fi
if [[ ! -s "$PGDATA/PG_VERSION" ]]; then "$PG_BIN/initdb" -D "$PGDATA" --auth-local=peer --auth-host=reject --encoding=UTF8 --locale=C.UTF-8 >/dev/null; fi
if ! "$PG_BIN/pg_isready" -q -h "$SOCKET" -p 5436; then "$PG_BIN/pg_ctl" -D "$PGDATA" -l /tmp/dsu-postgres.log -o "-k $SOCKET -p 5436 -c listen_addresses=''" -w start; fi
export PGHOST="$SOCKET" PGPORT=5436 PGDATABASE=dsu
export DATABASE_URL="host=$SOCKET port=5436 dbname=dsu"
if [[ "$(psql -d postgres -Atc "SELECT count(*) FROM pg_database WHERE datname='dsu'")" != '1' ]]; then
  createdb dsu
fi
# Recover even if a previous first boot created the empty database but stopped before restore.
if [[ -s data/pilot.dump && "$(psql -Atc "SELECT count(*) FROM pg_tables WHERE schemaname='public'")" == '0' ]]; then
  RESTORE_CONFIRM=restore-to-empty-target bash scripts/restore.sh data/pilot.dump
fi
python scripts/migrate.py
if [[ "$(psql -Atc 'SELECT count(*) FROM schools')" == '0' ]]; then python -m backend.seed --demo; fi
if [[ ! -f frontend/public/app.js ]]; then npm ci && npm run build; fi
exec uvicorn backend.api:app --host 0.0.0.0 --port "${PORT:-8000}"
