"""Generate the physical data dictionary, real FK diagram and verification report from the tested system."""

import sys, csv, json, subprocess, html, re
from pathlib import Path
from xml.etree import ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.core import *
from backend.api import app

with connect() as c:
    db = DB(c)
    cols = db.all(
        "SELECT c.table_name,c.column_name,c.data_type,c.is_nullable,c.column_default FROM information_schema.columns c JOIN information_schema.tables t ON t.table_schema=c.table_schema AND t.table_name=c.table_name AND t.table_type='BASE TABLE' WHERE c.table_schema='public' ORDER BY c.table_name,c.ordinal_position"
    )
    fk = db.all(
        "SELECT tc.table_name,kcu.column_name,cf.table_name AS target_table,cf.column_name AS target_column FROM information_schema.table_constraints tc JOIN information_schema.key_column_usage kcu ON tc.constraint_name=kcu.constraint_name AND tc.constraint_schema=kcu.constraint_schema JOIN information_schema.constraint_column_usage cf ON cf.constraint_name=tc.constraint_name AND cf.constraint_schema=tc.constraint_schema WHERE tc.constraint_type='FOREIGN KEY' AND tc.table_schema='public'"
    )
    pk = db.all(
        "SELECT tc.table_name,k.column_name FROM information_schema.table_constraints tc JOIN information_schema.key_column_usage k ON k.constraint_name=tc.constraint_name AND k.constraint_schema=tc.constraint_schema WHERE tc.constraint_type='PRIMARY KEY' AND tc.table_schema='public'"
    )
keys = {(r["table_name"], r["column_name"]) for r in pk}
refs = {
    (r["table_name"], r["column_name"]): r["target_table"] + "." + r["target_column"]
    for r in fk
}
tables = sorted({r["table_name"] for r in cols})
with (ROOT / "docs/schema-dictionary.csv").open("w") as f:
    w = csv.writer(f)
    w.writerow(
        [
            "Table",
            "Column",
            "PostgreSQL type",
            "Nullable",
            "Primary key",
            "References",
            "Default",
        ]
    )
    for r in cols:
        w.writerow(
            [
                r["table_name"],
                r["column_name"],
                r["data_type"],
                r["is_nullable"],
                (r["table_name"], r["column_name"]) in keys,
                refs.get((r["table_name"], r["column_name"]), ""),
                r["column_default"] or "",
            ]
        )
lines = [
    "digraph CFCS {",
    'graph [label="DSU–CFCS  |  Physical data model\\n49 normalised tables · PostgreSQL · SET pilot",labelloc=t,fontname="DejaVu Sans",fontsize=22,fontcolor="#1d3556",bgcolor="#f8fafd",rankdir=LR,ranksep=0.95,nodesep=0.18,pad=0.3];',
    'node [shape=plain,fontname="DejaVu Sans",fontsize=10];',
    'edge [color="#a1b0c5",arrowsize=0.5,penwidth=0.8];',
]
for t in tables:
    fields = [r for r in cols if r["table_name"] == t]
    label = (
        '<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0" CELLPADDING="5" BGCOLOR="white"><TR><TD ALIGN="LEFT" BGCOLOR="#233d61"><FONT COLOR="white"><B>'
        + t
        + "</B></FONT></TD></TR>"
    )
    for r in fields:
        k = (t, r["column_name"])
        tag = "PK " if k in keys else ("FK " if k in refs else "")
        label += (
            '<TR><TD ALIGN="LEFT"><FONT POINT-SIZE="8" COLOR="'
            + ("#3e65a5" if tag else "#66768e")
            + '">'
            + tag
            + html.escape(r["column_name"])
            + " · "
            + html.escape(r["data_type"])
            + "</FONT></TD></TR>"
        )
    lines.append(t + " [label=<" + label + "</TABLE>>];")
for r in fk:
    lines.append(
        r["target_table"]
        + " -> "
        + r["table_name"]
        + ' [tooltip="'
        + r["table_name"]
        + "."
        + r["column_name"]
        + " references "
        + r["target_table"]
        + "."
        + r["target_column"]
        + '"];'
    )
lines.append("}")
(ROOT / "docs/er-diagram.dot").write_text("\n".join(lines))
subprocess.run(
    [
        "dot",
        "-Tsvg",
        str(ROOT / "docs/er-diagram.dot"),
        "-o",
        str(ROOT / "docs/er-diagram.svg"),
    ],
    check=True,
)
spec = app.openapi()
(ROOT / "docs/api-specification.json").write_text(
    json.dumps(spec, indent=2, ensure_ascii=False)
)
suite = ET.parse(ROOT / "docs/test-results.xml").getroot().find("testsuite")
tests = suite.findall("testcase")
counts = {
    k: len([t for t in tests if t.get("classname", "").endswith(k)])
    for k in ["test_acceptance", "test_browser", "test_workflows"]
}
ok = suite.get("failures") == "0" and suite.get("errors") == "0"
operation_count = sum(
    sum(x in ["get", "post", "put", "patch", "delete"] for x in p)
    for p in spec["paths"].values()
)
report = f"""# Verification and release record

**Local execution:** {suite.get("timestamp")}  
**Result:** {suite.get("tests")} tests, {suite.get("failures")} failures, {suite.get("errors")} errors, {suite.get("skipped")} skipped. Runtime: {suite.get("time")} seconds.  
**Database:** PostgreSQL 17, isolated schema per scenario. **Browser:** real headless Chromium.  
**Delivered surface:** {len(tables)} normalised tables, {len(fk)} foreign keys, four transactional migrations, {operation_count} documented REST operations.

## Test gates
| Suite | Tests | Coverage |
|---|---:|---|
| Academic acceptance | {counts["test_acceptance"]} | All 20 requested mandatory scenarios |
| Workflow / integration / pure unit | {counts["test_workflows"]} | Nine Excel profiles, preview/commit, audit, role scope, independent decisions, authentication, credit identity, attempt lifecycle and capacity changes |
| Browser end-to-end | {counts["test_browser"]} | Dashboard/filtering, student detail, publication, registration/drop, approvals, XLSX download/import, faculty attendance, search and mobile navigation |

## Mandatory academic scenarios
| No. | Executed scenario | Result |
|---:|---|---|
"""
for t in [x for x in tests if x.get("classname", "").endswith("test_acceptance")]:
    m = re.match(r"test_(\d+)_(.*)", t.get("name"))
    report += (
        f"| {int(m[1])} | {m[2].replace('_', ' ').capitalize()} | "
        + ("PASS" if len(t) == 0 else "See XML")
        + " |\n"
    )
report += """
## Phase-to-code traceability
1. Foundation: `core.py`, versioned DDL, password/session/permission tests.
2. Masters: `admin.py`, protected identity, approved migration and archival guards.
3. Student records: `imports.py`, real Excel workbook tests, invalid-row diagnostics and credit reconciliation.
4. Eligibility: `engine.py`, mandatory/conditional/recommended and AND/OR groups; per-attempt debarment.
5. Equivalence and delivery: approved validity-bounded mappings, original credits and schemes; publication checks.
6. Faculty: competencies, cross-department teaching, approved load, availability and lab/room checks.
7. Registration: same validator at submit/promotion, concurrent last-seat test, protected capacity, queue promotion.
8. Timetable and credit audit: overlap checks, verified recognition view, original attempts, category targets and supply-based forecast.
9. Operations: eight role workspaces, reports, actual binary downloads, validated uploads, independent decisions and audit.
10. Release: full regression, browser verification, verified backup restoration and deployment handoff.

## Additional observed checks
- No section overbooking in the initial live synthetic dataset.
- Desktop and 390-pixel mobile layouts render without page-level horizontal overflow; wide tables scroll inside their own container.
- Offline `/docs` renders using bundled Swagger assets; the OpenAPI schema includes a bearer authorisation scheme.
- A checksum-verified custom-format backup restored to a separate empty PostgreSQL database. Student, enrolment and examination-attempt counts matched the source; restored sessions = 0.
- Test writes occur in isolated schemas, not the user-facing preview. A deprecation notice from the test-client integration is not a failed test.

## Release decision
**Engineering regression: passed. Institutional go-live: not yet authorised.** These tests establish the stated scenarios on the delivered environment. They do not establish official DSU policy correctness, production load capacity, external security certification, privacy compliance, managed-database failover or final university UAT. Complete the deployment checklist before using real records.
"""
(ROOT / "docs/04-verification.md").write_text(report)
print(
    f"Generated documentation: {len(tables)} tables, {len(fk)} foreign keys, {operation_count} API operations, {len(tests)} test results."
)
