"""Real Chromium → HTTP FastAPI → separate PostgreSQL schema. Never runs writes against the live pilot."""

import io, threading, socket, uuid, sys
import pytest, uvicorn, psycopg
from psycopg import sql
from psycopg.conninfo import make_conninfo
from psycopg.rows import dict_row
from playwright.sync_api import sync_playwright, expect
from backend.core import *
from backend.api import app
from backend.seed import seed
from backend.imports import FORMATS
from openpyxl import Workbook


@pytest.fixture(scope="module")
def browser_env():
    base = os.getenv("TEST_DATABASE_URL", DSN)
    sch = "cfcs_browser_" + uuid.uuid4().hex[:10]
    with psycopg.connect(base, autocommit=True) as c:
        c.execute(sql.SQL("CREATE SCHEMA {}").format(sql.Identifier(sch)))
    dsn = make_conninfo(base, options="-c search_path=" + sch)
    with psycopg.connect(dsn, row_factory=dict_row) as c:
        db = DB(c)
        for m in sorted((ROOT / "migrations").glob("*.sql")):
            db.run(m.read_text())
        setup_roles(db)
        seed(db)

    def scoped():
        with psycopg.connect(dsn, row_factory=dict_row) as c:
            yield DB(c)

    app.dependency_overrides[get_db] = scoped
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.listen(64)
    event = threading.Event()

    class Server(uvicorn.Server):
        async def startup(self, sockets=None):
            await super().startup(sockets=sockets)
            event.set()

    server = Server(uvicorn.Config(app, log_level="error", access_log=False))
    thread = threading.Thread(target=lambda: server.run(sockets=[sock]), daemon=True)
    thread.start()
    assert event.wait(10)
    with sync_playwright() as p:
        b = p.chromium.launch(headless=True, args=["--no-sandbox"])
        yield b, f"http://127.0.0.1:{port}"
        b.close()
    server.should_exit = True
    thread.join(8)
    app.dependency_overrides.pop(get_db, None)
    with psycopg.connect(base, autocommit=True) as c:
        c.execute(sql.SQL("DROP SCHEMA {} CASCADE").format(sql.Identifier(sch)))


@pytest.fixture
def page(browser_env):
    b, url = browser_env
    pg = b.new_page(viewport={"width": 1400, "height": 900})
    err = []
    pg.on("pageerror", lambda e: err.append(str(e)))
    pg.goto(url)
    expect(
        pg.get_by_role("heading", name="Academic overview", exact=True)
    ).to_be_visible()
    yield pg
    pg.close()
    assert not err, err


def nav(pg, name):
    pg.locator(".sidenav").get_by_role("button", name=name, exact=True).click()


def role(pg, name):
    pg.get_by_role("button", name="Account and demo role selection").click()
    pg.locator(".accountmenu").get_by_role("button", name=name, exact=True).click()
    expect(pg.locator(".accounttrigger small")).to_have_text(name.replace(" – ", ", "))


def test_browser_preview_signin_overview_chart_period_and_navigation(page):
    # Embedding gateways may reserve Authorization. The same session must still
    # authenticate the browser, including after an explicit logout and demo entry.
    def through_preview(route):
        headers = route.request.all_headers()
        headers.pop("authorization", None)
        route.continue_(headers=headers)

    page.route("**/api/**", through_preview)
    page.get_by_role("button", name="Account and demo role selection").click()
    page.get_by_role("button", name="Sign out", exact=True).click()
    expect(page.get_by_role("heading", name="Explore the pilot")).to_be_visible()
    page.get_by_role("button", name="Explore the Dean workspace", exact=True).click()
    expect(page.get_by_role("heading", name="Academic overview", exact=True)).to_be_visible()
    expect(page.locator(".kpicard").first).to_contain_text("1,248")
    page.get_by_label("Registration period").select_option("14")
    expect(page.get_by_label("Registration period")).to_have_value("14")
    expect(page.locator(".deptpanel tbody tr")).to_have_count(6)
    page.locator(".kpicard").nth(2).click()
    expect(page.get_by_role("heading", name="Faculty pool", exact=True)).to_be_visible()
    expect(page.locator("tbody tr")).to_have_count(12)


def test_browser_student_search_transcript_and_audit(page):
    nav(page, "Student records")
    page.get_by_placeholder("Search name or register number…").fill("SYN-25CSE0001")
    expect(page.locator("tbody tr")).to_have_count(1)
    page.locator("tbody tr").click()
    expect(page.get_by_role("dialog")).to_contain_text("Aarav Srinivas")
    page.get_by_role("tab", name="Credit audit").click()
    expect(page.get_by_role("dialog")).to_contain_text("Degree target")
    page.get_by_role("tab", name="Transcript").click()
    expect(page.get_by_role("dialog").locator("tbody tr").first).to_contain_text(
        "Passed"
    )


def test_browser_publish_validated_offering(page):
    nav(page, "Course offerings")
    page.get_by_label("Offering status").select_option("Pending approval")
    page.locator("tbody tr").first.click()
    page.get_by_role("button", name="Publish offering", exact=True).click()
    page.get_by_role("checkbox").check()
    page.get_by_role("button", name="Validate & publish").click()
    expect(page.locator(".toast")).to_contain_text("Published")


def test_browser_student_register_and_drop(page):
    role(page, "Student")
    nav(page, "Course registration")
    page.get_by_role("button", name="Register", exact=True).first.click()
    page.get_by_role("checkbox").check()
    page.get_by_role("button", name="Register course", exact=True).click()
    expect(page.locator(".toast")).to_contain_text("Registered")
    page.get_by_role("tab", name="Registered courses").click()
    page.get_by_role("button", name="Drop", exact=True).first.click()
    page.get_by_label("Decision remarks").fill("Synthetic end-to-end course release.")
    page.get_by_role("checkbox").check()
    page.get_by_role("button", name="Confirm drop").click()
    expect(page.locator(".toast")).to_contain_text("Dropped")


def test_browser_authorised_exception_decision(page):
    page.locator(".navitem").filter(has_text="Approvals").click()
    page.locator("tbody tr").filter(has_text="Dean – SET").first.click()
    page.get_by_role("button", name="Approve request").click()
    page.get_by_label("Decision remarks").fill(
        "Evidence reviewed for the synthetic pilot."
    )
    page.get_by_role("checkbox").check()
    page.get_by_role("button", name="Approve request").click()
    expect(page.locator(".toast")).to_contain_text("Approved")


def test_browser_real_excel_report_download(page):
    nav(page, "Reports & analytics")
    page.get_by_label("Choose report").select_option("department")
    page.get_by_role("button", name="Export report").click()
    with page.expect_download() as result:
        page.get_by_role("button", name="Excel workbook").click()
    assert result.value.suggested_filename.endswith(".xlsx")
    assert Path(result.value.path()).read_bytes()[:2] == b"PK"


def test_browser_excel_import_preview_commit(page):
    role(page, "Super Administrator")
    page.get_by_role("button", name="Workspace settings", exact=True).click()
    page.get_by_role("tab", name="Data imports").click()
    page.get_by_label("Import profile").first.select_option("students")
    wb = Workbook()
    ws = wb.active
    ws.append(FORMATS["students"])
    ws.append(
        [
            "SYN-E2E-001",
            "Synthetic E2E Learner",
            "CSE",
            "BT-CSE",
            2025,
            "R2025",
            3,
            "",
            "",
            "",
            "",
            0,
            0,
            "Active",
        ]
    )
    buf = io.BytesIO()
    wb.save(buf)
    page.locator("input[type=file]").set_input_files(
        {
            "name": "synthetic-student.xlsx",
            "mimeType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "buffer": buf.getvalue(),
        }
    )
    page.get_by_role("button", name="Validate file").click()
    expect(page.locator(".importresult")).to_contain_text("passed validation")
    page.get_by_role("button", name="Review & commit import").click()
    page.get_by_role("checkbox").last.check()
    page.get_by_role("button", name="Commit import", exact=True).click()
    expect(page.locator(".toast")).to_contain_text("1 records imported")


def test_browser_faculty_course_attendance(page):
    role(page, "Faculty")
    page.locator(".timeslot").first.click()
    page.get_by_role("button", name="View class roster").click()
    page.get_by_role("button", name="Record", exact=True).first.click()
    page.get_by_label("Classes attended").fill("19")
    page.get_by_label("Classes conducted").fill("20")
    page.get_by_label("Course-wise eligibility").select_option("Eligible")
    page.get_by_role("checkbox").check()
    page.get_by_role("button", name="Save attendance").click()
    expect(page.locator(".toast")).to_contain_text("Course attendance recorded")


def test_browser_global_search_and_mobile_navigation(page):
    page.keyboard.press("Control+k")
    page.get_by_label("Search all workspace records").fill("Data Structures")
    expect(page.locator(".searchresults")).to_contain_text("COURSES")
    page.locator(".searchresults button").filter(
        has_text="Data Structures"
    ).first.click()
    expect(page.get_by_role("dialog")).to_contain_text("Course equivalence matrix")
    page.keyboard.press("Escape")
    page.set_viewport_size({"width": 390, "height": 844})
    page.get_by_role("button", name="Toggle navigation").click()
    page.locator(".sidenav").get_by_role("button", name="Timetable", exact=True).click()
    expect(page.get_by_role("heading", name="Academic timetable")).to_be_visible()
    assert page.evaluate("document.documentElement.scrollWidth<=innerWidth")
