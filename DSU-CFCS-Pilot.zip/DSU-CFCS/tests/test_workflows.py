import io, csv, secrets, pytest
from datetime import timedelta
from openpyxl import Workbook, load_workbook
from fastapi import HTTPException
from conftest import headers
from backend.core import *
from backend.engine import *
from backend.imports import FORMATS, boolean, tparse


@pytest.mark.parametrize("kind", list(FORMATS))
def test_nine_excel_profiles_validate_then_commit(store, client, kind):
    a = store
    c, z, o = a.course(4)
    p, _, _ = a.course(2)
    code = a.db.val("SELECT code FROM courses WHERE id=%s", (c,))
    pre = a.db.val("SELECT code FROM courses WHERE id=%s", (p,))
    student = a.s()
    staff = a.db.val("SELECT staff_number FROM faculty WHERE id=%s", (a.f,))
    rr = a.reg("TEST-OTHER")
    cc, _, _ = a.course(4, rr, offer=False)
    target = a.db.val("SELECT code FROM courses WHERE id=%s", (cc,))
    base = {"regulation": "TEST-A", "programme": "TEST-BT", "course_code": code}
    rows = {
        "students": dict(
            register_number="SYN-IMPORT-001",
            name="Synthetic imported student",
            department="TEST-CS",
            programme="TEST-BT",
            admission_year=2024,
            regulation="TEST-A",
            semester=4,
            completed_courses=pre,
            failed_courses="",
            debarred_courses="",
            registered_courses="",
            earned_credits=3,
            cgpa=8.2,
            status="Active",
        ),
        "curriculum": dict(
            **{**base, "course_code": "TEST-UPLOAD"},
            semester=4,
            title="Synthetic imported curriculum",
            credits=3,
            category="CORE",
            lecture=1,
            tutorial=0,
            practical=0,
            prerequisites=pre,
            assessment="Test assessment",
            approved="true",
        ),
        "prerequisites": dict(
            **base,
            group="Verified foundations",
            operator="AND",
            kind="Mandatory",
            prerequisite_code=pre,
        ),
        "equivalences": dict(
            **base,
            target_regulation="TEST-OTHER",
            target_programme="TEST-BT",
            target_code=target,
            valid_from=date.today().isoformat(),
            valid_until=(date.today() + timedelta(days=10)).isoformat(),
            recognise_credit="true",
            approved="true",
        ),
        "attendance": dict(
            register_number=student["register_number"],
            course_code=code,
            attempt=1,
            attended=18,
            conducted=20,
            status="Eligible",
            repeat_approved="false",
        ),
        "results": dict(
            register_number=student["register_number"],
            course_code=code,
            attempt=1,
            outcome="Passed",
            verified="true",
        ),
        "faculty": dict(
            staff_number="TEST-IMPORT-F",
            name="Synthetic pooled faculty",
            department="TEST-CS",
            qualification="Synthetic doctorate",
            specialisation="Computing",
            lab_competent="true",
            eligible_course_ids=str(c),
        ),
        "workload": dict(staff_number=staff, maximum_hours=32, other_hours=1),
        "offerings": dict(
            **base,
            staff_number=staff,
            section="B",
            capacity=20,
            minimum_seats=2,
            reserved_seats=6,
            room="TEST-101",
            weekday=3,
            start_time="13:00",
            end_time="14:00",
            kind="Theory",
            window="Test window",
            recovery_allowed="true",
        ),
    }
    table = {
        "students": "students",
        "curriculum": "courses",
        "prerequisites": "course_prerequisites",
        "equivalences": "course_equivalences",
        "attendance": "attendance_records",
        "results": "student_course_results",
        "faculty": "faculty",
        "workload": "faculty_workloads",
        "offerings": "course_offerings",
    }[kind]
    before = a.db.val("SELECT count(*) FROM " + table)
    h = headers(a.db, a.uid)
    res = client.get("/api/templates/" + kind, headers=h)
    assert res.status_code == 200
    wb = load_workbook(io.BytesIO(res.content))
    ws = wb.active
    assert [x.value for x in ws[1]] == FORMATS[kind]
    ws.append([rows[kind][k] for k in FORMATS[kind]])
    buf = io.BytesIO()
    wb.save(buf)
    prev = client.post(
        f"/api/imports/{kind}/preview?overwrite=true",
        headers=h,
        files={"file": ("test-fixture.xlsx", buf.getvalue())},
    )
    assert prev.status_code == 200, prev.text
    summary = prev.json()
    assert summary["valid"] == 1 and summary["failed"] == 0, summary
    assert a.db.val("SELECT count(*) FROM " + table) == before
    res = client.post(
        f"/api/imports/{summary['batch_id']}/commit", headers=h, json={"confirm": True}
    )
    assert res.status_code == 200, res.text
    assert res.json()["committed"]
    assert a.db.val("SELECT count(*) FROM " + table) == before + (
        0 if kind == "workload" else 1
    )
    assert (
        client.post(
            f"/api/imports/{summary['batch_id']}/commit",
            headers=h,
            json={"confirm": True},
        ).status_code
        == 409
    )


def test_invalid_duplicate_missing_rows_do_not_commit(store, client):
    a = store
    h = headers(a.db, a.uid)
    f = io.StringIO()
    w = csv.DictWriter(f, FORMATS["curriculum"])
    w.writeheader()
    r = dict(
        regulation="TEST-A",
        programme="TEST-BT",
        semester=4,
        course_code="SYN-VALID",
        title="Test",
        credits=3,
        category="CORE",
        lecture=1,
        tutorial=0,
        practical=0,
        prerequisites="",
        assessment="Test assessment",
        approved="true",
    )
    w.writerow(r)
    w.writerow(r)
    w.writerow({**r, "credits": -3, "course_code": "SYN-BAD"})
    w.writerow({**r, "course_code": ""})
    w.writerow({**r, "course_code": "SYN-PRE", "prerequisites": "UNMAPPED"})
    resp = client.post(
        "/api/curriculum/import",
        headers=h,
        files={"file": ("fixture.csv", f.getvalue())},
    )
    assert resp.status_code == 200
    summary = resp.json()
    assert (
        summary["total"] == 5
        and summary["failed"] == 4
        and summary["duplicates"] == 1
        and summary["missing"] == 1
    )
    assert (
        client.post(
            f"/api/imports/{summary['batch_id']}/commit",
            headers=h,
            json={"confirm": True},
        ).status_code
        == 409
    )
    assert a.db.val("SELECT count(*) FROM courses") == 0


def test_approved_curriculum_not_overwritten_without_review(store, client):
    a = store
    c, _, _ = a.course(4)
    h = headers(a.db, a.uid)
    resp = client.put(
        "/api/admin/masters/courses/" + str(c),
        headers=h,
        json={"values": {"title": "New title"}, "confirm": False},
    )
    assert resp.status_code == 422
    assert a.db.val("SELECT title FROM courses WHERE id=%s", (c,)) != "New title"


def test_explicit_regulation_migration_required(store, client):
    a = store
    r = a.reg("TEST-B")
    h = headers(a.db, a.uid)
    assert (
        client.put(
            "/api/admin/masters/students/" + str(a.sid),
            headers=h,
            json={"values": {"regulation_id": r}, "confirm": True},
        ).status_code
        == 409
    )
    res = client.post(
        "/api/admin/migrations",
        headers=h,
        json={
            "student_id": a.sid,
            "regulation_id": r,
            "reason": "Verified synthetic migration plan.",
            "confirm": True,
        },
    )
    assert res.status_code == 200, res.text
    assert a.s()["regulation_id"] == r
    assert a.db.val("SELECT count(*) FROM regulation_migrations") == 1


def test_recommended_and_or_prerequisite_groups(store):
    a = store
    p1, _, _ = a.course(2)
    p2, _, _ = a.course(3)
    p3, _, _ = a.course(3)
    c, z, _ = a.course(4)
    g = a.db.insert(
        "course_prerequisite_groups",
        course_id=c,
        name="Choice",
        operator="OR",
        kind="Mandatory",
    )
    a.db.insert("course_prerequisites", group_id=g, prerequisite_id=p1)
    a.db.insert("course_prerequisites", group_id=g, prerequisite_id=p2)
    g2 = a.db.insert(
        "course_prerequisite_groups",
        course_id=c,
        name="Preparation",
        operator="AND",
        kind="Recommended",
    )
    a.db.insert("course_prerequisites", group_id=g2, prerequisite_id=p3)
    a.record(p2)
    res = evaluate(a.db, a.s(), c, z)
    assert res["status"] == "Eligible" and "Recommended preparation" in res["reason"]


def test_compulsory_seat_reservation(store):
    a = store
    c, z, _ = a.course(5, capacity=1)
    a.db.run("UPDATE course_sections SET reserved_seats=1 WHERE id=%s", (z,))
    assert evaluate(a.db, a.s(), c, z)["status"] == "Waitlisted"
    s2 = a.student(5)
    assert submit(a.db, a.usr, a.s(s2), c, z, "Normal", True)["status"] == "Registered"


def test_protected_student_result_credit_identity(store):
    a = store
    c, z, _ = a.course(4)
    c2, _, _ = a.course(4)
    a.db.insert(
        "course_equivalences",
        course_a=c,
        course_b=c2,
        approved=True,
        recognise_credit=True,
        valid_from=date.today(),
        valid_until=date.today() + timedelta(days=10),
    )
    a.record(c)
    a.record(c2)
    assert credit_audit(a.db, a.s())["earned"] == 3
    assert evaluate(a.db, a.s(), c2)["status"] == "Already completed"


def test_exception_confirmed_independent_review_and_audit(store, client):
    a = store
    c, z, _ = a.course(5)
    a.db.insert(
        "exception_policies",
        regulation_id=a.r,
        kind="Conditional prerequisite",
        authority="Registrar",
        active=True,
    )
    hs = headers(a.db, a.stid)
    ha = headers(a.db, a.uid)
    r = client.post(
        "/api/exceptions",
        headers=hs,
        json={
            "student_id": a.sid,
            "course_id": c,
            "kind": "Conditional prerequisite",
            "reason": "Verified synthetic learning evidence.",
            "evidence": "TEST-DOC-001",
            "confirm": True,
        },
    )
    assert r.status_code == 200, r.text
    id = r.json()["id"]
    b = {"decision": "Approved", "remarks": "Verified independently.", "confirm": True}
    assert (
        client.post(f"/api/exceptions/{id}/decision", headers=hs, json=b).status_code
        == 403
    )
    assert (
        client.post(f"/api/exceptions/{id}/decision", headers=ha, json=b).status_code
        == 200
    )
    assert (
        a.db.val(
            "SELECT count(*) FROM academic_audit_logs WHERE action='Approved exception'"
        )
        == 1
    )


def test_provisional_request_revalidates_before_enrolment(store, client):
    a = store
    p, _, _ = a.course(2)
    c, z, _ = a.course(5)
    g = a.db.insert(
        "course_prerequisite_groups",
        course_id=c,
        name="Prior learning",
        kind="Conditional",
        operator="AND",
    )
    a.db.insert("course_prerequisites", group_id=g, prerequisite_id=p)
    a.db.insert(
        "exception_policies",
        regulation_id=a.r,
        kind="Conditional prerequisite",
        authority="Registrar",
        active=True,
    )
    hs = headers(a.db, a.stid)
    ha = headers(a.db, a.uid)
    r = client.post(
        "/api/registration/submit",
        headers=hs,
        json={"student_id": a.sid, "course_id": c, "section_id": z, "confirm": True},
    )
    assert r.status_code == 200, r.text
    assert r.json()["status"] == "Pending approval"
    assert credit_audit(a.db, a.s())["registered"] == 0
    eid = a.db.val("SELECT id FROM academic_exceptions LIMIT 1")
    r = client.post(
        f"/api/exceptions/{eid}/decision",
        headers=ha,
        json={
            "decision": "Approved",
            "remarks": "Reviewed synthetic prior learning.",
            "confirm": True,
        },
    )
    assert r.status_code == 200, r.text
    assert credit_audit(a.db, a.s())["registered"] == 3


def test_named_password_session_revocation_and_rate_limit(store, client):
    a = store
    pw = secrets.token_urlsafe(18)
    a.db.run(
        "UPDATE users SET demo=false,password_hash=%s WHERE id=%s", (PH.hash(pw), a.uid)
    )
    a.conn.commit()
    r = client.post("/api/auth/login", json={"username": "test-admin", "password": pw})
    assert r.status_code == 200
    h = {"Authorization": "Bearer " + r.json()["access_token"]}
    assert client.get("/api/auth/me", headers=h).status_code == 200
    app_header = {"X-CFCS-Session": r.json()["access_token"]}
    assert client.get("/api/auth/me", headers=app_header).status_code == 200
    assert client.get("/api/auth/me").status_code == 401
    assert client.post("/api/auth/logout", headers=app_header).status_code == 200
    assert client.get("/api/auth/me", headers=h).status_code == 401
    assert client.get("/api/auth/me", headers=app_header).status_code == 401
    for i in range(15):
        client.post(
            "/api/auth/login",
            json={"username": "unknown-test-account", "password": "invalid-test-value"},
        )
    assert (
        client.post(
            "/api/auth/login",
            json={"username": "unknown-test-account", "password": "invalid-test-value"},
        ).status_code
        == 429
    )


def test_export_documents_are_real_and_scoped(store, client):
    a = store
    c, z, _ = a.course(4)
    submit(a.db, a.usr, a.s(), c, z, "Normal", True)
    s2 = a.student()
    submit(a.db, a.usr, a.s(s2), c, z, "Normal", True)
    h = headers(a.db, a.stid)
    csvdoc = client.get("/api/reports/registration/export?format=csv", headers=h)
    assert (
        csvdoc.status_code == 200
        and a.s()["register_number"] in csvdoc.text
        and a.s(s2)["register_number"] not in csvdoc.text
    )
    x = client.get("/api/reports/registration/export?format=xlsx", headers=h)
    wb = load_workbook(io.BytesIO(x.content))
    assert wb.active.max_row == 2
    p = client.get("/api/reports/registration/export?format=pdf", headers=h)
    assert p.content.startswith(b"%PDF-")
    assert (
        client.get("/api/reports/department/export?format=csv", headers=h).status_code
        == 403
    )


def test_spreadsheet_upload_rejects_formula_and_improper_extension(store, client):
    a = store
    h = headers(a.db, a.uid)
    wb = Workbook()
    wb.active.append(FORMATS["faculty"])
    wb.active.append(["=1+1"])
    b = io.BytesIO()
    wb.save(b)
    r = client.post(
        "/api/imports/faculty/preview",
        headers=h,
        files={"file": ("fixture.xlsx", b.getvalue())},
    )
    assert r.status_code == 422 and "Formulas" in r.text
    assert (
        client.post(
            "/api/imports/faculty/preview",
            headers=h,
            files={"file": ("fixture.txt", b"not a supported spreadsheet")},
        ).status_code
        == 422
    )


def test_foreign_department_hod_scope(store, client):
    a = store
    dep = a.db.insert(
        "departments", school_id=a.sc, code="TEST-EE", name="Other department"
    )
    uid = a.db.insert(
        "users",
        username="test-hod",
        name="Test HoD",
        role_id=a.db.val("SELECT id FROM roles WHERE name='HoD'"),
        department_id=dep,
    )
    h = headers(a.db, uid)
    assert client.get("/api/students", headers=h).json()["total"] == 0
    assert client.get("/api/students/" + str(a.sid), headers=h).status_code == 404


def test_no_attendance_relaxation_inferred(store, client):
    a = store
    c, z, _ = a.course(4)
    submit(a.db, a.usr, a.s(), c, z, "Normal", True)
    h = headers(a.db, a.uid)
    payload = {
        "student_id": a.sid,
        "section_id": z,
        "attended": 7,
        "conducted": 10,
        "status": "",
        "confirm": True,
    }
    assert (
        client.post("/api/attendance/record", json=payload, headers=h).status_code
        == 422
    )
    a.db.run("UPDATE regulations SET attendance_threshold=80 WHERE id=%s", (a.r,))
    a.conn.commit()
    r = client.post("/api/attendance/record", json=payload, headers=h)
    assert r.status_code == 200, r.text
    assert a.db.val("SELECT status FROM attendance_records") == "Shortage"


def test_minimum_credit_checked_at_finalisation(store, client):
    a = store
    h = headers(a.db, a.stid)
    assert (
        client.post(
            f"/api/students/{a.sid}/finalise", headers=h, json={"confirm": True}
        ).status_code
        == 409
    )
    c, z, _ = a.course(4)
    submit(a.db, a.usr, a.s(), c, z, "Normal", True)
    a.conn.commit()
    assert (
        client.post(
            f"/api/students/{a.sid}/finalise", headers=h, json={"confirm": True}
        ).status_code
        == 200
    )


@pytest.mark.parametrize(
    "value,expected", [("09:30", 570), ("00:00", 0), ("23:59", 1439)]
)
def test_unit_timetable_time_normalisation(value, expected):
    assert tparse(value) == expected


@pytest.mark.parametrize(
    "value,expected", [("true", True), ("No", False), ("1", True), ("0", False)]
)
def test_unit_import_boolean_normalisation(value, expected):
    assert boolean(value) == expected


def test_repeat_attempt_keeps_history_without_awarding_debarred_credit(store, client):
    from backend.imports import apply_row

    a = store
    c, z, _ = a.course(4)
    first = submit(a.db, a.usr, a.s(), c, z, "Normal", True)
    h = headers(a.db, a.uid)
    r = client.post(
        "/api/attendance/record",
        headers=h,
        json={
            "student_id": a.sid,
            "section_id": z,
            "attended": 4,
            "conducted": 16,
            "status": "Debarred",
            "confirm": True,
        },
    )
    assert r.status_code == 200, r.text
    assert (
        a.db.val("SELECT status FROM course_enrolments WHERE id=%s", (first["id"],))
        == "Debarred"
    )
    assert credit_audit(a.db, a.s())["earned"] == 0
    second = submit(a.db, a.usr, a.s(), c, z, "Recovery", True)
    assert (
        a.db.val("SELECT attempt FROM course_enrolments WHERE id=%s", (second["id"],))
        == 2
    )
    apply_row(
        a.db,
        a.usr,
        "results",
        {
            "register_number": a.s()["register_number"],
            "course_code": a.db.val("SELECT code FROM courses WHERE id=%s", (c,)),
            "attempt": "2",
            "outcome": "Passed",
            "verified": "true",
        },
    )
    assert (
        credit_audit(a.db, a.s())["earned"] == 3
        and credit_audit(a.db, a.s())["registered"] == 0
    )
    assert (
        a.db.val("SELECT count(*) FROM student_course_results WHERE outcome='Debarred'")
        == 1
    )


def test_capacity_increase_promotes_waitlist_and_rejects_room_overflow(store, client):
    a = store
    c, z, _ = a.course(4, capacity=1)
    submit(a.db, a.usr, a.s(), c, z, "Normal", True)
    s2 = a.student()
    waiting = submit(a.db, a.usr, a.s(s2), c, z, "Normal", True)
    h = headers(a.db, a.uid)
    assert (
        client.put(
            f"/api/sections/{z}/capacity",
            headers=h,
            json={"capacity": 101, "reserved_seats": 0, "confirm": True},
        ).status_code
        == 409
    )
    assert (
        client.put(
            f"/api/sections/{z}/capacity",
            headers=h,
            json={"capacity": 2, "reserved_seats": 0, "confirm": True},
        ).status_code
        == 200
    )
    assert (
        a.db.val("SELECT status FROM course_enrolments WHERE id=%s", (waiting["id"],))
        == "Registered"
    )


def test_unapproved_equivalence_expiry_and_cross_department_pool(store):
    a = store
    c, z, o = a.course(4)
    c2, _, _ = a.course(4, offer=False)
    e = a.db.insert(
        "course_equivalences",
        course_a=c,
        course_b=c2,
        approved=False,
        recognise_credit=True,
        valid_from=date.today(),
        valid_until=date.today() + timedelta(days=10),
    )
    a.db.run("INSERT INTO offering_mappings VALUES(%s,%s)", (o, c2))
    assert evaluate(a.db, a.s(), c2, z)["status"] == "Blocked"
    a.db.run(
        "UPDATE course_equivalences SET approved=true,valid_from=current_date-5,valid_until=current_date-1 WHERE id=%s",
        (e,),
    )
    assert evaluate(a.db, a.s(), c2, z)["status"] == "Blocked"
    other = a.db.insert(
        "departments",
        school_id=a.sc,
        code="TEST-POOL",
        name="Synthetic pooled department",
    )
    a.db.run("UPDATE faculty SET department_id=%s WHERE id=%s", (other, a.f))
    assert evaluate(a.db, a.s(), c, z)["status"] == "Eligible"
