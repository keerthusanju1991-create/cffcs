"""Each test owns a freshly migrated, randomly named PostgreSQL schema. Never mutates pilot rows."""

import os, sys, uuid, secrets
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ["APP_MODE"] = "synthetic"
import pytest, psycopg
from psycopg.rows import dict_row
from psycopg import sql
from psycopg.conninfo import make_conninfo
from datetime import date, timedelta, datetime, timezone
from backend.core import *
from backend.api import app
from fastapi.testclient import TestClient


@pytest.fixture
def store():
    schema = "cfcs_test_" + uuid.uuid4().hex[:12]
    base = os.getenv("TEST_DATABASE_URL", DSN)
    with psycopg.connect(base, autocommit=True) as cc:
        cc.execute(sql.SQL("CREATE SCHEMA {}").format(sql.Identifier(schema)))
    dsn = make_conninfo(base, options="-c search_path=" + schema)
    conn = psycopg.connect(dsn, row_factory=dict_row)
    db = DB(conn)
    for mig in sorted((ROOT / "migrations").glob("*.sql")):
        db.run(mig.read_text())
    setup_roles(db)
    sc = db.insert("schools", code="TEST", name="Synthetic test school")
    dep = db.insert(
        "departments", school_id=sc, code="TEST-CS", name="Synthetic computing"
    )
    pr = db.insert(
        "programmes",
        department_id=dep,
        code="TEST-BT",
        name="Test programme",
        semesters=8,
    )
    batch = db.insert("admission_batches", year=2024)
    y = db.insert(
        "academic_years",
        label="Test year",
        starts_on=date.today() - timedelta(days=100),
        ends_on=date.today() + timedelta(days=100),
    )
    w = db.insert(
        "registration_windows",
        name="Test window",
        academic_year_id=y,
        opens_at=datetime.now(timezone.utc) - timedelta(days=10),
        closes_at=datetime.now(timezone.utc) + timedelta(days=10),
    )
    sem = {i: db.insert("curriculum_semesters", number=i) for i in range(1, 9)}
    cat = db.insert("course_categories", code="CORE", name="Test core", elective=False)

    def reg(code):
        r = db.insert(
            "regulations",
            code=code,
            name="Test regulation " + code,
            active=True,
            floating_window=1,
            conditional_allowed=False,
        )
        db.insert(
            "credit_limits",
            regulation_id=r,
            programme_id=pr,
            academic_year_id=y,
            minimum_credits=3,
            maximum_credits=24,
        )
        db.insert(
            "graduation_requirements",
            regulation_id=r,
            programme_id=pr,
            total_credits=48,
            mandatory_credits=32,
            elective_credits=0,
        )
        return r

    r = reg("TEST-A")
    ass = db.insert(
        "assessment_schemes",
        name="Test assessment",
        regulation_id=r,
        description="Synthetic test",
    )
    room = db.insert("classrooms", code="TEST-101", capacity=100)

    def faculty():
        fid = db.insert(
            "faculty",
            staff_number="TEST-F-" + uuid.uuid4().hex[:6],
            name="Synthetic instructor",
            department_id=dep,
            specialisation="Testing",
            lab_competent=True,
        )
        db.insert(
            "faculty_workloads",
            faculty_id=fid,
            academic_year_id=y,
            maximum_hours=30,
            other_hours=0,
        )
        for i in range(1, 8):
            db.insert(
                "faculty_availability", faculty_id=fid, weekday=i, starts=420, ends=1200
            )
        return fid

    f = faculty()
    seq = [0]

    def course(
        n, rid=None, credits=3, teacher=None, capacity=50, publish=True, offer=True
    ):
        rr = rid or r
        seq[0] += 1
        code = "TEST-C" + str(seq[0])
        a = db.val(
            "SELECT id FROM assessment_schemes WHERE regulation_id=%s LIMIT 1", (rr,)
        ) or db.insert(
            "assessment_schemes",
            name="Test assessment",
            regulation_id=rr,
            description="Independent grading",
        )
        c = db.insert(
            "courses",
            code=code,
            title="Synthetic course " + str(seq[0]),
            programme_id=pr,
            regulation_id=rr,
            semester_id=sem[n],
            category_id=cat,
            credits=credits,
            lecture=1,
            tutorial=0,
            practical=0,
            assessment_id=a,
            approved=True,
        )
        if not offer:
            return c, None, None
        fid = teacher or f
        db.run("INSERT INTO faculty_course_competencies VALUES(%s,%s,true)", (fid, c))
        o = db.insert(
            "course_offerings",
            course_id=c,
            department_id=dep,
            academic_year_id=y,
            window_id=w,
            status="Published" if publish else "Draft",
            recovery_allowed=True,
        )
        db.run("INSERT INTO offering_mappings VALUES(%s,%s)", (o, c))
        z = db.insert(
            "course_sections",
            offering_id=o,
            label="A",
            faculty_id=fid,
            maximum_seats=capacity,
            minimum_seats=0,
            reserved_seats=0,
        )
        t = 480 + (seq[0] % 6) * 65
        db.insert(
            "timetable_slots",
            section_id=z,
            room_id=room,
            weekday=seq[0] // 6 % 5 + 1,
            starts=t,
            ends=t + 60,
            kind="Theory",
        )
        return c, z, o

    def student(n=4, rid=None):
        return db.insert(
            "students",
            register_number="TEST-S-" + uuid.uuid4().hex[:7],
            name="Synthetic student",
            programme_id=pr,
            regulation_id=rid or r,
            batch_id=batch,
            semester_id=sem[n],
            status="Active",
            advisor_id=f,
        )

    sid = student()
    uid = db.insert(
        "users",
        username="test-admin",
        name="Test administrator",
        role_id=db.val("SELECT id FROM roles WHERE name='Super Administrator'"),
        demo=True,
    )
    stid = db.insert(
        "users",
        username="test-student",
        name="Test student",
        student_id=sid,
        department_id=dep,
        role_id=db.val("SELECT id FROM roles WHERE name='Student'"),
        demo=True,
    )
    db.run("INSERT INTO workspace_metadata VALUES('dataset','synthetic')")
    usr = {
        "id": uid,
        "role": "Super Administrator",
        "permissions": PERM["Super Administrator"],
        "department_id": None,
    }
    conn.commit()

    class Store:
        pass

    d = Store()
    d.__dict__.update(locals())
    d.s = lambda id=sid: get_student(db, usr, id)
    d.record = lambda c, outcome="Passed", verified=True: db.insert(
        "student_course_results",
        student_id=sid,
        course_id=c,
        attempt=1,
        outcome=outcome,
        verified=verified,
    )
    try:
        yield d
    finally:
        conn.close()
        with psycopg.connect(base, autocommit=True) as cc:
            cc.execute(sql.SQL("DROP SCHEMA {} CASCADE").format(sql.Identifier(schema)))


@pytest.fixture
def client(store):
    def scoped():
        with psycopg.connect(store.dsn, row_factory=dict_row) as c:
            yield DB(c)

    app.dependency_overrides[get_db] = scoped
    try:
        yield TestClient(app)
    finally:
        app.dependency_overrides.pop(get_db, None)


def headers(db, uid):
    t = session(db, uid)["access_token"]
    db.c.commit()
    return {"Authorization": "Bearer " + t}
