"""All twenty numbered SET pilot acceptance scenarios; all data are test fixtures."""

import pytest, threading, concurrent.futures
from fastapi import HTTPException
from backend.core import *
from backend.engine import *
from conftest import headers


def test_01_current_semester_registration(store):
    a = store
    c, z, _ = a.course(4)
    result = submit(a.db, a.usr, a.s(), c, z, "Normal", True)
    assert (result["status"], result["basket"]) == ("Registered", "Regular")


def test_02_immediately_succeeding_semester(store):
    a = store
    c, z, _ = a.course(5)
    r = submit(a.db, a.usr, a.s(), c, z, "Normal", True)
    assert r["basket"] == "Floating" and r["priority"] == "P5"


def test_03_two_semesters_ahead_blocked(store):
    a = store
    c, z, _ = a.course(6)
    r = evaluate(a.db, a.s(), c, z)
    assert r["status"] == "Blocked" and "window" in r["reason"]


def test_04_verified_backlog_outside_window(store):
    a = store
    c, z, _ = a.course(2)
    a.record(c, "Failed")
    r = submit(a.db, a.usr, a.s(), c, z, "Recovery", True)
    assert r["basket"] == "Backlog" and r["priority"] == "P2"


def test_05_debarment_normal_block_repeat_allowed_zero_credits(store):
    a = store
    c, z, _ = a.course(4)
    a.record(c, "Debarred")
    assert evaluate(a.db, a.s(), c, z, "Normal")["status"] == "Blocked"
    assert credit_audit(a.db, a.s())["earned"] == 0
    assert submit(a.db, a.usr, a.s(), c, z, "Recovery", True)["basket"] == "Repeat"


def test_06_debarment_does_not_block_unrelated_course(store):
    a = store
    c, z, _ = a.course(4)
    other, oz, _ = a.course(4)
    a.db.insert(
        "attendance_records",
        student_id=a.sid,
        course_id=c,
        academic_year_id=a.y,
        attended=3,
        conducted=16,
        status="Debarred",
    )
    assert evaluate(a.db, a.s(), other, oz)["status"] == "Eligible"


def test_07_mandatory_prerequisites_require_verified_results(store):
    a = store
    pre, _, _ = a.course(2)
    c, z, _ = a.course(4)
    g = a.db.insert(
        "course_prerequisite_groups",
        course_id=c,
        name="Foundations",
        operator="AND",
        kind="Mandatory",
    )
    a.db.insert("course_prerequisites", group_id=g, prerequisite_id=pre)
    a.record(pre, "Passed", False)
    r = evaluate(a.db, a.s(), c, z)
    assert r["status"] == "Blocked" and "successful completion" in r["reason"]
    a.db.run("UPDATE student_course_results SET verified=true")
    assert evaluate(a.db, a.s(), c, z)["status"] == "Eligible"


def test_08_conditional_prerequisite_approved_exception(store):
    a = store
    pre, _, _ = a.course(2)
    c, z, _ = a.course(5)
    g = a.db.insert(
        "course_prerequisite_groups",
        course_id=c,
        name="Conditional",
        operator="AND",
        kind="Conditional",
    )
    a.db.insert("course_prerequisites", group_id=g, prerequisite_id=pre)
    assert evaluate(a.db, a.s(), c, z)["status"] == "Pending approval"
    a.db.insert(
        "academic_exceptions",
        student_id=a.sid,
        course_id=c,
        kind="Conditional prerequisite",
        reason="Synthetic advisor evidence.",
        evidence="Test document",
        requested_by=a.stid,
        authority="Registrar",
        status="Approved",
        decided_by=a.uid,
        academic_year_id=a.y,
    )
    assert evaluate(a.db, a.s(), c, z)["status"] == "Eligible"


def test_09_credit_limit_enforced(store):
    a = store
    a.db.run("UPDATE credit_limits SET maximum_credits=3")
    c, z, _ = a.course(4, credits=4)
    assert "Credit limit exceeded" in evaluate(a.db, a.s(), c, z)["reason"]


def test_10_duplicate_registration_refused(store):
    a = store
    c, z, _ = a.course(4)
    submit(a.db, a.usr, a.s(), c, z, "Normal", True)
    assert "Duplicate registration" in evaluate(a.db, a.s(), c, z)["reason"]


def test_11_atomic_last_seat_race(store):
    a = store
    c, z, _ = a.course(4, capacity=1)
    second = a.student()
    a.conn.commit()
    barrier = threading.Barrier(2)

    def compete(sid):
        with psycopg.connect(a.dsn, row_factory=dict_row) as conn:
            db = DB(conn)
            s = get_student(db, a.usr, sid)
            barrier.wait(timeout=5)
            return submit(db, a.usr, s, c, z, "Normal", True)["status"]

    with concurrent.futures.ThreadPoolExecutor(2) as ex:
        states = list(ex.map(compete, [a.sid, second]))
        assert sorted(states) == ["Registered", "Waitlisted"]
    assert (
        a.db.val("SELECT count(*) FROM course_enrolments WHERE status='Registered'")
        == 1
    )


def test_12_shared_section_independent_regulation_credits(store):
    a = store
    c, z, o = a.course(4, credits=4)
    r2 = a.reg("TEST-B")
    c2, _, _ = a.course(4, r2, credits=2, offer=False)
    s2 = a.student(4, r2)
    a.db.insert(
        "course_equivalences",
        course_a=c,
        course_b=c2,
        approved=True,
        recognise_credit=True,
        valid_from=date.today(),
        valid_until=date.today() + timedelta(days=10),
    )
    a.db.run("INSERT INTO offering_mappings VALUES(%s,%s)", (o, c2))
    res = submit(a.db, a.usr, a.s(s2), c2, z, "Normal", True)
    assert res["credits"] == 2 and res["course_id"] == c2
    assert credit_audit(a.db, a.s(s2))["registered"] == 2


from datetime import timedelta


def test_13_non_equivalent_courses_cannot_share_delivery(store):
    a = store
    c, z, o = a.course(4)
    other, _, _ = a.course(4, offer=False)
    a.db.run("INSERT INTO offering_mappings VALUES(%s,%s)", (o, other))
    r = evaluate(a.db, a.s(), other, z)
    assert r["status"] == "Blocked" and "equivalence" in r["reason"]


def test_14_faculty_assignment_cannot_exceed_norm(store):
    a = store
    c, z, _ = a.course(4)
    a.db.run("UPDATE faculty_workloads SET maximum_hours=1,other_hours=1")
    assert "workload" in evaluate(a.db, a.s(), c, z)["reason"]


def test_15_faculty_timetable_conflict(store):
    a = store
    c, z, _ = a.course(4)
    c2, z2, _ = a.course(5)
    a.db.run(
        "UPDATE timetable_slots t SET weekday=b.weekday,starts=b.starts,ends=b.ends FROM timetable_slots b WHERE t.section_id=%s AND b.section_id=%s",
        (z2, z),
    )
    assert "Faculty timetable conflict" in evaluate(a.db, a.s(), c2, z2)["reason"]


def test_16_student_timetable_conflict(store):
    a = store
    c, z, _ = a.course(4)
    submit(a.db, a.usr, a.s(), c, z, "Normal", True)
    c2, z2, _ = a.course(5, teacher=a.faculty())
    room = a.db.insert("classrooms", code="TEST-202", capacity=100)
    a.db.run(
        "UPDATE timetable_slots t SET room_id=%s,weekday=b.weekday,starts=b.starts,ends=b.ends FROM timetable_slots b WHERE t.section_id=%s AND b.section_id=%s",
        (room, z2, z),
    )
    assert "Student timetable conflict" in evaluate(a.db, a.s(), c2, z2)["reason"]


def test_17_full_section_waitlists_and_promotes(store, client):
    a = store
    c, z, _ = a.course(4, capacity=1)
    first = submit(a.db, a.usr, a.s(), c, z, "Normal", True)
    other = a.student()
    second = submit(a.db, a.usr, a.s(other), c, z, "Normal", True)
    assert second["status"] == "Waitlisted"
    h = headers(a.db, a.uid)
    resp = client.post(
        f"/api/registration/{first['id']}/drop",
        headers=h,
        json={"confirm": True, "remarks": "Test release"},
    )
    assert resp.status_code == 200, resp.text
    assert (
        a.db.val("SELECT status FROM course_enrolments WHERE id=%s", (second["id"],))
        == "Registered"
    )


def test_18_final_semester_pending_graduation_priority(store):
    a = store
    final = a.student(8)
    c, z, _ = a.course(2)
    a.db.run("INSERT INTO pending_requirements VALUES(%s,%s,true)", (final, c))
    r = submit(a.db, a.usr, a.s(final), c, z, "Auto", True)
    assert r["priority"] == "P1"


def test_19_withdrawal_after_preferences_preserves_demand(store, client):
    a = store
    c, z, o = a.course(5)
    a.db.insert(
        "course_preferences",
        student_id=a.sid,
        course_id=c,
        academic_year_id=a.y,
        rank=1,
        interest="Floating",
    )
    h = headers(a.db, a.uid)
    resp = client.post(
        f"/api/offerings/{o}/withdraw",
        headers=h,
        json={"confirm": True, "remarks": "Synthetic planning change"},
    )
    assert resp.status_code == 200, resp.text
    assert a.db.val("SELECT count(*) FROM course_preferences") == 1
    assert evaluate(a.db, a.s(), c, z)["status"] == "Blocked"


def test_20_unauthorised_academic_modification_denied(store, client):
    a = store
    h = headers(a.db, a.stid)
    r = client.put(
        f"/api/admin/masters/students/{a.sid}",
        headers=h,
        json={"confirm": True, "values": {"status": "Graduated"}},
    )
    assert r.status_code == 403
    assert a.s()["status"] == "Active"
    s2 = a.student()
    a.conn.commit()
    assert client.get("/api/students/" + str(s2), headers=h).status_code == 404
